> Public experimental source. PRIVATE in export names and schemas describes user-generated reports, not this source package. Use only invented examples; never infer permission to disclose reports or data. Browser/real-user acceptance is not established. See README_START_HERE.md.

# Project Status & Escalation Digest | Private AI contract PD-STATUS-1

**Private, invented examples only.** The browser tool makes a status snapshot from a rigid local 10-column CSV. It does not contact clients, authenticate evidence, access any account, change commitments, store data remotely or grant any publication rights.

## Inputs and calculations

Header (exact order): `item_id,category,summary,status,owner_role,due_on,impact,next_step,evidence_ref,visibility`.
Snapshot date is an explicitly user-entered ISO calendar day, *not inferred from device timezone*. Open items past that day are counted overdue, those on the snapshot date through seven calendar days later counted due soon. Both counts are mutually exclusive. `REPORTED_COMPLETE` and `CANCELLED` items are excluded from open-date counts. Dates are target labels, not assertions of contractual breach. Completion is explicitly *self-reported* even when an evidence reference is filled. Blocked/waiting items must have a clear next action; waiting-client entries should have the generic CLIENT owner role. Names, URLs, contact details, confidential/security content and private/restricted/unknown visibility must not be used in the pilot.

Output CSV: exception rows only, **PRIVATE**, contains entered item IDs, next-step text and other identifying data. TXT: detailed **PRIVATE** review including all source summaries and unverified reference labels. JSON: `PD-STATUS-1` **counts only** (no source row labels, dates, IDs, prices or narrative). It explicitly denies verified completion, customer contact authorization and public release. The CLIENT REVIEW DRAFT (TXT) only appears when all items self-label PUBLIC_GENERIC and specified apparent disclosure/context checks pass; it is still not deemed cleared, approved, delivered or publishable. Human screening is mandatory, and the tool is not a DLP or rights-verification system.

## Interaction boundaries

The tool is distinct from the dependency planner (upstream scheduling model), handover checker (post-delivery acceptance review), and change order guard (contract scope changes). This is a **periodic operational snapshot and action-queue review**. Nothing is automatically sent or accepted. Do not treat the JSON counts as customer evidence. No client communication, website update, invoicing or real-data processing is authorized.

## Current collection evidence
Read VALIDATION.md for performed checks and unverified gates on this exact collection. Historical upstream in-memory browser results are not a rerun or acceptance of this candidate. Public source availability does not grant permission to disclose user-generated outputs or to act on their contents.
