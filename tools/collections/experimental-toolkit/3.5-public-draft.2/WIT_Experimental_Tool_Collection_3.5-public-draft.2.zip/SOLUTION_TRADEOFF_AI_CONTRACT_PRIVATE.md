> Public experimental source. PRIVATE in export names and schemas describes user-generated reports, not this source package. Use only invented examples; never infer permission to disclose reports or data. Browser/real-user acceptance is not established. See README_START_HERE.md.

# PD-SOLUTION-TRADEOFF-1 | PRIVATE local-only data contract

Purpose: compare **proposed solutions** against mandatory requirements and optional weighted preferences. This does not duplicate third-party vendor bid coverage (tool 21), requirements-to-evidence indexing (tool 05), root-cause experiments (tool 13) or project quote preparation (tool 01). It tests whether each original solution choice claims to meet non-negotiable constraints before weighing preferences or hypothetical cost.

## Input registers (RFC-4180 CSV, exact headers)

1. Criteria: `criterion_id,criterion_label,priority,weight,source_ref`. 1–35 rows. `priority=must` requires `weight=0`; `priority=prefer` needs weight 1–5. At least one must-have; uppercase synthetic codes.
2. Options: `option_id,option_label,estimated_cost_cad,cost_source_ref,rights_state,security_state`. 1–12 rows. Fictional CAD decimal estimates max 100,000,000.00; blanks remain flagged. Rights `reported_cleared/uncertain/restricted`; security `reported_reviewed/pending/stop`.
3. Assessments: `option_id,criterion_id,fit,evidence_state,evidence_ref`. 1–420 rows, one candidate/criterion pair maximum. Every expected pair must appear to be register-complete; absent pairs produce holds. `fit=met/not_met/unknown`, `evidence_state=source_checked/reported_only/missing`.

All max 75,000 input bytes individually. Plain labels are 2–64 characters, no live identities, links or email addresses. Inputs may be imported separately from invented local CSV fixtures. Duplicate keys, unknown IDs, malformed rows, impossible monetary syntax and unexpected status values fail closed. Never execute data as HTML, script or external code.

## Decision model

- BLOCK: at least one mandatory constraint `not_met`, restricted reported rights, or security stop.
- HOLD: mandatory unknown or unsupported met claim, unresolved rights or security review, unsubstantiated cost, missing assessment, unknown / unproven optional preference or missing provenance.
- ROW-READY: all table-level fields sufficiently complete, even if optional preferences explicitly `not_met`; **not approval**.
- Preference display is an evidence-screened *reported* weighted tally, not a recommendation, ranking, guarantee, legal rights verification or independent validation. Never let low estimated price override a hard gate.

Exports: private exception-only CSV, private detailed TXT and aggregate-only `PD-SOLUTION-TRADEOFF-1` JSON with unconditional `false` for verified rights, security, cost, independent sources, consent, purchase/publication or receipts; `humanDecisionRequired=true` always. Changes invalidate prior results. No network, storage, account links, customer contact, implementation, payment, publishing or shared services.

## Current collection evidence
Read VALIDATION.md for performed checks and unverified gates on this exact collection. Historical upstream in-memory browser results are not a rerun or acceptance of this candidate. Public source availability does not grant permission to disclose user-generated outputs or to act on their contents.
