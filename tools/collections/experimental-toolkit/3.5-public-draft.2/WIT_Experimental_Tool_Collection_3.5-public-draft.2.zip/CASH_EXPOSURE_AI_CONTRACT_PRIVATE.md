> Public experimental source. PRIVATE in export names and schemas describes user-generated reports, not this source package. Use only invented examples; never infer permission to disclose reports or data. Browser/real-user acceptance is not established. See README_START_HERE.md.

# PD-CASH-EXPOSURE-1 | PRIVATE, aggregate-only AI data contract

Purpose: estimate illustrative **project cash timing exposure** across three deterministic scenarios from original fictional event entries, independent of milestone invoice reconciliation and project profitability. This is a pre-commitment internal decision aid, not a booking, collection or invoice tool.

CSV: `event_id,date,direction,amount_cad,state,source_ref`. Never include customer names, bank details, real employer site details, payments or contractual evidence. `date` is YYYY-MM-DD. Direction `IN` states are `proposed`, `due_reported`, `received_reported`, `disputed`; `OUT` states are `estimated`, `committed_reported`, `paid_reported`, `disputed`. `received_reported` / `paid_reported` must not be later than the user-selected reporting date; status still constitutes **no verification**. Records represent fictional potential cash movement, not enforceable receivables/payables.

Assumptions: integer CAD cents, 1–150 dated events, max CAD $1m per event, $10m total, user-supplied fictional **opening** cash reserve from before the earliest modelled event (NOT the current bank balance, since that could double-count a historic deposit). Expenses always count (including disputed), disputed inflows never count. Baseline schedules non-disputed inflows for the stated day. Delay scenario shifts all inflows not marked `received_reported` by the selected number of days (7/14/30/60). No-future-receipts scenario counts only `received_reported` inflows. Outflows are booked before receipts on any given day. Peak additional cash need is `max(0, -min running_balance)`. These are deterministic stress illustrations, **not forecasts**, statements of actual available funds, or proof of cleared deposits. Taxes, contract restrictions, collection risk, expense uncertainty, weekends, processor timing and legal/regulatory obligations are outside scope.

Privacy: the exported AI JSON contains only schema, bounded counts, boolean risk flags and explicit non-authority claims; no event identifiers, dates, amounts, private source references, bank details, client names, contract records or actual cash balances. CSV/TXT detailed outputs are PRIVATE and must not be pasted into external AI or published without review. CSV export uses spreadsheet-formula escaping.

Human gate: verify source rights, project eligibility and real authority, signed payment terms, cost commitments, contract deposit/refund clauses and actual cleared funds outside tool. No automated client contact, quote sending, deposits, invoicing, spending, project starts, bank/tax/QBO changes or public posting.

Current source status: public experimental collection; current performed tests and remaining gates are recorded in VALIDATION.md. No real-world use or authority is established.

## Current collection evidence
Read VALIDATION.md for performed checks and unverified gates on this exact collection. Historical upstream in-memory browser results are not a rerun or acceptance of this candidate. Public source availability does not grant permission to disclose user-generated outputs or to act on their contents.
