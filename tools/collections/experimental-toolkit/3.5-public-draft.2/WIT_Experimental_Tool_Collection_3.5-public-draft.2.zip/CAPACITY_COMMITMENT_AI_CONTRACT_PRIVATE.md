> Public experimental source. PRIVATE in export names and schemas describes user-generated reports, not this source package. Use only invented examples; never infer permission to disclose reports or data. Browser/real-user acceptance is not established. See README_START_HERE.md.

# PD-CAPACITY-1 | PRIVATE, fictional, counts-only handoff

**Tool:** `27_Crew_Capacity_Commitment_Guard.html` (v2.5). First-party original offline HTML/JavaScript; reuses the toolkit's first-party `common.js` CSV parser/escaping and `styles.css`. No third-party code, external scripts, libraries, API, web requests, account integrations or persistent storage.

**Distinct buyer problem:** Before accepting a fixed-scope project, compare *role-week crew hours* available to *approved and tentative hours promised*, revealing firm overloads, soft holds, missing staff/source/rights gaps. This is a provisional capacity arithmetic review, **not** the site dispatch preflight (22), a project dependency map (11), a service completion audit (26) or a quote. It cannot schedule a day, prove qualified labor, verify approvals or assign people. No automatic pricing, billing, payroll, safety or authorization outcomes.

## Two original local fictional CSV contracts

- `capacity.csv` exact header: `week_start,role_code,available_hours,staffing_state,rights_status,source_ref`.
- `commitments.csv` exact header: `commitment_id,week_start,role_code,planned_hours,commitment_state,estimate_basis,rights_status,scope_ref`.
- `week_start` is a valid Monday in `YYYY-MM-DD`, 2000–2100 inclusive. Each `week_start` + `role_code` capacity row must be unique. Each commitment ID must be unique across rows. Split any actual multiweek project manually into one distinct commitment ID per role-week: the model does **not** prorate dates or infer shift schedules.
- `role_code` is uppercase alphanumeric/underscore/hyphen, 2–25 chars; commitment IDs are uppercase limited safe tokens, 2–31 chars. Source references are only *reported pointers*; `UNKNOWN` is accepted for missing refs and flagged, never evidence of permission.
- Decimal hours must be nonnegative, at most 2 places, <=2000.00 per row; active work must be >0. Totals are exact integer hundredths of an hour. A reported `confirmed` capacity contributes its full hours; `tentative`/`unavailable` contributes zero confirmed hours even if a number is typed. `approved` commitments count firm demand, `tentative` soft demand, `cancelled` excluded from demand, findings and ghost buckets.
- `rights_status`: `cleared/unknown/restricted`; `staffing_state`: `confirmed/tentative/unavailable`; `commitment_state`: `approved/tentative/cancelled`; `estimate_basis`: `source_backed/rough`. Every status is supplied by the fictional author; even `cleared`, `approved` and `source_backed` remain unverified claims.
- Maximum 100 capacity rows, 200 commitment rows, 80,000 characters per text input or 80,000 bytes per local file, and max 90 characters per individual parsed CSV cell. Required exact header and valid column count; malformed data stops review and disables private export until corrected.

## Human-only outcome model

- Hard overcommit: `approved_hours > confirmed_hours`. The exact excess is shown.
- Soft risk: hard demand fits, but `approved_hours + tentative_hours > confirmed_hours`.
- Missing role-week capacity remains a HOLD, with zero confirmed capacity assumed for review math, never a suggestion to hire or authorize overtime.
- Unknown or restricted capacity/commitment rights, rough estimates, missing sources and tentative staffing/work generate human findings.
- The detailed local UI, CSV and TXT stay PRIVATE and may include labels/identifiers. They **must not** be sent to an AI/provider or published without fresh permission and privacy/IP review.

**Permitted AI-facing input:** The *counts-only* JSON downloaded from the tool (`kind=private_counts_only_capacity_commitment_review`), containing only role-week bucket count, active reported commitment count, firm and possible overbook bucket counts, missing capacity bucket count and human finding count. It deliberately excludes week dates, role names, scope IDs, people, employers, customers, hours and dollar figures. Flags `staffing_verified`, `rights_verified`, `calendar_verified`, `action_authorized`, `published` are always `false`.

**Safe AI use:** Explain that a human should review reported overbooking, source gaps and decision boundaries. Never infer actual staffing, compliance, third-party rights, clearance, promised delivery, pricing or revenue. The tool does not act on clients, schedules, banks, invoice systems, taxes, QBO or any outside system. No copies of employer/client confidential material or safety bypass detail.

**Original invented test fixtures:** `examples/capacity_guard_capacity_risk_fictional.csv`, `examples/capacity_guard_commitments_risk_fictional.csv`, `examples/capacity_guard_capacity_clean_fictional.csv`, `examples/capacity_guard_commitments_clean_fictional.csv`. No real data.

## Current collection evidence
Read VALIDATION.md for performed checks and unverified gates on this exact collection. Historical upstream in-memory browser results are not a rerun or acceptance of this candidate. Public source availability does not grant permission to disclose user-generated outputs or to act on their contents.
