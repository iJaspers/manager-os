'use strict';
// Versioned local-only import coordinator. A generation belongs to one editable field,
// not one whole app: independent input files can finish in either order.
function createSafeCSVImports(options){
 const states=new Map(options.pairs.map(([fileId,area])=>[area,{fileId,version:0,pending:false}]));
 const anyPending=()=>[...states.values()].some(s=>s.pending);
 function invalidate(){options.invalidate();}
 function message(text){document.getElementById(options.errorId).textContent=text;}
 function cancel(area){const s=states.get(area);if(s){s.version++;s.pending=false;}}
 function cancelAll(){for(const area of states.keys())cancel(area);}
 function guard(){if(!anyPending())return false;invalidate();message('FILE READ PENDING: analysis and exports are locked. Wait or edit/cancel the input.');return true;}
 async function load(input,area){
  const state=states.get(area),token=++state.version;
  state.pending=false;invalidate();
  const file=input.files&&input.files[0];
  if(!file)return; // a cancelled/new empty selection supersedes the earlier read
  state.pending=true;message('FILE READ PENDING: analysis and exports are locked.');
  try{
   const limit=options.maxBytes();
   if(!Number.isFinite(file.size)||file.size<0||file.size>limit)throw Error('Local CSV exceeds the allowed byte limit.');
   const text=await file.text();
   if(token!==state.version)return;
   if(typeof text!=='string'||new TextEncoder().encode(text).length>limit)throw Error('Decoded local CSV exceeds the allowed byte limit.');
   if(options.maxChars&&text.length>options.maxChars())throw Error('Local CSV exceeds the allowed character limit.');
   document.getElementById(area).value=text;
   state.pending=false;invalidate();
   if(anyPending())message('FILE READ PENDING: another input is still loading.');
  }catch(_){
   if(token!==state.version)return;
   state.pending=false;document.getElementById(area).value='';invalidate();
   message('FILE IMPORT FAILED: input cleared; choose a permitted fictional CSV or edit it manually.');
  }finally{
   // A stale completion must not clear a newer selection or pending state.
   if(token===state.version){state.pending=false;input.value='';}
  }
 }
 function bind(controls){
  for(const [fileId,area] of options.pairs)document.getElementById(fileId).addEventListener('change',e=>load(e.target,area));
  for(const id of controls){const changed=()=>{if(states.has(id))cancel(id);else cancelAll();invalidate();if(anyPending())message('FILE READ PENDING: another input is still loading.');};
   document.getElementById(id).addEventListener('input',changed);
   document.getElementById(id).addEventListener('change',changed);
  }
 }
 return {bind,load,cancelAll,guard,pending:anyPending};
}
