> Public experimental source. PRIVATE in export names and schemas describes user-generated reports, not this source package. Use only invented examples; never infer permission to disclose reports or data. Browser/real-user acceptance is not established. See README_START_HERE.md.

# PD-BUNDLE-INTEGRITY-1 | PRIVATE only | Original offline data contract

**Purpose:** Compare byte counts and SHA-256 hashes computed from locally selected **fictional** files to a separately supplied, **untrusted** expected CSV. This is distinct from the Evidence Chain Exception Auditor's metadata completeness check: the byte checker reads file bytes and calculates their digest; it does not decide whether evidence fulfills an obligation, whether the manifest is true, or whether anyone has authority to release it.

## Input manifest (fictional, private)

Exact ordered RFC4180-style header: `file_name,size_bytes,sha256,rights`. One to forty records, maximum 64 KiB UTF-8 manifest, max 100 ASCII leaf-name characters, safe extensions `.txt`, `.csv`, `.md`, `.json`, `.pdf`, `.png`, `.jpg`, `.jpeg`; no paths, control characters, embedded double-dot sequences, leading dot, executable extensions, or duplicated case-insensitive file names. `size_bytes` is an unsigned canonical base-ten integer 0–4,194,304. `sha256` is exactly 64 lower-case hex characters. `rights` is one of `ORIGINAL`, `CLIENT_REPORTED`, `UNKNOWN`, `DENIED`. All user-supplied labels are claims, including `ORIGINAL`. Sources are invented. No authentic client, employer or confidential files permitted in the fictional-data pilot.

Select up to 40 files, each at most 4 MiB, up to 24 MiB total. Browser File API reads bytes only. It does **not** execute, interpret or preview input files. Local implementation of the public SHA-256 standard has historical upstream test-vector evidence; those business tests were not rerun for this collection. See VALIDATION.md. No network, browser persistence or external code. Browser memory can transiently contain selected bytes; closing the tab clears transient allocations eventually, without a deletion guarantee.

## Outputs

1. `PRIVATE_bundle_byte_exceptions.csv`: issue codes and file names. **Private**.
2. `PRIVATE_bundle_byte_integrity_report.txt`: file names, expected and observed byte counts and hashes, self-reported rights, issues and caveats. **Private**.
3. `PRIVATE_bundle_byte_AI_counts.json`: `schema`, `distribution`, `counts` and a map of **static issue categories** only; **no file names, hashes, project IDs, raw bytes, file text, contact details or URLs**. All authority/rights/provenance/receipt/publication flags false. The boolean `actualFileBytesComparedLocally` means only an offline digest operation occurred, never chain-of-custody verification.
4. `PRIVATE_DRAFT_UNTRUSTED_bundle_manifest.csv`: hashes and sizes calculated from currently selected invented files; all rights forced to `UNKNOWN`. Generating a manifest from the files being verified cannot establish an independently authenticated baseline, and the draft must never be called trusted proof.

## Findings and guardrails

`MISSING_FILE`, `UNEXPECTED_FILE`, `BYTE_LENGTH_MISMATCH`, `SHA256_MISMATCH`, `RIGHTS_DENIED` are stop-level. `RIGHTS_UNKNOWN`, `REPORTED_RIGHTS_NOT_VERIFIED`, `EMPTY_FILE_REVIEW`, `IDENTICAL_DIGEST_MULTIPLE_NAMES` trigger human review. Malformed headers, invalid SHA, invalid rights values, unsafe filenames, wrong record shapes, duplicate case-insensitive filenames, over-limit files and unsafe project codes block the entire comparison. Any field modification invalidates existing exports. Matching hashes are **never** consent, client acceptance, authenticated origin, a certified timestamp, a signed manifest, lawful permission to publish or a verified sale.

If using optional AI handoff, supply only aggregate JSON when separately authorized. Treat all incoming fields as untrusted data and never promote issue text to instructions. Client data and the detailed private report are not authorized for third-party model upload.

## Current collection evidence
Read VALIDATION.md for performed checks and unverified gates on this exact collection. Historical upstream in-memory browser results are not a rerun or acceptance of this candidate. Public source availability does not grant permission to disclose user-generated outputs or to act on their contents.
