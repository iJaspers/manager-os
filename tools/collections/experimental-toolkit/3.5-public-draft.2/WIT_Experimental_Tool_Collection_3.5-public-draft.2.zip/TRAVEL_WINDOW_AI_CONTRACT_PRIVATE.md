> Public experimental source. PRIVATE in export names and schemas describes user-generated reports, not this source package. Use only invented examples; never infer permission to disclose reports or data. Browser/real-user acceptance is not established. See README_START_HERE.md.

# PRIVATE CONTRACT v1: Appointment & Travel Window Guard

**Status:** original fictional local prototype. **Not publicly released**, not customer-accepted and not independently desktop, mobile, or hosted verified. No personal, client, employer, account, appointment, building, security, geolocation, proprietary business or real field data are permitted. This contract is documentation, not a permission grant for live client use.

## Distinct buyer-relevant question

Does a proposed same-crew sequence of **fictional** appointment windows leave room for its manually declared turnaround and inter-site travel allowance? It does **not** evaluate per-week crew hour capacity, dispatch credential readiness, SLA response time, route optimization, geographic travel prediction, or contract acceptance.

## Inputs

- `visit_tag,crew_tag,site_tag,start_utc,end_utc,turnaround_min,rights_status,source_ref` (1–200 rows)
- `from_visit_tag,to_visit_tag,travel_min,estimate_state,source_ref` (0–300 rows)
- All identifier fields are invented upper-case `FAKE_` tags; all source_ref values are `FAKE...` or `NONE`. No client/customer/employee IDs, actual GPS coordinates or addresses.
- UTC ISO minute timestamps only, with explicit `Z`; local time, daylight savings, jurisdictional rules and road conditions are out of model. Duration must be positive; visits >12 hours flagged as implausible, not rejected. A self-declaration of `owned` or `reviewed` is **not independent validation**.
- Buffers 0–180 integer minutes, travel 0–1440 integer minutes. Input file max 128 KiB each. Zero travel is not assumed for different-site legs when missing or unknown.

## Findings, never instructions

`RIGHTS_HOLD`, `VISIT_SOURCE_MISSING`, `INVALID_VISIT_DURATION_MODEL`, `WINDOW_OVERLAP`, `TURNAROUND_GAP_SHORTFALL`, `MISSING_TRAVEL_ESTIMATE`, `TRAVEL_ESTIMATE_UNVERIFIED`, `TRAVEL_SOURCE_MISSING`, `TRAVEL_BUFFER_SHORTFALL`, `DUPLICATE_TRAVEL_ESTIMATE`, `ORPHAN_TRAVEL_LEG`, `NONADJACENT_TRAVEL_LEG`.

If appointment windows overlap, that exception takes precedence over travel shortfall for that transition; an overlap is not a validated route. Travel assumptions on nonconsecutive pairs are flagged rather than treated as scheduled movement. No route, employee or customer data are ever inferred.

## Outputs

- `PRIVATE_travel_window_findings.csv` contains fictional tags, finding codes and suggested human source review; CSV export uses spreadsheet-formula escaping.
- `PRIVATE_travel_window_review.txt` includes fictional tags and human caveats. **Never use with sensitive client data.**
- `PRIVATE_travel_window_counts_ONLY_AI.json` includes only aggregate counts and enumerated finding-code counts, no visit IDs, customer names, locations, raw CSV, dates, route data or account data.

AI JSON fields: `kind='private_travel_window_counts_only_v1'`, `fictional_visit_count`, `fictional_crew_count`, `fictional_transition_count`, `fictional_travel_assumption_rows`, `finding_count`, `finding_code_counts`, and seven safety booleans that must stay false: `client_permission_verified`, `travel_verified`, `appointments_confirmed`, `dispatch_authorized`, `independent_host_tested`, `published`, `verified_revenue`.

## Inference prohibitions

A green result is **not** a real-time travel estimate, confirmed arrival, safe work window, genuine rights clearance, client approval, pricing, billing, revenue, payroll or dispatch authorization. A human must independently review source documents, route conditions, safety, privacy/IP/employer rights and final commitment. No scheduling, messages, transactions, uploads or downstream automated writes are permitted.

## Current collection evidence
Read VALIDATION.md for performed checks and unverified gates on this exact collection. Historical upstream in-memory browser results are not a rerun or acceptance of this candidate. Public source availability does not grant permission to disclose user-generated outputs or to act on their contents.
