"""Private Evidence Chain tool: actual Chromium DOM and download checks using in-memory HTML. No file:// claim."""
import asyncio
import json
import pathlib
import traceback
from playwright.async_api import async_playwright

ROOT=pathlib.Path(__file__).resolve().parents[1]
RESULTS=[]
def check(name,ok,detail=''):
    item={'test':name,'pass':bool(ok),'detail':str(detail)}
    RESULTS.append(item)
    if not ok: raise AssertionError(f'{name}: {detail}')

RH='project_id,item_id,statement,owner,priority,status,evidence_ids,exception_reason'
EH='project_id,evidence_id,source_title,kind,observed_on,verification,rights,sensitivity'
R='DEMO,REQ-A,Check fictional source,Reviewer,critical,verified_complete,EV-A,'
E='DEMO,EV-A,Original synthetic document,document,2026-10-01,verified,cleared,synthetic_public'
async def main():
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        page=await browser.new_page(accept_downloads=True)
        network=[];page.on('request',lambda q:network.append(q.url))
        html=(ROOT/'05_Evidence_Chain_Exception_Auditor.html').read_text()
        html=html.replace('<link rel="stylesheet" href="styles.css">','<style>'+(ROOT/'styles.css').read_text()+'</style>')
        html=html.replace('<script src="common.js"></script>','<script>'+(ROOT/'common.js').read_text()+'</script>')
        await page.set_content(html,wait_until='load')
        errors=[];page.on('pageerror',lambda err:errors.append(str(err)))
        check('initial exports disabled',await page.locator('#csvexport').is_disabled() and await page.locator('#jsonexport').is_disabled())
        check('no network after initial load',not network,str(network))
        await page.click('#audit')
        codes=await page.locator('#results td:nth-child(3)').all_inner_texts()
        check('sample captures missing evidence','MISSING_EVIDENCE_ID' in codes,codes)
        check('sample catches unverified source','SOURCE_UNVERIFIED' in codes,codes)
        check('sample catches uncertain rights','SOURCE_RIGHTS_HOLD' in codes,codes)
        check('sample N/A review','NOT_APPLICABLE_SIGNOFF' in codes,codes)
        check('sample open blocker','BLOCKED_REQUIREMENT' in codes,codes)
        check('sample unused source','UNUSED_EVIDENCE' in codes,codes)
        check('sample status held','HOLD' in await page.locator('#status').inner_text())
        check('positive exports enabled',await page.locator('#csvexport').is_enabled() and await page.locator('#jsonexport').is_enabled())
        async with page.expect_download() as d: await page.click('#jsonexport')
        path=await (await d.value).path();data=json.loads(pathlib.Path(path).read_text())
        check('JSON has schema and review boundary',data['schema']=='PD-EVIDENCE-1' and data['permissionToPublish'] is False and data['reviewRequired'] is True)
        check('JSON omits titles and raw statements',not any('Fictional source register' in str(x) for x in data.values()) and 'source_title' not in str(data))
        async with page.expect_download() as d: await page.click('#textexport')
        content=pathlib.Path(await (await d.value).path()).read_text()
        check('human summary export', 'HUMAN' not in content or 'Human source' in content)
        async with page.expect_download() as d: await page.click('#csvexport')
        content=pathlib.Path(await (await d.value).path()).read_text()
        check('CSV exception export', 'MISSING_EVIDENCE_ID' in content and 'project_id' in content)
        await page.click('#clean');await page.click('#audit')
        check('clean fictional sample has no structural exception',await page.locator('#mexceptions').inner_text()=='0')
        check('clean still demands human review','HUMAN_REVIEW_REQUIRED' in await page.locator('#status').inner_text())
        await page.fill('#reqcsv', RH+'\n'+R+'\n'+R)
        await page.fill('#evcsv', EH+'\n'+E)
        await page.click('#audit')
        check('duplicate requirement ID','DUPLICATE_ITEM_ID' in await page.locator('#results').inner_text())
        async def case(name,req=R,ev=E,code=None,expect_hold=True):
            await page.fill('#reqcsv',RH+'\n'+req)
            await page.fill('#evcsv',EH+'\n'+ev)
            await page.click('#audit')
            text=await page.locator('#results').inner_text()
            check(name,(code in text if code else True) and (('HOLD' in await page.locator('#status').inner_text())==expect_hold),text[:500])
        await case('completed missing refs','DEMO,REQ-A,Check fictional source,Reviewer,critical,verified_complete,,',E,'COMPLETE_NO_EVIDENCE')
        await case('cross-project link',R,E.replace('DEMO,EV-A','OTHER,EV-A'),'CROSS_PROJECT_REFERENCE')
        await case('unverified evidence',R,E.replace(',verified,cleared,',',unknown,cleared,'),'SOURCE_UNVERIFIED')
        await case('restricted rights',R,E.replace(',cleared,synthetic_public',',restricted,synthetic_public'),'SOURCE_RIGHTS_HOLD')
        await case('sensitive source',R,E.replace('synthetic_public','private'),'SENSITIVE_SOURCE_HOLD')
        await case('invalid date',R,E.replace('2026-10-01','2026-02-31'),'INVALID_SOURCE_DATE')
        await case('invalid source kind',R,E.replace(',document,',',alien,'),'INVALID_SOURCE_KIND')
        await case('missing human owner',R.replace('Reviewer,critical',',critical'),E,'NO_REVIEW_OWNER')
        await case('unknown status',R.replace('verified_complete','finished'),E,'INVALID_STATUS')
        await case('duplicate support reference',R.replace('EV-A,','EV-A;EV-A,'),E,'REPEATED_REFERENCE')
        await case('duplicate evidence rows',R,E+'\n'+E,'AMBIGUOUS_EVIDENCE_ID')
        await case('N/A must be reviewed','DEMO,REQ-A,Fictional exception,Reviewer,normal,not_applicable,,documented reason',E,'NOT_APPLICABLE_SIGNOFF',expect_hold=False)
        await case('N/A without reason', 'DEMO,REQ-A,Fictional exception,Reviewer,normal,not_applicable,,',E,'NOT_APPLICABLE_NO_RATIONALE',expect_hold=False)
        await case('CSV formula-looking ID protected', 'DEMO,-7,Fictional exception,Reviewer,normal,open,,',E,'OPEN_REQUIREMENT',expect_hold=False)
        async with page.expect_download() as d: await page.click('#csvexport')
        content=pathlib.Path(await (await d.value).path()).read_text()
        check('CSV export neutralizes risky ID',"'-7" in content,content[:400])
        # Properly escaped quotes and embedded newline are parsed without formula evaluation or leaking source body.
        await case('quoted CSV fields with newline', 'DEMO,REQ-A,"Fictional row, with a \nnewline and ""quote""",Reviewer,normal,verified_complete,EV-A,',E,None,False)
        await page.fill('#reqcsv',RH+'\nDEMO,REQ-A,"unclosed,Reviewer,normal,verified_complete,EV-A,')
        await page.click('#audit')
        check('malformed quoted CSV fails closed', 'INPUT INVALID' in await page.locator('#status').inner_text() and await page.locator('#csvexport').is_disabled())
        await page.fill('#reqcsv',RH+'\n'+R)
        await page.fill('#evcsv',EH+'\n'+E)
        await page.click('#audit')
        await page.fill('#evcsv',EH+'\n'+E+'\n')
        check('text edit invalidates export',await page.locator('#csvexport').is_disabled() and 'Not audited' in await page.locator('#status').inner_text())
        # Real file import: local fictitious CSV, then one click; tool does not fetch a server.
        await page.locator('#reqfile').set_input_files(str(ROOT/'examples'/'evidence_requirements_fictional.csv'))
        await page.locator('#evfile').set_input_files(str(ROOT/'examples'/'evidence_index_fictional.csv'))
        await page.wait_for_function("document.getElementById('reqcsv').value.includes('REQ-01')")
        await page.click('#audit')
        check('file import and audit',await page.locator('#mreq').inner_text()=='4')
        # Duplicate headers should fail, not silently pick one.
        await page.fill('#reqcsv',RH.replace('item_id,','project_id,')+'\n'+R)
        await page.click('#audit')
        check('bad columns rejected',await page.locator('#csvexport').is_disabled() and 'exact ordered columns' in await page.locator('#err').inner_text())
        check('no browser page exceptions',not errors,errors)
        check('no requests or network activity',not network,network)
        await browser.close()
try:
    asyncio.run(main())
except Exception as exc:
    RESULTS.append({'test':'uncaught','pass':False,'detail':str(exc)+'\n'+traceback.format_exc()})
finally:
    result={'test_count':len(RESULTS),'passed':sum(x['pass'] for x in RESULTS),'failed':sum(not x['pass'] for x in RESULTS),'results':RESULTS,'environment':'Headless Chromium in-memory HTML with inline common.js + styles.css; not independent file:// host acceptance'}
    (ROOT/'tests'/'evidence_test_results.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({k:result[k] for k in ('test_count','passed','failed')}))
    for x in RESULTS:
        if not x['pass']: print('FAIL',x)
    if result['failed']: raise SystemExit(1)
