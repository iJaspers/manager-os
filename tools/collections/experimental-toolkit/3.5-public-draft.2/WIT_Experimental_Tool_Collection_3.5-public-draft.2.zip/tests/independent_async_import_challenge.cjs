'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const root=path.resolve(process.argv[2]),out=path.resolve(process.argv[3]);
const configs=JSON.parse(fs.readFileSync(path.join(root,'tests/async_import_configs.json'))),results=[],hashes={};
function test(app,name,fn){try{fn();results.push({app,name,pass:true})}catch(e){results.push({app,name,pass:false,error:String(e.message)})}}
function boot(file){const html=fs.readFileSync(path.join(root,file),'utf8'),nodes=new Map(),captures=[];const dec=s=>s.replaceAll('&gt;','>').replaceAll('&lt;','<').replaceAll('&amp;','&').replaceAll('&quot;','"');
 function el(id=''){return {id,value:'',textContent:'',disabled:false,checked:false,files:[],children:[],handlers:{},classList:{add(){},remove(){},toggle(){}},addEventListener(k,f){(this.handlers[k]??=[]).push(f)},click(){return Promise.all((this.handlers.click||[]).map(f=>f.call(this,{target:this,currentTarget:this})))},replaceChildren(){this.children=[]},append(...v){this.children.push(...v)},appendChild(v){this.children.push(v)},remove(){},setAttribute(){}}}
 const doc={getElementById(id){if(!nodes.has(id))nodes.set(id,el(id));return nodes.get(id)},createElement:()=>el(),querySelectorAll(){return[]},body:el()};
 for(const m of html.matchAll(/<(input|textarea|select|button)\b([^>]*)>([\s\S]*?)(?:<\/(?:textarea|select|button)>|(?=<))/g)){} // explicit parsing below
 for(const m of html.matchAll(/<input\b[^>]*>/g)){let id=m[0].match(/\bid="([^"]+)"/);if(!id)continue;let n=doc.getElementById(id[1]);n.value=dec(m[0].match(/\bvalue="([^"]*)"/)?.[1]||'');n.checked=/\bchecked\b/.test(m[0]);n.type=m[0].match(/\btype="([^"]*)"/)?.[1]||'text';}
 for(const m of html.matchAll(/<textarea\b[^>]*id="([^"]+)"[^>]*>([\s\S]*?)<\/textarea>/g))doc.getElementById(m[1]).value=dec(m[2]);
 for(const m of html.matchAll(/<select\b[^>]*id="([^"]+)"[^>]*>([\s\S]*?)<\/select>/g)){const opts=[...m[2].matchAll(/<option([^>]*)>([^<]*)<\/option>/g)],v=opts.find(v=>/selected/.test(v[1]))||opts[0];if(v)doc.getElementById(m[1]).value=v[1].match(/value="([^"]+)"/)?.[1]||v[2];}
 const ctx=vm.createContext({document:doc,TextEncoder,TextDecoder,File,Blob,Uint8Array,ArrayBuffer,setTimeout(){},clearTimeout(){},capture:(...x)=>captures.push(x)},{codeGeneration:{strings:false,wasm:false}});
 for(const m of html.matchAll(/<script([^>]*)>([\s\S]*?)<\/script>/g)){
  const src=m[1].match(/src="([^"]+)"/);let code=src?fs.readFileSync(path.join(root,src[1]),'utf8'):m[2];if(src){hashes[src[1]]=crypto.createHash('sha256').update(code).digest('hex');}
  vm.runInContext(code,ctx,{timeout:2000});if(src&&src[1]==='common.js')vm.runInContext('downloadText=(...x)=>capture(...x)',ctx);
 }
 hashes[file]=crypto.createHash('sha256').update(html).digest('hex');
 const emit=(id,type)=>{let n=doc.getElementById(id);return Promise.all((n.handlers[type]||[]).map(f=>f.call(n,{target:n,currentTarget:n})));};
 return {nodes,ctx,emit,captures,run:s=>vm.runInContext(s,ctx,{timeout:2000})};
}
function deferred(raw='h\nFAKE_NEW'){let resolve,reject;const p=new Promise((r,j)=>{resolve=r;reject=j});return {file:{name:'fictional.csv',size:Buffer.byteLength(raw),text:()=>p},resolve:()=>resolve(raw),reject:()=>reject(new Error('FAKE delayed failure'))};}
function snap(a){return [...a.nodes].map(([id,n])=>[id,n.value,n.textContent,n.disabled]);}
async function start(a,input,d){a.nodes.get(input).files=[d.file];a.nodes.get(input).value='selected.csv';return a.emit(input,'change');}
(async()=>{
for(const [num,c] of Object.entries(configs)){
 const file=fs.readdirSync(root).find(f=>f.startsWith(num.padStart(2,'0')+'_')&&f.endsWith('.html'));
 let a;try{a=boot(file)}catch(e){results.push({app:num,name:'boot',pass:false,error:String(e)});continue}
 const exp=()=>[...a.nodes].filter(([k,n])=>/export/i.test(k)&&n.handlers.click?.length);
 const disabled=()=>exp().every(([k,n])=>n.disabled);
 const fresh=()=>{a=boot(file)};
 for(const [input,area] of c.pairs){
  fresh();const old=deferred('h\nFAKE_OLD'),newer=deferred('h\nFAKE_NEW');let p1=start(a,input,old),p2=start(a,input,newer);newer.resolve();await p2;const before=snap(a);old.resolve();await p1;
  test(num,area+' latest success wins reverse completion',()=>assert.equal(a.nodes.get(area).value,'h\nFAKE_NEW'));
  test(num,area+' stale success leaves all UI unchanged',()=>assert.deepEqual(snap(a),before));
  fresh();let slow=deferred('h\nFAKE_OLD'),waiting=deferred('h\nFAKE_NEW');let oldP=start(a,input,slow),newP=start(a,input,waiting);const whileNewPending=snap(a);slow.resolve();await oldP;
  test(num,area+' old finally cannot clear newer selection or pending UI',()=>assert.deepEqual(snap(a),whileNewPending));
  if(c.calculate)a.run(c.calculate+'()');else await a.emit('review','click');test(num,area+' forward stale completion still blocks calculation',()=>assert.ok(disabled()));waiting.resolve();await newP;
  fresh();let bad=deferred('h\nFAKE_BAD'),good=deferred('h\nFAKE_GOOD');p1=start(a,input,bad);p2=start(a,input,good);good.resolve();await p2;const beforeError=snap(a);bad.reject();await p1;
  test(num,area+' stale rejection leaves all UI unchanged',()=>assert.deepEqual(snap(a),beforeError));
  fresh();let d=deferred(),p=start(a,input,d);test(num,area+' exports disabled while pending',()=>assert.ok(disabled()));
  if(c.calculate)a.run(c.calculate+'()');else await a.emit('review','click');
  test(num,area+' calculate blocked while pending',()=>assert.ok(disabled()));
  for(const [id]of exp())await a.emit(id,'click');test(num,area+' forced export handlers cannot download pending data',()=>assert.equal(a.captures.length,0));
  a.nodes.get(area).value='h\nFAKE_MANUAL';await a.emit(area,'input');const manual=snap(a);d.resolve();await p;
  test(num,area+' manual input wins',()=>assert.equal(a.nodes.get(area).value,'h\nFAKE_MANUAL'));
  test(num,area+' late completion after manual edit no UI change',()=>assert.deepEqual(snap(a),manual));
  fresh();d=deferred();p=start(a,input,d);a.nodes.get(area).value='h\nFAKE_CHANGE_EVENT';await a.emit(area,'change');d.resolve();await p;test(num,area+' change event cancels prior read',()=>assert.equal(a.nodes.get(area).value,'h\nFAKE_CHANGE_EVENT'));
  fresh();d=deferred();p=start(a,input,d);a.nodes.get(input).files=[];await a.emit(input,'change');const cancel=snap(a);d.resolve();await p;test(num,area+' empty selection supersedes pending read',()=>assert.deepEqual(snap(a),cancel));
  fresh();d=deferred();p=start(a,input,d);a.nodes.get(input).files=[{name:'huge.csv',size:99999999,text(){throw Error('oversize must not read')}}];await a.emit(input,'change');const huge=snap(a);d.resolve();await p;test(num,area+' oversized selection supersedes pending read',()=>assert.deepEqual(snap(a),huge));
  fresh();d=deferred();p=start(a,input,d);const demo=[...a.nodes].find(([id,n])=>/^(demo|sample)/i.test(id)&&n.handlers.click?.length);if(demo){await a.emit(demo[0],'click');const demoSnap=snap(a);d.resolve();await p;test(num,area+' demo wins over pending read',()=>assert.deepEqual(snap(a),demoSnap));}else {d.resolve();await p;}
 }

 // All non-data configuration inputs must cancel obsolete reads, but not be overwritten.
 fresh();const controls=[...a.nodes].filter(([id,n])=>n.handlers.input?.length&&n.type!=='file'&&!c.pairs.some(v=>v[1]===id));
 for(const [control] of controls){
  for(const outcome of ['success','failure']){
   fresh();const [inp,area]=c.pairs[0],d=deferred('h\nFAKE_OBSOLETE');const p=start(a,inp,d);
   a.nodes.get(control).value+=' CHANGED';await a.emit(control,'input');const before=snap(a);
   if(outcome==='success')d.resolve();else d.reject();await p;
   test(num,control+' configuration edit cancels stale '+outcome,()=>assert.deepEqual(snap(a),before));
  }
 }
 // A completed valid import must not leave the app stuck in a pending guard.
 fresh();if(c.calculate)a.run(c.calculate+'()');else await a.emit('review','click');const beforeExports=exp().map(([k,n])=>[k,n.disabled]);
 const [recoveryInput,recoveryArea]=c.pairs[0],valid=deferred(a.nodes.get(recoveryArea).value);const recoveryPromise=start(a,recoveryInput,valid);valid.resolve();await recoveryPromise;
 if(c.calculate)a.run(c.calculate+'()');else await a.emit('review','click');
 test(num,'same valid data recovers prior export eligibility after completion',()=>assert.deepEqual(exp().map(([k,n])=>[k,n.disabled]),beforeExports));
 if(c.pairs.length>1){
  fresh();const [one,two]=c.pairs,d1=deferred('h\nFAKE_LEFT'),d2=deferred('h\nFAKE_RIGHT');const p1=start(a,one[0],d1),p2=start(a,two[0],d2);d1.resolve();await p1;
  if(c.calculate)a.run(c.calculate+'()');else await a.emit('review','click');test(num,'one side completed does not unlock pending other side',()=>assert.ok(disabled()));d2.resolve();await p2;
  test(num,'different sides complete independently',()=>{assert.equal(a.nodes.get(one[1]).value,'h\nFAKE_LEFT');assert.equal(a.nodes.get(two[1]).value,'h\nFAKE_RIGHT')});
  fresh();const x=deferred('h\nFAKE_LEFT'),y=deferred('h\nFAKE_RIGHT');const px=start(a,one[0],x),py=start(a,two[0],y);a.nodes.get(one[1]).value='h\nFAKE_MANUAL_LEFT';await a.emit(one[1],'input');y.resolve();await py;x.resolve();await px;
  test(num,'manual one-side edit preserves independent other-side read',()=>{assert.equal(a.nodes.get(one[1]).value,'h\nFAKE_MANUAL_LEFT');assert.equal(a.nodes.get(two[1]).value,'h\nFAKE_RIGHT')});
 }
}
const report={scope:'Independent all-changed-app controlled-promise event-listener tests in minimal Node DOM; not real browser',source_hashes:hashes,apps:Object.keys(configs).length,tests:results.length,passed:results.filter(x=>x.pass).length,failed:results.filter(x=>!x.pass).length,results};fs.writeFileSync(out,JSON.stringify(report,null,2));console.log(JSON.stringify({apps:report.apps,tests:report.tests,passed:report.passed,failed:report.failed,failures:results.filter(x=>!x.pass)},null,2));process.exitCode=report.failed?1:0;
})().catch(e=>{console.error(e);process.exitCode=1});
