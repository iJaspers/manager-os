"""Only synthetic-input Chromium in-memory regression; not independent extracted desktop/mobile/browser acceptance."""
import asyncio, csv, io, pathlib, json, copy, traceback
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=ROOT/'tests/solution_tradeoff_test_results.json'
checks=[]
def check(name,result,detail=''):
    x={'test':name,'passed':bool(result),'detail':str(detail)[:150]}
    checks.append(x)
    print(('PASS' if result else 'FAIL')+' '+name,flush=True)
    if not result:raise AssertionError(name+': '+str(detail))
def rows(data):return list(csv.reader(io.StringIO(data)))
def txt(rows):
    buff=io.StringIO();writer=csv.writer(buff,lineterminator='\n');writer.writerows(rows);return buff.getvalue()
C=rows((ROOT/'examples/solution_criteria_fictional.csv').read_text())
O=rows((ROOT/'examples/solution_options_complete_fictional.csv').read_text())
A=rows((ROOT/'examples/solution_assessments_complete_fictional.csv').read_text())
async def run():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
  page=await browser.new_page(accept_downloads=True)
  errors=[];requests=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:requests.append(r.url))
  html=(ROOT/'23_Solution_Tradeoff_Review.html').read_text().replace('<link rel="stylesheet" href="styles.css">','<style>'+(ROOT/'styles.css').read_text()+'</style>').replace('<script src="common.js"></script>','<script>'+(ROOT/'common.js').read_text()+'</script>')
  await page.set_content(html,wait_until='load')
  async def value(id):return (await page.locator('#'+id).inner_text()).strip()
  async def apply(c=C,o=O,a=A):
    await page.fill('#criteria',txt(c) if isinstance(c,list) else c)
    await page.fill('#options',txt(o) if isinstance(o,list) else o)
    await page.fill('#assessments',txt(a) if isinstance(a,list) else a)
    await page.click('#review')
  async def down(id):
   async with page.expect_download() as d:await page.click('#'+id)
   obj=await d.value
   return obj.suggested_filename,pathlib.Path(await obj.path()).read_text()
  async def blocked(word):
   e=await value('error');check('rejected '+word, 'INPUT BLOCKED' in await value('status') and word.lower() in e.lower() and await page.locator('#exportTXT').is_disabled(),e)
  check('default demo seeded two fictional options',await value('mOptions')=='2')
  check('default blocks cheap unsafe patch','BLOCK' in await value('status') and 'OPT-PATCH' in await value('overview'))
  risks=await value('findings')
  for code in ['HARD_CONSTRAINT_FAILED','RIGHTS_UNCERTAIN','SECURITY_REVIEW_PENDING','PREFERENCE_UNPROVEN','PREFERENCE_NOT_MET','PREFERENCE_UNKNOWN']:
   check('demo finding '+code,code in risks)
  check('default blocked exactly one option',await value('mBlocked')=='1')
  name,data=await down('exportCSV');r=rows(data)
  check('findings export private',name.startswith('PRIVATE_FICTIONAL_'))
  check('findings export header',r[0]==['option_id','priority','issue_code','human_next_action'])
  check('findings CSV contains mandatory failed',any(a[0]=='OPT-PATCH' and a[2]=='HARD_CONSTRAINT_FAILED' for a in r[1:]))
  name,data=await down('exportTXT')
  check('review TXT private and unverified','PRIVATE / FICTIONAL' in data and 'NOT VERIFIED' in data and 'No winner' in data)
  name,data=await down('exportJSON');j=json.loads(data)
  check('counts only schema',j['schema']=='PD-SOLUTION-TRADEOFF-1' and j['distribution']=='PRIVATE_COUNTS_ONLY')
  check('JSON counts options 2 blocked 1',j['counts']['options']==2 and j['counts']['blockedOptions']==1)
  check('JSON no row labels/ids/source/cost',all(x not in data for x in ['OPT-PATCH','REQ-SAFE','SOURCE-A','COST-B','Safe replacement','650.00','EVID-D']))
  for key in ['independentSourcesVerified','solutionFeasibilityVerified','legalRightsVerified','securityVerified','costEstimatesVerified','clientApproved','purchaseAuthorized','permissionToPublish','revenueReceivedVerified']:
   check('JSON never attests '+key,j[key] is False)
  check('JSON insists on human decision',j['humanDecisionRequired'] is True)
  await page.click('#demoClean')
  check('complete demo has no blocked options',await value('mBlocked')=='0')
  check('clean still has unmet soft preference', 'PREFERENCE_NOT_MET' in await value('findings'))
  check('clean has 2 row-ready options',(await value('overview')).count('ROW-READY')==2)
  check('clean no recommendation','NO DECISION OR APPROVAL' in await value('status'))
  check('visible preference coverage 4/7 and 3/7','4/7' in await value('overview') and '3/7' in await value('overview'))
  _,data=await down('exportJSON');j=json.loads(data)
  check('complete JSON remains unverified',j['purchaseAuthorized'] is False and j['clientApproved'] is False)
  await page.fill('#options','');check('edit disables old exports',await page.locator('#exportCSV').is_disabled() and 'NOT REVIEWED' in await value('status'))
  # Risk/hold paths: each new case from clean clone
  async def mutate(table,row,col,value):
   c,o,a=copy.deepcopy((C,O,A));dest={'criteria':c,'options':o,'assessments':a}[table];dest[row][col]=value;await apply(c,o,a)
  for (col,new,issue) in [(4,'uncertain','RIGHTS_UNCERTAIN'),(4,'restricted','RIGHTS_RESTRICTED'),(5,'pending','SECURITY_REVIEW_PENDING'),(5,'stop','SECURITY_STOP'),(2,'','COST_NOT_SUBSTANTIATED'),(3,'','COST_NOT_SUBSTANTIATED')]:
   await mutate('options',1,col,new);check('isolated option issue '+issue,issue in await value('findings'))
  for (col,new,issue) in [(2,'not_met','HARD_CONSTRAINT_FAILED'),(2,'unknown','HARD_CONSTRAINT_UNKNOWN'),(3,'reported_only','HARD_PROOF_INSUFFICIENT'),(4,'','HARD_PROOF_INSUFFICIENT')]:
   await mutate('assessments',1,col,new);check('isolated hard issue '+issue,issue in await value('findings'))
  for (row,col,new,issue) in [(2,2,'unknown','PREFERENCE_UNKNOWN'),(2,3,'reported_only','PREFERENCE_UNPROVEN'),(2,4,'','PREFERENCE_UNPROVEN'),(3,2,'met',None)]:
   await mutate('assessments',row,col,new)
   if issue:check('isolated preference issue '+issue,issue in await value('findings'))
   else:check('met clears optional unmet issue','PREFERENCE_NOT_MET' not in (await value('findings')).split('OPT-REPLACE')[0])
  c,o,a=copy.deepcopy((C,O,A));a.pop(1);await apply(c,o,a);check('missing criterion-option pair is held','MISSING_ASSESSMENT' in await value('findings'))
  c,o,a=copy.deepcopy((C,O,A));a.append(copy.deepcopy(a[1]));await apply(c,o,a);await blocked('duplicate assessment pair')
  c,o,a=copy.deepcopy((C,O,A));a[1][0]='OPT-NOT-REAL';await apply(c,o,a);await blocked('unknown option')
  c,o,a=copy.deepcopy((C,O,A));a[1][1]='REQ-FAKE';await apply(c,o,a);await blocked('unknown option or criterion')
  # Semantic fail-closed inputs and injection shaped data
  badcriteria=[(1,0,'x','uppercase'),(1,1,'<img src=x onerror=alert(1)>','short fictional'),(1,2,'critical','priority'),(1,3,'5','weight'),(2,3,'0','weight'),(1,4,'https://source','uppercase')]
  for row,col,new,err in badcriteria:
   c,o,a=copy.deepcopy((C,O,A));c[row][col]=new;await apply(c,o,a);await blocked(err)
  badoptions=[(1,0,'*UNSAFE','uppercase'),(1,1,'site@example.com','short fictional'),(1,2,'-0.01','cost'),(1,2,'1.999','cost'),(1,2,'100000001.00','cost'),(1,2,'NaN','cost'),(1,3,'=1+1','synthetic'),(1,4,'clear','rights_state'),(1,5,'approved','security_state')]
  for row,col,new,err in badoptions:
   c,o,a=copy.deepcopy((C,O,A));o[row][col]=new;await apply(c,o,a);await blocked(err)
  badasses=[(1,2,'likely','fit'),(1,3,'verified','evidence_state'),(1,4,'+1','uppercase'),(1,4,'<script>','uppercase')]
  for row,col,new,err in badasses:
   c,o,a=copy.deepcopy((C,O,A));a[row][col]=new;await apply(c,o,a);await blocked(err)
  c,o,a=copy.deepcopy((C,O,A));a[1][3]='missing';await apply(c,o,a);await blocked('missing evidence')
  c,o,a=copy.deepcopy((C,O,A));o[2][0]=o[1][0];await apply(c,o,a);await blocked('duplicate option_id')
  c,o,a=copy.deepcopy((C,O,A));c[2][0]=c[1][0];await apply(c,o,a);await blocked('duplicate criterion_id')
  c,o,a=copy.deepcopy((C,O,A));c[1][2]='prefer';c[1][3]='1';await apply(c,o,a);await blocked('at least one must-have')
  await apply('junk');await blocked('exact 5-column')
  await apply(txt([C[0]]));await blocked('between 1 and')
  await apply(txt([C[0]]+C[1:]*36));await blocked('between 1 and')
  await apply(txt([C[0],C[1][:-1]]));await blocked('wrong column count')
  await apply(txt([C[0],C[1]])+'X'*76000);await blocked('75KB')
  await apply(txt(C),txt([O[0]]));await blocked('between 1 and')
  await apply(txt(C),txt(O),txt([A[0]]));await blocked('between 1 and')
  await apply(txt(C),txt(O),txt([A[0],A[1][:-1]]));await blocked('wrong column count')
  c,o,a=copy.deepcopy((C,O,A));c[1][1]='BAD\x01FIELD';await apply(c,o,a);await blocked('unsafe control')
  c,o,a=copy.deepcopy((C,O,A));c[1][1]='A'*151;await apply(c,o,a);await blocked('oversized field')
  await apply(txt(C),txt(O),txt(A)+'\n"broken');await blocked('unclosed quoted')
  # quoted multiline parser should parse but reject private linebreak label
  c,o,a=copy.deepcopy((C,O,A));c[1][1]='New\nLine';await apply(c,o,a);await blocked('short fictional')
  # Local import of user-selected (fictional) file. No network.
  await page.click('#demoClean')
  f=ROOT/'examples/solution_options_complete_fictional.csv'
  await page.set_input_files('#optionsFile',str(f))
  await asyncio.sleep(0.2)
  check('fictional CSV file import displays local rows','OPT-REPAIR' in await page.locator('#options').input_value())
  check('import invalidates previous result',await page.locator('#exportCSV').is_disabled())
  await page.click('#review');check('matching imported CSV is processed','OPT-REPAIR' in await value('overview'))
  f=ROOT/'examples/solution_options_mixed_fictional.csv'
  await page.set_input_files('#optionsFile',str(f))
  await asyncio.sleep(0.2)
  await page.click('#review');check('import of changed candidate mismatches safely blocked','unknown option or criterion' in (await value('error')).lower())
  await page.set_input_files('#optionsFile',{'name':'unsuitable.txt','mimeType':'text/plain','buffer':b'junk'})
  await blocked('only invented CSV')
  await page.click('#demoClean')
  c,o,a=copy.deepcopy((C,O,A));o[1][1]='=HYPERLINK';await apply(c,o,a)
  check('spreadsheet-formula shaped option name cannot appear raw','INPUT BLOCKED' in await value('status'))
  await page.click('#demoClean');check('no network traffic from normal workflow',not requests,requests)
  check('no browser script exceptions',not errors,errors)
  check('CSP connect denied',"connect-src 'none'" in html)
  check('tool has no storage APIs',not any(token in html for token in ('localStorage','sessionStorage','indexedDB','fetch(','XMLHttpRequest(')))
  await browser.close()
 try: OUT.write_text(json.dumps({'suite':'solution_tradeoff_browser_checks','checks':len(checks),'passed':len(checks),'failed':0,'in_memory_chromium':True,'real_customer_tested':False,'independent_desktop_tested':False,'published':False,'details':checks},indent=2))
 except:pass
if __name__=='__main__':
 try:asyncio.run(run())
 except Exception:
  OUT.write_text(json.dumps({'checks':len(checks),'passed':sum(t['passed'] for t in checks),'failed':sum(not t['passed'] for t in checks),'in_memory_chromium':True,'details':checks,'traceback':traceback.format_exc()},indent=2))
  traceback.print_exc();raise
