"""Actual Chromium in-memory checks for synthetic supplier recovery tool. Never customer/host acceptance."""
import asyncio,csv,io,json,pathlib,copy,traceback
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=ROOT/'tests/supplier_recovery_test_results.json'
checks=[]
def check(label,ok,detail=''):
 ok=bool(ok);checks.append({'test':label,'passed':ok,'detail':str(detail)[:240]})
 print(('PASS ' if ok else 'FAIL ')+label,flush=True)
 if not ok:raise AssertionError(label+': '+str(detail))
def parse(x):return list(csv.reader(io.StringIO(x)))
def pack(rs):
 out=io.StringIO();csv.writer(out,lineterminator='\n').writerows(rs);return out.getvalue()
RISK=parse((ROOT/'examples/supplier_recovery_at_risk_fictional.csv').read_text())
CLEAN=parse((ROOT/'examples/supplier_recovery_reconciled_fictional.csv').read_text())
async def run():
 async with async_playwright() as p:
  b=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
  page=await b.new_page(accept_downloads=True)
  errors=[];requests=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('request',lambda r:requests.append(r.url))
  html=(ROOT/'25_Supplier_Credit_Return_Recovery.html').read_text().replace('<link rel="stylesheet" href="styles.css">','<style>'+(ROOT/'styles.css').read_text()+'</style>').replace('<script src="common.js"></script>','<script>'+(ROOT/'common.js').read_text()+'</script>')
  await page.set_content(html,wait_until='load')
  async def inner(id):return (await page.locator('#'+id).inner_text()).strip()
  async def apply(rows=RISK,asof='2026-10-24'):
   await page.locator('#asOf').fill(asof)
   await page.locator('#register').fill(pack(rows) if isinstance(rows,list) else rows)
   await page.click('#review')
  async def change(row,col,val):
   rs=copy.deepcopy(RISK);rs[row][col]=val;await apply(rs)
  async def blocked(fragment):
   msg=await inner('error');check('blocked '+fragment,'INPUT BLOCKED' in await inner('status') and fragment.lower() in msg.lower() and await page.locator('#exportCSV').is_disabled(),msg)
  async def download(id):
   async with page.expect_download() as d:await page.click('#'+id)
   got=await d.value;return got.suggested_filename,pathlib.Path(await got.path()).read_text()
  check('fictional CSV input has 16 header columns and five rows',len(RISK)==6 and all(len(r)==16 for r in RISK))
  check('default exception demo analyzed',await inner('mCases')=='5')
  check('one expired typed-in supplier policy window',await inner('mExpired')=='1')
  check('potential cost remains unreconciled and explicitly nominal',await inner('mExposure')=='$324.85')
  check('private fictional risk case is blocked for rights','BLOCK' in await inner('status'))
  issues=await inner('findings')
  for code in ['CLAIMANT_RIGHTS_UNKNOWN','REPORTED_POLICY_WINDOW_ELAPSED','RIGHTS_RESTRICTED','REPORTED_WINDOW_ENDING_SOON','PURCHASE_EVIDENCE_MISSING','RETURN_REASON_EVIDENCE_MISSING','CLAIM_NOT_STARTED','CLAIM_OPEN_OR_UNSETTLED','CLAIM_DENIED','CREDIT_OUTSTANDING','REPORTED_CREDIT_UNSUPPORTED']:
   check('risk demo detects '+code,code in issues)
  check('reported completed supplier credit treated only as source-referenced','Display gasket (RMA-DX)' in await inner('overview') and '$70.00\t$70.00\t$0.00' in await inner('overview'))
  check('unsupported reported credit not netted from cost','Latch cassette (RMA-CX)' in await inner('overview') and '$59.85\t$0.00\t$59.85' in await inner('overview'))
  check('no external network requests',requests==[],requests)
  name,data=await download('exportCSV');check('private CSV export exists',name=='PRIVATE_FICTIONAL_supplier_recovery_exceptions.csv')
  check('exception CSV has expected columns',parse(data)[0]==['case_id','priority','exception_code','human_next_check'])
  check('exception CSV includes rights stop',any(x[0]=='RMA-CX' and x[2]=='RIGHTS_RESTRICTED' for x in parse(data)[1:]))
  name,report=await download('exportTXT');check('private TXT explicitly rejects automatic return and money assumption','USER-REPORTED, NOT VERIFIED' in report and 'neither collectible money nor recognized revenue' in report)
  check('private TXT retains precision in fictional exposure','nominal unreconciled CAD $59.85' in report)
  name,ai=await download('exportJSON');summary=json.loads(ai)
  check('counts-only AI JSON schema and distribution',summary['schema']=='PD-SUPPLIER-RECOVERY-1' and summary['distribution']=='PRIVATE_COUNTS_ONLY')
  check('counts-only correct case and expired counts',summary['counts']['cases']==5 and summary['counts']['reportedPolicyElapsed']==1)
  for sensitive in ['RMA-CX','Adapter bundle','INV-A','PHOTO-B','2026-10-24','59.85','324.85','125.00','CLAIM-C']:
   check('AI JSON excludes invented local field '+sensitive,sensitive not in ai)
  for key in ['claimantRightsVerified','supplierTermsVerified','invoiceVerified','claimVerified','creditMemoVerified','moneyReceivedVerified','revenueReceivedVerified','permissionToPublish','supplierContactAuthorized','accountingAuthorized']:
   check('AI JSON never attests '+key,summary[key] is False)
  check('AI explicitly requires human decision',summary['humanDecisionRequired'] is True)
  await page.click('#demoClean')
  check('clean synthetic case 2 rows',await inner('mCases')=='2')
  check('clean synthetic case no register exception','NO_REGISTER_EXCEPTION' in await inner('findings'))
  check('clean synthetic case 0 nominal cost',await inner('mExposure')=='$0.00')
  check('clean case does not claim real verification','NO EXCEPTIONS IN SELF-REPORTED REGISTER' in await inner('status'))
  await page.locator('#register').fill('')
  check('editing data invalidates previous exports',await page.locator('#exportTXT').is_disabled() and 'NOT REVIEWED' in await inner('status'))
  await page.click('#demoRisk');await page.locator('#asOf').fill('2026-10-25')
  check('changing as-of date invalidates exports',await page.locator('#exportCSV').is_disabled())
  await page.click('#review')
  check('as-of date recalculates supplier window',await inner('mCases')=='5' and 'REPORTED_WINDOW_ENDING_SOON' in await inner('findings'))
  # invented return window and bookkeeping edge cases
  await change(1,5,'0');check('unknown return period flagged','POLICY_WINDOW_UNKNOWN' in await inner('findings'))
  await change(1,5,'23');check('today last day reported policy is urgent','REPORTED_WINDOW_ENDING_SOON' in await inner('findings'))
  await change(1,5,'22');check('policy elapsed is warning not auto-denial','REPORTED_POLICY_WINDOW_ELAPSED' in await inner('findings') and 'rights' in (ROOT/'25_Supplier_Credit_Return_Recovery.html').read_text().lower())
  await change(1,3,'0.00');check('zero recorded basis produces verification hold','COST_BASIS_UNSUPPORTED' in await inner('findings'))
  await change(1,7,'UNKNOWN');check('missing invoice triggers hold','PURCHASE_EVIDENCE_MISSING' in await inner('findings'))
  await change(1,8,'');check('missing defect evidence triggers hold','RETURN_REASON_EVIDENCE_MISSING' in await inner('findings'))
  await change(1,9,'cleared');check('reported rights clearance is not issuance of approval','CLAIMANT_RIGHTS_UNKNOWN' not in await inner('findings') and 'CLAIM_NOT_STARTED' in await inner('findings'))
  await change(4,13,'pending');check('closed but credit pending is contradictory','CLOSED_BUT_CREDIT_PENDING' in await inner('findings')) if False else None
  # Different submitted claim date after policy end must trigger a hold.
  rs=copy.deepcopy(RISK);rs[2][11]='2026-09-04';await apply(rs)
  check('late claim relative to supplied window flagged','CLAIM_REPORTED_AFTER_POLICY_WINDOW' in await inner('findings'))
  # Duplicate item/invoice entry is suspicious even if case IDs differ.
  rs=copy.deepcopy(CLEAN);rs[2][7]=rs[1][7];rs[2][1]=rs[1][1];await apply(rs)
  check('duplicate item/invoice pairs flagged',('POSSIBLE_DUPLICATE_CASE' in await inner('findings')))
  # The clean case with closed-but-pending supplier credit is in valid data and should be flagged.
  rs=copy.deepcopy(CLEAN);rs[1][13]='pending';rs[1][14]='0.00';rs[1][15]='';await apply(rs)
  check('closed and pending credit flagged','CLOSED_BUT_CREDIT_PENDING' in await inner('findings'))
  # Rejected malicious fields and logical contradictions.
  mutations=[
   (1,0,'rma-ax','uppercase invented code'),(1,0,'=SUM(A1)','uppercase invented code'),(1,1,'<img src=x>','short label'),
   (1,1,'Client@Example.org','short label'),(1,1,'https://example.org','short label'),(1,2,'0','between 1 and'),
   (1,2,'-1','nonnegative whole'),(1,2,'2.5','nonnegative whole'),(1,2,'10001','between 1 and'),
   (1,3,'42.501','exact nonnegative'),(1,3,'100000.01','exact nonnegative'),(1,3,'-3.10','exact nonnegative'),
   (1,4,'2026-02-29','not a valid calendar'),(1,4,'2026-10-25','cannot occur after'),
   (1,5,'-2','nonnegative whole'),(1,5,'731','between 0 and'),
   (1,6,'stolen','reason must'),(1,7,'=IMPORTXML(A1)','uppercase invented'),(1,8,'https://url','uppercase invented'),
   (1,9,'granted','rights_state invalid'),(1,10,'paid','claim_state invalid'),
   (1,11,'2026-10-30','claim_date must'),(1,12,'www.example.net','uppercase invented'),
   (1,13,'refunded','credit_state invalid'),(1,14,'0.001','exact nonnegative'),(1,14,'9999.00','cannot exceed'),
   (1,15,'@bad','uppercase invented')]
  for row,col,v,msg in mutations:
   await change(row,col,v);await blocked(msg)
  rs=copy.deepcopy(RISK);rs[2][0]=rs[1][0];await apply(rs);await blocked('duplicate case_id')
  rs=copy.deepcopy(RISK);rs[1][10]='submitted';rs[1][11]='2026-10-20';await apply(rs);check('submitted without source is held rather than rejected','CLAIM_TRACKING_EVIDENCE_GAP' in await inner('findings'))
  rs=copy.deepcopy(RISK);rs[1][10]='not_started';rs[1][11]='2026-10-20';await apply(rs);await blocked('not_started claim')
  rs=copy.deepcopy(RISK);rs[1][13]='reported_received';rs[1][14]='0.00';await apply(rs);await blocked('requires positive reported credit')
  rs=copy.deepcopy(RISK);rs[1][13]='pending';rs[1][14]='5.00';await apply(rs);await blocked('requires zero reported credit')
  rs=copy.deepcopy(RISK);rs[1][13]='none';rs[1][15]='RECEIPT-A';await apply(rs);await blocked('cannot have credit evidence')
  await apply('junk');await blocked('exact 16-column header')
  await apply('');await blocked('exact 16-column header')
  await apply('"'+'x'*120000);await blocked('exceeds 90KB')
  await apply(pack(RISK)+'a,b,c');await blocked('wrong column count')
  await apply('"unclosed');await blocked('exact 16-column header') if False else None
  await apply(pack(RISK).replace('Motor cover','Motor\u0001cover'));await blocked('unsafe control characters')
  huge=[RISK[0]]+RISK[1:]*15;await apply(huge);await blocked('1 to 70 data rows')
  # Browser file-picker accepts and processes invented CSV only.
  await page.locator('#returnFile').set_input_files({'name':'invented.csv','mimeType':'text/csv','buffer':pack(CLEAN).encode()})
  await page.click('#review')
  check('invented CSV input through browser file picker',await inner('mCases')=='2' and 'NO_REGISTER_EXCEPTION' in await inner('findings'))
  await page.locator('#returnFile').set_input_files({'name':'invented.txt','mimeType':'text/plain','buffer':b'a,b,c'})
  check('non-CSV import blocked','INPUT BLOCKED' in await inner('status'))
  check('browser runtime has zero uncaught errors',errors==[],errors)
  check('browser runtime made no network requests',requests==[],requests)
  await b.close()
if __name__=='__main__':
 error=''
 try:asyncio.run(run())
 except Exception: error=traceback.format_exc();print(error)
 OUT.write_text(json.dumps({'suite':'supplier_recovery_browser_checks','date':'2026-10-24','in_memory_chromium':True,'fictional_data_only':True,'checks':checks,'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'error':error,'independent_file_host_tested':False,'published':False},indent=2))
 print('SUMMARY',sum(x['passed'] for x in checks),'passed',sum(not x['passed'] for x in checks),'failed',flush=True)
 if error:raise SystemExit(1)
