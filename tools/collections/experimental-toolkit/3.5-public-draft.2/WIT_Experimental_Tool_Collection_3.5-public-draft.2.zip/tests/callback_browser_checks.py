"""Real headless Chromium tests of the original synthetic Callback & Defect Review tool."""
import asyncio, csv, io, json, pathlib, traceback
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=[]
HEAD=['case_id','deliverable_ref','issue_summary','age_days','severity','scope_reported','policy_ref','evidence_ref','third_party_change','sensitive_system','stage']
BASE=['CASE-100','DELIV-100','Fictional template label mismatch','6','ROUTINE','IN_SCOPE_REPORTED','TERMS-100','TEST-100','NO_REPORTED','NO','NEW']
def check(label,ok,detail=''):
    ok=bool(ok);OUT.append({'test':label,'pass':ok,'detail':str(detail)[:400]});print(('PASS ' if ok else 'FAIL ')+label,flush=True)
    if not ok:raise AssertionError(label+' '+str(detail))
def serialize(rows):
    f=io.StringIO();csv.writer(f,lineterminator='\n').writerows(rows);return f.getvalue()
async def test():
  async with async_playwright() as pw:
    browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
    page=await browser.new_page(accept_downloads=True);page.set_default_timeout(8000)
    errors=[];requests=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:requests.append(r.url))
    html=(ROOT/'12_Callback_Defect_Triage.html').read_text().replace('<link rel="stylesheet" href="styles.css">','<style>'+(ROOT/'styles.css').read_text()+'</style>').replace('<script src="common.js"></script>','<script>'+(ROOT/'common.js').read_text()+'</script>')
    await page.set_content(html,wait_until='load')
    async def tx(s):return await page.locator('#'+s).inner_text()
    async def fill(rows):await page.fill('#casesCSV',serialize([HEAD]+rows));await page.click('#run')
    async def blocked(label,error_match=None):
       msg=await tx('err');check(label,'REVIEW BLOCKED' in await tx('status') and await page.locator('#outCSV').is_disabled() and (error_match is None or error_match in msg),msg)
    async def csv_output():
       async with page.expect_download() as info:await page.click('#outCSV')
       return pathlib.Path(await(await info.value).path()).read_text()
    async def ai_output():
       async with page.expect_download() as info:await page.click('#outJSON')
       return json.loads(pathlib.Path(await(await info.value).path()).read_text())
    check('five mixed demonstration cases',await tx('mCases')=='5')
    check('one safety/security stop',await tx('mStops')=='1')
    check('three non-safety holds',await tx('mHolds')=='3')
    check('one routine human-review candidate',await tx('mReview')=='1')
    check('one unverified resolution listed','1 reports of resolution' in await tx('findings'))
    check('no automated coverage or cause claim','no coverage, cause' in await tx('status'))
    table=await page.locator('#results tr').all_inner_texts()
    check('mixed demo first case eligible for human review only','ROUTINE_HUMAN_REVIEW' in table[0],table[0])
    check('mixed demo missing policy and source held','HOLD_CONTRACT_EVIDENCE' in table[1] and 'COVERAGE_TERMS_MISSING' in table[1] and 'EVIDENCE_MISSING' in table[1],table[1])
    check('safety escalated even when scope reported in','STOP_SAFETY_SECURITY' in table[2],table[2])
    check('reported closure never accepted','VERIFY_REPORTED_RESOLUTION' in table[3] and 'RESOLUTION_UNVERIFIED' in table[3],table[3])
    check('age over 365 prompts contract review not expiration','CHECK_CONTRACT_TIME_WINDOW' in table[3],table[3])
    check('third-party alteration and reported out-of-scope held','THIRD_PARTY_CHANGE_REPORTED' in table[4] and 'SCOPE_OUT_REPORTED_ONLY' in table[4],table[4])
    check('no JavaScript errors',not errors,errors)
    check('no external network requests',not requests,requests)
    check('outputs unlocked for structurally valid input',all([await page.locator('#'+s).is_enabled() for s in ['outCSV','outTXT','outJSON']]))
    raw=await csv_output();parsed=list(csv.reader(io.StringIO(raw)))
    check('CSV has all cases and 13 columns',len(parsed)==6 and len(parsed[0])==13 and all(len(x)==13 for x in parsed[1:]))
    check('CSV calls fields reported and nonverified','policy_ref_UNVERIFIED' in parsed[0] and 'stage_REPORTED' in parsed[0])
    check('CSV includes human review gate and flags','STOP_SAFETY_SECURITY' in raw and 'RESOLUTION_UNVERIFIED' in raw)
    async with page.expect_download() as info:await page.click('#outTXT')
    brief=pathlib.Path(await(await info.value).path()).read_text()
    check('TXT forbids unauthorized contact and work','No contacting, repair, access' in brief)
    check('TXT explicitly separates reported age from legal warranty','Never infer a warranty expiration from age' in brief)
    check('TXT carries original private text','Fictional export missing a column' in brief)
    ai=await ai_output();j=json.dumps(ai)
    check('counts-only JSON uses schema and counts',ai['schema']=='PD-CALLBACK-1' and ai['caseCount']==5 and ai['otherHoldCount']==3)
    check('counts-only JSON does not leak any identifiers or descriptions',not any(x in j for x in ['CASE-001','DELIV-02','Fictional site system','TERMS-01','TEST-04','DEMO-HELPDESK']))
    check('all authorization and verification flags false',all(ai[k] is False for k in ['reportedScopeVerified','contractTermsVerified','warrantyOrLiabilityDecided','reportedResolutionVerified','safetyClearanceVerified','customerContactAuthorized','systemAccessAuthorized','workOrRepairAuthorized','refundOrPaymentAuthorized','privateUploadAuthorized','publicReleaseAuthorized','instructionAuthority']))
    await page.fill('#project','Modified synthetic project')
    check('edits disable stale exports',await page.locator('#outCSV').is_disabled() and 'INPUTS CHANGED' in await tx('status'))
    await page.click('#run')
    check('re-review enables exports',await page.locator('#outCSV').is_enabled())
    await page.click('#cleanDemo')
    check('clean synthetic case reaches only human review',await tx('mCases')=='1' and await tx('mHolds')=='0' and await tx('mReview')=='1')
    clean=await page.locator('#results tr').first.inner_text()
    check('review status does not assert authorization','ROUTINE_HUMAN_REVIEW' in clean and 'NO_STRUCTURAL_HOLD' in clean)
    test_row=BASE.copy();test_row[4]='URGENT';await fill([test_row])
    check('urgent clean case triggers manual priority review',await tx('mReview')=='1' and 'PRIORITY_HUMAN_REVIEW' in await page.locator('#results tr').first.inner_text())
    test_row=BASE.copy();test_row[9]='YES';await fill([test_row])
    check('sensitive system overrides benign severity',await tx('mStops')=='1' and 'STOP_SAFETY_SECURITY' in await page.locator('#results tr').first.inner_text())
    test_row=BASE.copy();test_row[4]='SAFETY';test_row[10]='CLOSED_REPORTED';await fill([test_row])
    check('safety stop outranks claimed closed status',await tx('mStops')=='1' and 'RESOLUTION_UNVERIFIED' in await page.locator('#results tr').first.inner_text())
    test_row=BASE.copy();test_row[10]='CLOSED_REPORTED';await fill([test_row])
    check('closed self-report requires validation',await tx('mHolds')=='1' and 'VERIFY_REPORTED_RESOLUTION' in await page.locator('#results tr').first.inner_text())
    test_row=BASE.copy();test_row[7]='NONE';await fill([test_row])
    check('source missing holds even in reported in-scope complaint',await tx('mHolds')=='1' and 'EVIDENCE_MISSING' in await page.locator('#results tr').first.inner_text())
    test_row=BASE.copy();test_row[6]='NONE';await fill([test_row])
    check('missing signed coverage term reference holds',await tx('mHolds')=='1' and 'COVERAGE_TERMS_MISSING' in await page.locator('#results tr').first.inner_text())
    test_row=BASE.copy();test_row[8]='YES_REPORTED';await fill([test_row])
    check('third-party modification requires manual review',await tx('mHolds')=='1' and 'THIRD_PARTY_CHANGE_REPORTED' in await page.locator('#results tr').first.inner_text())
    test_row=BASE.copy();test_row[5]='UNKNOWN';await fill([test_row])
    check('unknown scope held rather than covered',await tx('mHolds')=='1' and 'SCOPE_UNKNOWN' in await page.locator('#results tr').first.inner_text())
    test_row=BASE.copy();test_row[3]='366';await fill([test_row])
    check('365+ day case held for terms check not automatically denied',await tx('mHolds')=='1' and 'CHECK_CONTRACT_TIME_WINDOW' in await page.locator('#results tr').first.inner_text())
    test_row=BASE.copy();test_row[3]='365';await fill([test_row])
    check('365-day case no fabricated annual warranty cutoff',await tx('mReview')=='1' and 'CHECK_CONTRACT_TIME_WINDOW' not in await page.locator('#results tr').first.inner_text())
    # Malformed inputs: all fail closed with export disabled.
    await fill([]);await blocked('empty CSV blocked')
    await page.fill('#casesCSV','wrong,header\nCASE-100,DELIV-100,hello');await page.click('#run');await blocked('incorrect CSV header blocked','exact columns')
    await fill([BASE,BASE]);await blocked('duplicate case ID blocked','duplicate case ID')
    for idx,value,label in [(0,'A','case ID too short'),(0,'#bad','invalid case ID'),(1,'!bad','invalid deliverable ID'),(2,'bad','issue summary too short'),(3,'-1','negative age'),(3,'1.5','fractional age'),(3,'036','zero-padded age'),(3,'3651','age over model limit'),(4,'UNKNOWN','unsupported severity'),(5,'IN_SCOPE','invalid reported scope'),(6,'$BAD','invalid policy reference'),(7,'..','invalid evidence ref'),(8,'UNVERIFIED','invalid change status'),(9,'SOMETIMES','invalid sensitive-system flag'),(10,'ACCEPTED','invalid case stage')]:
       row=BASE.copy();row[idx]=value;await fill([row]);await blocked(label)
    await page.fill('#casesCSV','case_id,deliverable_ref,issue_summary,age_days,severity,scope_reported,policy_ref,evidence_ref,third_party_change,sensitive_system,stage\n"unclosed');await page.click('#run');await blocked('unclosed quote blocked','Unclosed quoted field')
    row=BASE.copy();row[2]='Line1\x01Line2 invalid';await fill([row]);await blocked('embedded control character blocked')
    row=BASE.copy();row[2]='x'*181;await fill([row]);await blocked('oversize summary blocked')
    rows=[BASE.copy() for _ in range(81)];
    for i,row in enumerate(rows):row[0]=f'CASE-{i+200}'
    await fill(rows);await blocked('81 cases blocked')
    rows=[BASE.copy() for _ in range(80)];
    for i,row in enumerate(rows):row[0]=f'CASE-{i+200}'
    await fill(rows);check('80-case boundary accepted',await tx('mCases')=='80')
    await page.fill('#casesCSV','case_id,deliverable_ref,issue_summary,age_days,severity,scope_reported,policy_ref,evidence_ref,third_party_change,sensitive_system,stage\n'+'x'*132000);await page.click('#run');await blocked('128 KiB capacity guarded','exceeds 128 KiB')
    # XSS literal only, and exported CSV is protected from spreadsheet formulas.
    row=BASE.copy();row[2]='<img src=x onerror=alert(1)> =cmd';await fill([row])
    check('markup rendered as literal text, no injected image',await page.locator('#results img').count()==0 and '<img' in await page.locator('#results tr').first.inner_text())
    row=BASE.copy();row[2]='=HYPERLINK("https://bad.invalid")';await fill([row]);csvdata=await csv_output();d=list(csv.reader(io.StringIO(csvdata)))
    check('CSV spreadsheet formula injection escaped',d[1][2].startswith("'="),d[1][2])
    check('no injected popup, no JS errors or network access',not errors and not requests,(errors,requests))
    await page.click('#cleanDemo')
    # Actual upload event is supported by browser in-memory host.
    fake=serialize([HEAD,BASE]).encode();await page.locator('#inputFile').set_input_files({'name':'callback_fictional.csv','mimeType':'text/csv','buffer':fake})
    check('browser local CSV import reads fictional data', 'CASE-100' in await page.locator('#casesCSV').input_value())
    check('file changes invalidate prior results',await page.locator('#outCSV').is_disabled())
    await page.click('#run');check('file-import case analyzes',await tx('mCases')=='1')
    await page.locator('#inputFile').set_input_files({'name':'huge.csv','mimeType':'text/csv','buffer':b'X'*132000})
    check('large local file denied without stale export', 'exceeds 128 KiB' in await tx('err') and await page.locator('#outCSV').is_disabled())
    await browser.close()

async def main():
 try:await test()
 except Exception:
   traceback.print_exc()
   raise
 finally:
   path=ROOT/'tests/callback_test_results.json';path.write_text(json.dumps({'passed':sum(x['pass'] for x in OUT),'total':len(OUT),'all_pass':all(x['pass'] for x in OUT),'tests':OUT},indent=2)+'\n')
   print('SUMMARY:',sum(x['pass'] for x in OUT),'/',len(OUT),flush=True)
if __name__=='__main__':asyncio.run(main())
