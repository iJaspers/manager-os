"""Chromium local-source in-memory checks of the *new* offline intake tool.

Run `python tests/triage_browser_checks.py`. A real file:// or deployment install
is NOT tested by in-memory page.set_content. No remote requests or client data.
"""
import asyncio
import json
from pathlib import Path
import sys
import traceback
from playwright.async_api import async_playwright

ROOT=Path(__file__).resolve().parents[1]
RESULTS=[]


def check(name, condition, detail=''):
    RESULTS.append(dict(name=name,passed=bool(condition),detail=detail))
    if not condition:
        raise AssertionError(f'{name}: {detail}')


async def main():
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        page=await browser.new_page(accept_downloads=True)
        requested=[]
        page.on('request',lambda req:requested.append(req.url))
        html=(ROOT/'04_Customer_Problem_Intake_Triage.html').read_text(encoding='utf-8')
        html=html.replace('<link rel="stylesheet" href="styles.css">','<style>'+(ROOT/'styles.css').read_text(encoding='utf-8')+'</style>')
        html=html.replace('<script src="common.js"></script>','<script>'+(ROOT/'common.js').read_text(encoding='utf-8')+'</script>')
        await page.set_content(html,wait_until='load')
        status=page.locator('#status')
        async def run():
            await page.locator('#triage').click()
            return await status.inner_text()
        async def put(id,value):
            await page.locator('#'+id).select_option(value)
            return await run()
        async def reset():
            # reset all inputs to default intentionally benign synthetic scenario
            await page.evaluate('''() => {
              const values={alias:'Fictional inventory work', timebox:'5 business days after approved input', problem:'Two fictional CSVs have inconsistent tags',inputs:'Two invented CSV tables', deliverable:'Exception report and stable mapping',acceptance:'Every example row accounted for and exceptions flagged',exclusions:'No production system or legal/safety certification',rights:'yes',public:'yes',nda:'no',exclusive:'no',data:'synthetic',credentials:'no',thirdparty:'original',highstakes:'no',supplied:'yes',worktype:'routine'};
              for (const [id,value] of Object.entries(values)) { const node=document.getElementById(id);node.value=value;node.dispatchEvent(new Event('input',{bubbles:true}));node.dispatchEvent(new Event('change',{bubbles:true})); }
            }''')
            return await run()

        check('initial example is human-review draft','HUMAN_REVIEW_REQUIRED' in await status.inner_text())
        check('initial hard stops zero',(await page.locator('#hardcount').inner_text())=='0')
        check('initial holds zero',(await page.locator('#holdcount').inner_text())=='0')
        check('initial clarifications zero',(await page.locator('#askcount').inner_text())=='0')
        check('normal review explicitly prohibits automatic acceptance','NO CLIENT COMMITMENT' in await page.locator('#report').inner_text())
        check('no background network requests',not requested,str(requested))
        async with page.expect_download() as d:
            await page.locator('#exportjson').click()
        dl=await d.value
        obj=json.loads(Path(await dl.path()).read_text(encoding='utf-8'))
        check('json export filename',dl.suggested_filename=='problem_intake_data_contract_DRAFT.json')
        check('json contract schema and stage',obj.get('schema')=='PD-INTAKE-1' and obj['reviewState'].startswith('DRAFT_SCOPE_READY'))
        check('json is not an authorization',all(obj.get(k) is False for k in ['customerAccepted','clientAgreementSigned','paymentRequested','paymentReceivedVerified','publicReleaseApproved','externalSubmissionPerformed']))
        check('json includes proposed acceptance test','Every example source row' in obj['requesterReportedInputs']['acceptance'])
        async with page.expect_download() as d:
            await page.locator('#exporttxt').click()
        dl=await d.value
        text=Path(await dl.path()).read_text(encoding='utf-8')
        check('text filename and explicit review',dl.suggested_filename.endswith('DRAFT.txt') and 'NEXT HUMAN ACTION:' in text)
        check('no customer/legal commitment in text','not an accepted contract' in text.lower())
        check('no network after exports',not requested,str(requested))

        await reset()
        check('NDA requirement rejects', (await put('nda','yes')).startswith('UNFIT_FOR_CURRENT_SERVICE'))
        await reset()
        check('exclusivity requirement rejects', (await put('exclusive','yes')).startswith('UNFIT_FOR_CURRENT_SERVICE'))
        await reset()
        check('public reuse prohibited rejects',(await put('public','no')).startswith('UNFIT_FOR_CURRENT_SERVICE'))
        await reset()
        check('known missing source rights rejects',(await put('rights','no')).startswith('UNFIT_FOR_CURRENT_SERVICE'))
        await reset()
        check('prohibited task rejects',(await put('worktype','prohibited')).startswith('UNFIT_FOR_CURRENT_SERVICE'))
        await reset()
        check('unauthorized thirdparty reuse rejects',(await put('thirdparty','no')).startswith('UNFIT_FOR_CURRENT_SERVICE'))
        await reset()
        check('unknown source ownership holds',(await put('rights','unknown')).startswith('HOLD'))
        await reset()
        check('uncertain thirdparty license holds',(await put('thirdparty','unknown')).startswith('HOLD'))
        await reset()
        check('thirdparty claimed commercial licence still holds',(await put('thirdparty','licensed')).startswith('HOLD'))
        await reset()
        check('private business records hold',(await put('data','private')).startswith('HOLD'))
        await reset()
        check('security material holds',(await put('data','security')).startswith('HOLD'))
        await reset()
        check('credentials required holds',(await put('credentials','yes')).startswith('HOLD'))
        await reset()
        check('credential uncertainty holds',(await put('credentials','unknown')).startswith('HOLD'))
        await reset()
        check('specialist decision holds',(await put('highstakes','yes')).startswith('HOLD'))
        await reset()
        check('uncertain specialist implications hold',(await put('highstakes','unknown')).startswith('HOLD'))
        await reset()
        check('unknown reuse agreement holds',(await put('public','unknown')).startswith('HOLD'))
        await reset()
        check('missing input sources flagged',(await put('supplied','no')).startswith('NEEDS_SCOPE_CLARIFICATION'))
        await reset()
        await page.locator('#acceptance').fill('')
        check('missing acceptance criteria flagged',(await run()).startswith('NEEDS_SCOPE_CLARIFICATION'))
        await reset()
        await page.locator('#problem').fill('')
        check('missing problem flagged',(await run()).startswith('NEEDS_SCOPE_CLARIFICATION'))
        await reset()
        await page.locator('#exclusions').fill('')
        check('missing exclusions flagged',(await run()).startswith('NEEDS_SCOPE_CLARIFICATION'))
        await reset()
        await page.locator('#nda').select_option('yes')
        await page.locator('#data').select_option('private')
        await page.locator('#problem').fill('')
        status_text=await run()
        check('hard stop precedence over privacy hold and missing scope',status_text.startswith('UNFIT_FOR_CURRENT_SERVICE'))
        check('multi-category counts preserved',await page.locator('#hardcount').inner_text()=='1' and await page.locator('#holdcount').inner_text()=='1' and await page.locator('#askcount').inner_text()=='1')
        await reset()
        await page.locator('#problem').fill('<img src=x onerror=alert(123)>\n=HYPERLINK("evil")')
        await run()
        check('hostile-shaped string displayed literally','<img src=x onerror=alert(123)>' in await page.locator('#report').inner_text() and await page.locator('#report img').count()==0)
        check('hostile shape triggers no requests',not requested,str(requested))
        await reset()
        await page.locator('#problem').fill('changed after previous result')
        check('edit invalidates prior export', await page.locator('#exporttxt').is_disabled() and 'changed' in (await status.inner_text()).lower())
        await run()
        check('regenerated report enables export', await page.locator('#exporttxt').is_enabled())
        await reset()
        await page.evaluate("document.getElementById('alias').value='A'.repeat(121)")
        check('programmatic overlong field fails closed', (await run()).startswith('INVALID INPUT') and await page.locator('#exportjson').is_disabled())
        await reset()
        await page.evaluate("document.getElementById('rights').innerHTML+='<option value=wat>bad</option>';document.getElementById('rights').value='wat'")
        check('unapproved select choice fails closed',(await run()).startswith('INVALID INPUT'))
        await reset()
        check('valid restored to draft state',(await status.inner_text()).startswith('DRAFT_SCOPE_READY'))
        check('offline HTML and JS has no external refs or network APIs',all(token not in (ROOT/'04_Customer_Problem_Intake_Triage.html').read_text(encoding='utf-8').lower() for token in ['https://','http://','fetch(', 'xmlhttprequest', 'localstorage', 'sessionstorage','serviceworker','websocket']))
        await browser.close()

error=None
try:
    asyncio.run(main())
except Exception as e:
    error=str(e)+'\n'+traceback.format_exc()
    RESULTS.append({'name':'uncaught','passed':False,'detail':error})
finally:
    report={'scope':'v0.2 new intake only, in-memory Chromium','test_count':len(RESULTS),'passed':sum(1 for i in RESULTS if i['passed']),'failed':sum(1 for i in RESULTS if not i['passed']),'cases':RESULTS}
    (ROOT/'tests'/'triage_test_results.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({k:report[k] for k in ['test_count','passed','failed']},indent=2))
    if report['failed']:
        print('FAIL:',error or next(i['detail'] for i in RESULTS if not i['passed']))
        sys.exit(1)
