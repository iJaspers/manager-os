"""Actual headless Chromium in-memory checks, strictly synthetic data. No host acceptance."""
import asyncio,io,csv,json,pathlib,traceback
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
T=[]
def check(label,condition,detail=''):
 ok=bool(condition);T.append(dict(test=label,passed=ok,detail=str(detail)[:180]));print(('PASS' if ok else 'FAIL')+' '+label,flush=True)
 if not ok:raise AssertionError(label+': '+str(detail))
def rows(header,content):
 o=io.StringIO();w=csv.writer(o,lineterminator='\n');w.writerow(header);w.writerows(content);return o.getvalue()
R=['item_id','description','quantity','unit','critical'];B=['bidder_id','item_id','coverage','quantity','unit','unit_price_cad','exclusion','valid_through','source_ref']
req=[['SURV-1','Survey positions','2','each','yes'],['WIRE-2','Cable routes','30','m','yes'],['LABEL-3','Labels','10','each','no']]
bids=[['ALPHA','SURV-1','included','2','each','75.00','','2026-12-31','A-01'],['ALPHA','WIRE-2','included','30','m','7.00','','2026-12-31','A-02'],['ALPHA','LABEL-3','included','10','each','2.00','','2026-12-31','A-03'],['BETA','SURV-1','included','2','each','60.00','','2026-12-31','B-01'],['BETA','WIRE-2','included','30','m','8.00','','2026-12-31','B-02'],['BETA','LABEL-3','included','10','each','1.50','','2026-12-31','B-03']]
async def run():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
  page=await browser.new_page(accept_downloads=True)
  errs=[];reqs=[];page.on('pageerror',lambda e:errs.append(str(e)));page.on('request',lambda r:reqs.append(r.url))
  html=(ROOT/'21_Subcontractor_Bid_Scope_Comparator.html').read_text().replace('<link rel="stylesheet" href="styles.css">','<style>'+(ROOT/'styles.css').read_text()+'</style>').replace('<script src="common.js"></script>','<script>'+(ROOT/'common.js').read_text()+'</script>')
  await page.set_content(html,wait_until='load')
  async def val(id):return (await page.locator('#'+id).inner_text()).strip()
  async def apply(r=req,b=bids,asof='2026-10-24'):
   await page.fill('#asOf',asof);await page.fill('#requirements',r if isinstance(r,str) else rows(R,r));await page.fill('#bids',b if isinstance(b,str) else rows(B,b));await page.click('#audit')
  async def blocked(word):
   check('blocked: '+word,await val('status')=='AUDIT BLOCKED' and word.lower() in (await val('err')).lower() and await page.locator('#outCSV').is_disabled(),await val('err'))
  async def down(id):
   async with page.expect_download() as dl:await page.click('#'+id)
   x=await dl.value;return x.suggested_filename,pathlib.Path(await x.path()).read_text()
  check('risk demo auto-loaded',await val('mBidders')=='2' and await val('mItems')=='3')
  check('risk demo flag critical scope', 'CRITICAL SCOPE GAPS' in await val('status'))
  check('risk demo ALPHA provisional price 170','170.00' in await page.locator('#summary').inner_text())
  check('risk demo BETA provisional price 120','120.00' in await page.locator('#summary').inner_text())
  issues=await page.locator('#issues').inner_text()
  for code in ['EXCLUDED_REQUIRED_WORK','QUOTE_EXPIRED','QTY_OR_UNIT_MISMATCH','UNRESOLVED_INCLUSION']:
   check('risk finding '+code,code in issues)
  check('risk held from award', 'NO AWARD' in await val('status') or 'STOP' in await val('status'))
  check('no automatic ranking UI','winner' not in (await page.locator('main').inner_text()).lower())
  name,s=await down('outCSV');rr=list(csv.reader(io.StringIO(s)))
  check('private CSV export',name.startswith('PRIVATE_FICTIONAL_') and rr[0]==['bidder_id','item_id','priority','issue_code','human_next_step'])
  check('critical exclusion CSV row', ['ALPHA','WIRE-2','STOP','EXCLUDED_REQUIRED_WORK','Clarify revised scope and itemized quote'] in rr)
  name,s=await down('outTXT');check('review TXT disclaimer','NO BIDDER RANKING' in s and 'ALPHA' in s and 'NOT' in s)
  name,s=await down('outJSON');j=json.loads(s)
  check('aggregate contract schema',j['schema']=='PD-BID-SCOPE-1' and j['counts']['bidders']==2)
  check('aggregate hides IDs, dates, prices and source refs',all(x not in s for x in ['ALPHA','BETA','SURV-1','WIRE-2','170.00','2026-10-20','A-01','Not included']))
  check('aggregate denies authorization',all(j[k] is False for k in ['allQuoteSourcesVerified','permissionToSolicit','permissionToAward','permissionToSpend','permissionToPublish','revenueReceivedVerified','customerContactAuthorized']))
  await page.click('#demoClean')
  check('clean status still no award','NO AWARD OR SOURCE VERIFIED' in await val('status'))
  check('clean exceptions zero',await val('mIssues')=='0' and await val('mHolds')=='0')
  check('clean ALPHA 380 subtotal','380.00' in await page.locator('#summary').inner_text())
  check('clean BETA 375 subtotal','375.00' in await page.locator('#summary').inner_text())
  check('clean human review marker','HUMAN REVIEW' in await page.locator('#summary').inner_text())
  check('clean no auto award', 'award' in (await page.locator('main').inner_text()).lower())
  await page.fill('#asOf','2026-10-25');check('date input invalidates outputs',await page.locator('#outJSON').is_disabled())
  await page.click('#audit');check('rerun restores outputs',await page.locator('#outJSON').is_enabled())
  await page.fill('#requirements','nonsense');await page.click('#audit');await blocked('exact headers')
  await apply(r='');await blocked('empty')
  await apply(r=rows(R,req).replace('item_id','ITEM'));await blocked('exact headers')
  await apply(r=req+req[:1]);await blocked('Duplicate requirement')
  await apply(r=[['bad-id','X','1','each','yes']]);await blocked('Invalid work item ID')
  await apply(r=[['S1','X','0','each','yes']]);await blocked('Invalid required quantity')
  await apply(r=[['S1','X','1','km','yes']]);await blocked('Invalid required quantity')
  await apply(r=[['S1','X','1','each','maybe']]);await blocked('Invalid required quantity')
  await apply(r=[['S1','','1','each','yes']]);await blocked('Invalid required quantity')
  await apply(r='item_id,description,quantity,unit,critical\n"S1,Missing close,1,each,yes');await blocked('Unclosed quoted')
  await apply(r=[['S1','\x00evil','1','each','yes']]);await blocked('control-text')
  await apply(r=req,b=bids+bids[:1]);await blocked('Duplicate bidder/item')
  await apply(r=req,b=[['bad','SURV-1','included','2','each','1.00','','2026-12-31','Q1']]);await blocked('Bad bidder/item')
  await apply(r=req,b=[['ALPHA','SURV-1','free','','','','','2026-12-31','Q1']]);await blocked('Unknown quoted coverage')
  await apply(r=req,b=[['ALPHA','SURV-1','included','','each','1.00','','2026-12-31','Q1']]);await blocked('requires quantity')
  await apply(r=req,b=[['ALPHA','SURV-1','excluded','2','each','1.00','','2026-12-31','Q1']]);await blocked('must not masquerade')
  await apply(r=req,b=[['ALPHA','SURV-1','included','2','each','-1.00','','2026-12-31','Q1']]);await blocked('requires quantity')
  await apply(r=req,b=[['ALPHA','SURV-1','included','2','each','1.001','','2026-12-31','Q1']]);await blocked('requires quantity')
  await apply(r=req,b=[['ALPHA','SURV-1','included','2','each','1.00','','2026-02-30','Q1']]);await blocked('Invalid quote expiry date')
  await apply(r=req,b=[['ALPHA','SURV-1','included','2','each','1000000000.01','','2026-12-31','Q1']]);await blocked('max')
  await apply(r=req,b='nonsense');await blocked('exact headers')
  await apply(r=req,b=[]);await blocked('row count')
  await apply(r=req,b=rows(B,bids).replace('bidder_id','bidder'));await blocked('exact headers')
  # Substantive case coverage: missing mandatory, extra, expired boundary, absent sources, zero, hidden exclusions.
  await apply(r=req,b=bids[:1]);check('missing mandatory scope is STOP','MISSING_SCOPE_LINE' in await page.locator('#issues').inner_text() and 'STOP' in await val('status'))
  await apply(r=req,b=bids+[['ALPHA','EXTRA-9','included','1','each','5.00','','2026-12-31','Q2']]);check('unmapped extra flagged','UNMAPPED_QUOTED_ITEM' in await page.locator('#issues').inner_text())
  b=[x.copy() for x in bids];b[0][7]='2026-10-24';await apply(b=b);check('expiry exactly as of accepted','QUOTE_EXPIRED' not in await page.locator('#issues').inner_text())
  b[0][7]='2026-10-23';await apply(b=b);check('expiry day before held','QUOTE_EXPIRED' in await page.locator('#issues').inner_text())
  b=[x.copy() for x in bids];b[0][7]='';await apply(b=b);check('blank quote validity held','MISSING_VALIDITY' in await page.locator('#issues').inner_text())
  b=[x.copy() for x in bids];b[0][8]='';await apply(b=b);check('blank source held','MISSING_SOURCE_REF' in await page.locator('#issues').inner_text())
  b=[x.copy() for x in bids];b[0][8]='=HYPERLINK("X")';await apply(b=b);check('malicious source marked review','SOURCE_REF_NEEDS_REVIEW' in await page.locator('#issues').inner_text())
  b=[x.copy() for x in bids];b[0][5]='0.00';await apply(b=b);check('zero price needs verification','ZERO_PRICE_CONFIRM' in await page.locator('#issues').inner_text())
  b=[x.copy() for x in bids];b[0][6]='Excludes setup';await apply(b=b);check('hidden exclusion undermines inclusion','HIDDEN_EXCLUSION' in await page.locator('#issues').inner_text())
  b=[x.copy() for x in bids];b[0][4]='lot';await apply(b=b);check('unit mismatch removes line subtotal','QTY_OR_UNIT_MISMATCH' in await page.locator('#issues').inner_text() and '230.00' in await page.locator('#summary').inner_text())
  b=[x.copy() for x in bids];b[0][3]='3';await apply(b=b);check('quantity mismatch flagged','QTY_OR_UNIT_MISMATCH' in await page.locator('#issues').inner_text())
  b=[x.copy() for x in bids];b[0][2]='clarify';b[0][3]=b[0][4]=b[0][5]='';await apply(b=b);check('clarify required critical stop','UNRESOLVED_INCLUSION' in await page.locator('#issues').inner_text() and 'STOP' in await val('status'))
  check('missing exclusion reason held','EXCLUSION_REASON_MISSING' in await page.locator('#issues').inner_text())
  # Test safe DOM textContent and CSV injection escaping, not HTML/script execution.
  testdesc='<img src=x onerror=alert(7)>'
  r=[x.copy() for x in req];r[0][1]=testdesc;await apply(r=r);check('HTML-looking description allowed only as inert data',await val('mIssues')=='0' and not errs)
  b=[x.copy() for x in bids];b[0][8]="=CMD|' /C calc'!A0";await apply(b=b)
  name,s=await down('outCSV');check('formula-like id/ref never exported raw as active formula',name.startswith('PRIVATE_') and '=CMD' not in s)
  # Import both invented CSV fixtures through File input, no network.
  await page.locator('#reqFile').set_input_files({'name':'req_fixture.csv','mimeType':'text/csv','buffer':rows(R,req).encode()})
  check('local requirement CSV imported',await page.locator('#requirements').input_value()==rows(R,req))
  await page.locator('#bidFile').set_input_files({'name':'bids_fixture.csv','mimeType':'text/csv','buffer':rows(B,bids).encode()})
  check('local bid CSV imported',await page.locator('#bids').input_value()==rows(B,bids))
  check('CSV import invalidates stale exports',await page.locator('#outCSV').is_disabled())
  await page.click('#audit');check('imported fixtures audited',await val('mIssues')=='0')
  await page.locator('#bidFile').set_input_files({'name':'bad.txt','mimeType':'text/plain','buffer':b'x'})
  check('reject non CSV import','Only invented .csv' in await val('err'))
  await page.locator('#bidFile').set_input_files({'name':'too_large.csv','mimeType':'text/csv','buffer':b'x'*110001})
  check('reject oversized import', '110KB' in await val('err'))
  check('oversized import no enabled exports',await page.locator('#outJSON').is_disabled())
  await apply();check('valid after bad import recovery',await val('mIssues')=='0')
  check('no network requests',not reqs,reqs)
  check('no JS errors',not errs,errs)
  check('CSP denies network',"connect-src 'none'" in (ROOT/'21_Subcontractor_Bid_Scope_Comparator.html').read_text())
  check('no data stores in new code',not any(x in (ROOT/'21_Subcontractor_Bid_Scope_Comparator.html').read_text() for x in ['localStorage','sessionStorage','indexedDB','fetch(','XMLHttpRequest']))
  check('only inventoried new tool file', (ROOT/'21_Subcontractor_Bid_Scope_Comparator.html').is_file())
  check('new page has human gate','No automatic ranking' in (await page.locator('main').inner_text()))
  await browser.close()
 results={'test_host':'headless Chromium page.set_content(in-memory), never independent file:// or mobile acceptance','tool':'21_Subcontractor_Bid_Scope_Comparator.html','passed':sum(x['passed'] for x in T),'failed':sum(not x['passed'] for x in T),'tests':T}
 (ROOT/'tests/bid_scope_test_results.json').write_text(json.dumps(results,indent=2)+'\n')
 print('TOTAL',results['passed'],results['failed'])
if __name__=='__main__':
 try:asyncio.run(run())
 except Exception:
  print(traceback.format_exc());(ROOT/'tests/bid_scope_test_results.json').write_text(json.dumps({'passed':sum(x['passed'] for x in T),'failed':1,'tests':T},indent=2)+'\n');raise
