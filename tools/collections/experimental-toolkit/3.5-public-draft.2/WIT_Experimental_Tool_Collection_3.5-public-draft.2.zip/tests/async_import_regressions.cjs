'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.resolve(process.argv[2]||path.join(__dirname,'..')),baseline=process.argv.includes('--baseline'),results=[];
const configs=JSON.parse(fs.readFileSync(path.join(__dirname,'async_import_configs.json')));
function boot(file){
 const html=fs.readFileSync(path.join(root,file),'utf8'),nodes=new Map(),downloads=[];
 function elem(){return {value:'',textContent:'',disabled:false,checked:false,files:[],children:[],events:{},classList:{add(){},remove(){},toggle(){}},addEventListener(n,f){(this.events[n]??=[]).push(f)},async fire(n){const ev={target:this};return Promise.all((this.events[n]||[]).map(f=>f.call(this,ev)))},click(){return this.fire('click')},replaceChildren(){this.children=[]},append(...v){this.children.push(...v)},appendChild(v){this.children.push(v)},remove(){},setAttribute(){}}}
 const doc={getElementById(id){if(!nodes.has(id))nodes.set(id,elem());return nodes.get(id)},createElement:elem,querySelectorAll(){return[]},body:elem()};
 const dec=s=>s.replaceAll('&gt;','>').replaceAll('&lt;','<').replaceAll('&amp;','&').replaceAll('&quot;','"');
 for(const x of html.matchAll(/<input\b[^>]*>/g)){const id=x[0].match(/\bid="([^"]+)"/),val=x[0].match(/\bvalue="([^"]*)"/);if(id){const n=doc.getElementById(id[1]);n.value=val?dec(val[1]):'';n.checked=/\bchecked\b/.test(x[0]);}}
 for(const x of html.matchAll(/<textarea\b[^>]*id="([^"]+)"[^>]*>([\s\S]*?)<\/textarea>/g))doc.getElementById(x[1]).value=dec(x[2]);
 for(const x of html.matchAll(/<select\b[^>]*id="([^"]+)"[^>]*>([\s\S]*?)<\/select>/g)){const opts=[...x[2].matchAll(/<option([^>]*)>([^<]*)<\/option>/g)],c=opts.find(v=>/selected/.test(v[1]))||opts[0];if(c)doc.getElementById(x[1]).value=c[1].match(/value="([^"]+)"/)?.[1]||c[2];}
 class Reader{readAsText(file){this.done=file.text().then(x=>{this.result=x;this.onload?.()},e=>{this.error=e;this.onerror?.()})}}
 const ctx=vm.createContext({document:doc,FileReader:Reader,File,Blob,TextEncoder,TextDecoder,Uint8Array,Uint32Array,ArrayBuffer,console:{log(){}},setTimeout,clearTimeout},{codeGeneration:{strings:false,wasm:false}});
 const run=s=>vm.runInContext(s,ctx,{timeout:2000});
 for(const m of html.matchAll(/<script(?: src="([^"]+)")?>([\s\S]*?)<\/script>/g)){
  if(m[1]==='common.js'){run(fs.readFileSync(path.join(root,m[1]),'utf8'));ctx.capture=(...v)=>downloads.push(v);run('downloadText=(...args)=>capture(...args)')}
  else run(m[1]?fs.readFileSync(path.join(root,m[1]),'utf8'):m[2]);
 }
 const check=(name,fn)=>{try{fn();results.push({file,name,pass:true})}catch(e){results.push({file,name,pass:false,error:e.message})}};
 return {nodes,run,check,downloads,html};
}
function deferred(raw,size){let resolve,reject;const p=new Promise((a,b)=>{resolve=a;reject=b});return {file:{name:'fictional.csv',size:size??Buffer.byteLength(raw),text:()=>p},resolve:()=>resolve(raw),reject:()=>reject(Error('Invented failure'))}}
async function settle(){await Promise.resolve();await Promise.resolve();}
function select(a,id,f){const input=a.nodes.get(id);input.files=f?[f.file]:[];input.value='selected.csv';const done=input.fire('change');return {input,done};}
(async()=>{
for(const [num,c]of Object.entries(configs)){
 const file=fs.readdirSync(root).find(x=>x.startsWith(num.padStart(2,'0')+'_')&&x.endsWith('.html'));let a;
 try{a=boot(file)}catch(e){results.push({file,name:'boot',pass:false,error:e.stack});continue;}
 const [input,area]=c.pairs[0];
 if(baseline){const old=deferred('OLD FILE');select(a,input,old);a.nodes.get(area).value='NEWER MANUAL EDIT';await a.nodes.get(area).fire('input');old.resolve();await settle();a.check('baseline demonstrates unguarded manual overwrite',()=>assert.equal(a.nodes.get(area).value,'OLD FILE'));continue;}
 const old=deferred('OLD FILE'),fresh=deferred('NEW FILE');const p1=select(a,input,old),p2=select(a,input,fresh);
 a.check('pending read tracked',()=>assert.equal(a.run('csvImports.pending()'),true));
 a.check('analysis guard holds while read pending',()=>assert.equal(a.run('csvImports.guard()'),true));
 const prior=a.downloads.length;a.run("downloadText('fake.csv','x')");a.check('programmatic export blocked while pending',()=>assert.equal(a.downloads.length,prior));
 fresh.resolve();await p2.done;old.resolve();await p1.done;a.check('newer same-field success wins',()=>assert.equal(a.nodes.get(area).value,'NEW FILE'));
 a.check('no stale pending state',()=>assert.equal(a.run('csvImports.pending()'),false));
 const manual=deferred('STALE');const pm=select(a,input,manual);a.nodes.get(area).value='MANUAL';await a.nodes.get(area).fire('input');manual.resolve();await pm.done;a.check('manual edit wins',()=>assert.equal(a.nodes.get(area).value,'MANUAL'));
 const bad=deferred('OLD'),good=deferred('GOOD');const pb=select(a,input,bad),pg=select(a,input,good);good.resolve();await pg.done;const errId=Number(num)<=16?'err':'error',before=a.nodes.get(errId).textContent;bad.reject();await pb.done;a.check('stale rejection preserves newer data',()=>assert.equal(a.nodes.get(area).value,'GOOD'));a.check('stale rejection preserves newer error state',()=>assert.equal(a.nodes.get(errId).textContent,before));
 const d=deferred('STALE'),pd=select(a,input,d);select(a,input,null);d.resolve();await pd.done;a.check('cancel selection supersedes read',()=>assert.notEqual(a.nodes.get(area).value,'STALE'));
 const d2=deferred('STALE2'),pd2=select(a,input,d2);const over=deferred('OVERSIZE',99999999);await select(a,input,over).done;d2.resolve();await pd2.done;a.check('oversize selection supersedes older read',()=>assert.equal(a.nodes.get(area).value,''));
 const error=deferred('BAD');const pe=select(a,input,error);error.reject();await pe.done;a.check('current read failure clears obsolete input',()=>assert.equal(a.nodes.get(area).value,''));
 const recover=deferred('RECOVERED');const pr=select(a,input,recover);recover.resolve();await pr.done;a.check('later load recovers',()=>assert.equal(a.nodes.get(area).value,'RECOVERED'));
 const demoEvent=[...a.nodes.entries()].find(([id,node])=>(node.events.click||[]).some(fn=>c.demos.some(d=>fn.toString().includes(d+'(')||fn.name===d)));
 if(demoEvent){const delayed=deferred('STALE DEMO'),pdem=select(a,input,delayed);await demoEvent[1].fire('click');const demoValue=a.nodes.get(area).value;delayed.resolve();await pdem.done;a.check('demo supersedes pending read',()=>assert.equal(a.nodes.get(area).value,demoValue));}
 if(c.pairs.length>1){const [other,otherArea]=c.pairs[1],x=deferred('SIDE ONE'),y=deferred('SIDE TWO'),px=select(a,input,x),py=select(a,other,y);y.resolve();await py.done;a.check('remaining other-side read keeps guard',()=>assert.equal(a.run('csvImports.pending()'),true));x.resolve();await px.done;a.check('independent input sides both preserved',()=>{assert.equal(a.nodes.get(area).value,'SIDE ONE');assert.equal(a.nodes.get(otherArea).value,'SIDE TWO')});}
}
const report={scope:'Controlled Node synthetic DOM with multiple listeners and deferred promises. Not rendered browser/file picker/mobile validation.',baseline,tests:results.length,passed:results.filter(x=>x.pass).length,failed:results.filter(x=>!x.pass).length,results};
fs.writeFileSync(path.join(__dirname,baseline?'async_baseline_results.json':'async_import_results.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({tests:report.tests,passed:report.passed,failed:report.failed,failures:results.filter(x=>!x.pass)}));process.exitCode=report.failed?1:0;
})().catch(e=>{console.error(e);process.exitCode=1});
