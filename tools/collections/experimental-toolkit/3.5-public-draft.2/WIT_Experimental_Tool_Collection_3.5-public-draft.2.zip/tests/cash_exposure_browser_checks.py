"""Real headless Chromium, synthetic fixtures only. In-memory app boot, no host proof."""
import asyncio,csv,io,json,pathlib,traceback
from playwright.async_api import async_playwright
R=pathlib.Path(__file__).resolve().parents[1]
H=['event_id','date','direction','amount_cad','state','source_ref']
T=[]
def check(label,condition,detail=''):
 ok=bool(condition);T.append({'test':label,'pass':ok,'detail':str(detail)[:200]});print(('PASS' if ok else 'FAIL')+' '+label,flush=True)
 if not ok:raise AssertionError(f'{label}: {detail}')
def rows(*rr):
 b=io.StringIO();w=csv.writer(b,lineterminator='\n');w.writerow(H);w.writerows(rr);return b.getvalue()
def ent(id,date,direction,amt,state,ref='SRC-1'):return [id,date,direction,amt,state,ref]
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
  page=await browser.new_page(accept_downloads=True)
  errors=[];network=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:network.append(r.url))
  html=(R/'20_Cash_Exposure_Scenario_Planner.html').read_text().replace('<link rel="stylesheet" href="styles.css">','<style>'+(R/'styles.css').read_text()+'</style>').replace('<script src="common.js"></script>','<script>'+(R/'common.js').read_text()+'</script>')
  await page.set_content(html,wait_until='load')
  async def val(id):return (await page.locator('#'+id).inner_text()).strip()
  async def setcsv(csv):await page.fill('#events',csv);await page.click('#audit')
  async def down(id):
   async with page.expect_download() as d:await page.click('#'+id)
   obj=await d.value;return obj.suggested_filename,pathlib.Path(await obj.path()).read_text()
  async def blocked(label,word=''):
   a,b=await val('status'),await val('err')
   check(label,a=='CALCULATION BLOCKED' and await page.locator('#outCSV').is_disabled() and (not word or word.lower() in b.lower()),a+' '+b)
  async def setup(evt,reserve='300.00',asof='2026-10-24',delay='14'):
   await page.fill('#reserve',reserve);await page.fill('#asOf',asof);await page.select_option('#delay',delay);await setcsv(evt)
  check('risk demo autoloads',await val('mOut')=='$950.00',await val('mOut'))
  check('baseline cash gap exact cents',await val('mBase')=='$300.00')
  check('delayed cash gap exact cents',await val('mDelayed')=='$650.00')
  check('no future receipts cash gap exact cents',await val('mNoFuture')=='$650.00')
  check('delay marginal exposure exact',await val('mDelayDelta')=='$350.00')
  check('disputed item stop', 'STOP' in await val('status'))
  check('planned inflow warning', 'UNAGREED_INFLOW' in await page.locator('#issues').inner_text())
  check('disputed inflow/outflow warning', 'DISPUTED_CASH_EVENT' in await page.locator('#issues').inner_text())
  check('risk display not cash proof','self-reported' in (await page.locator('body').inner_text()).lower())
  name,s=await down('outCSV');report=list(csv.reader(io.StringIO(s)))
  check('private dated timeline csv export',name.startswith('PRIVATE_FICTIONAL_') and report[0]==['scenario','date','event_id','reported_or_planned_cash_balance_cad'])
  check('baseline outflow before inflow recorded',['BASE','2026-10-25','COST-1','-300.00'] in report)
  check('shifted deposit dated Nov 9',['DELAYED_14_DAYS','2026-11-09','DEP-1','-250.00'] in report)
  name,s=await down('outTXT')
  check('private review explicit no approval',name.startswith('PRIVATE_') and 'NO CUSTOMER CONTACT' in s and 'NOT collected' in s)
  name,j=await down('outJSON');a=json.loads(j)
  check('counts-only handoff schema',a['schema']=='PD-CASH-EXPOSURE-1' and a['counts']['events']==5)
  check('JSON excludes source data, amounts, dates, cash gaps and client IDs',all(x not in j for x in ['DEMO-CASH','DEP-1','COST-1','2026-10-25','300.00','650.00','AG-1','PO-1']))
  check('JSON denies actual money/authority',all(a[k] is False for k in ['actualBankReceiptsVerified','expensePaymentsVerified','contractAndRightsVerified','permissionToSendInvoice','permissionToCollectMoney','permissionToStartWork','permissionToPublish','customerContactAuthorized','revenueReceivedVerified']))
  await page.click('#demoHealthy')
  check('healthy demo no baseline gap',await val('mBase')=='$0.00')
  check('healthy demo stress no gap',await val('mDelayed')=='$0.00' and await val('mNoFuture')=='$0.00')
  check('reported receipt explicitly unverified', 'RECEIPT_SELF_REPORTED' in await page.locator('#issues').inner_text())
  check('healthy not automatically payment approved','HUMAN REVIEW REQUIRED' in await val('status'))
  await page.fill('#reserve','301.00');check('edit invalidates exports',await page.locator('#outTXT').is_disabled() and await val('mBase')=='—')
  await page.click('#audit');check('audit restores exports',await page.locator('#outTXT').is_enabled())
  await page.fill('#asOf','2026-10-25');check('date edit invalidates',await page.locator('#outCSV').is_disabled())
  await page.click('#audit');check('rerun after date edit',await page.locator('#outCSV').is_enabled())
  await page.select_option('#delay','30');check('delay edit invalidates',await page.locator('#outCSV').is_disabled())
  await page.click('#audit');check('30-day stress variant runs',await val('mDelayed')=='$0.00')
  await setup(rows(ent('IN-A','2026-10-25','IN','100.00','due_reported'),ent('OUT-A','2026-10-25','OUT','100.00','estimated')),'0.00')
  check('same-day outflow occurs before receipt',await val('mBase')=='$100.00')
  check('same-day delay 14 days leaves gap',await val('mDelayed')=='$100.00')
  await setup(rows(ent('OUT-A','2026-10-25','OUT','100.00','estimated'),ent('IN-A','2026-10-25','IN','200.00','disputed')),'0.00')
  check('disputed inflow excluded',await val('mBase')=='$100.00' and await val('mNoFuture')=='$100.00')
  await setup(rows(ent('IN-A','2026-10-23','IN','125.00','received_reported'),ent('OUT-A','2026-10-26','OUT','110.00','paid_reported')),'0.00')
  await blocked('future paid_reported rejected','future')
  await setup(rows(ent('IN-A','2026-10-23','IN','125.00','received_reported'),ent('OUT-A','2026-10-24','OUT','110.00','paid_reported')),'0.00')
  check('past reported inflow and expense zero need',await val('mBase')=='$0.00')
  await setup(rows(ent('IN-A','2026-10-29','IN','100.00','received_reported')),'0.00')
  await blocked('future received_reported rejected','future')
  await setup(rows(ent('OUT-A','2026-10-25','OUT','100.00','estimated')),'0.00')
  check('missing income event flagged', 'NO_INCOMING_CASH' in await page.locator('#issues').inner_text())
  await setup(rows(ent('IN-A','2026-10-25','IN','100.00','proposed')),'0.00')
  check('missing expense flagged', 'NO_OUTGOING_CASH' in await page.locator('#issues').inner_text())
  await setup(rows(ent('OUT-A','2026-10-25','OUT','0.01','estimated')),'0.00')
  check('one cent precision','$0.01'==await val('mBase'))
  await setup(rows(ent('OUT-A','2026-10-25','OUT','1000000.00','estimated')),'0.00')
  check('maximum per-row accepted',await val('mBase')=='$1,000,000.00')
  for name,payload,hint in [
   ('empty schedule','', 'event rows'),
   ('wrong header','x,y,z\na,b,c','header'),
   ('duplicate event IDs',rows(ent('COST-A','2026-10-25','OUT','1.00','estimated'),ent('cost-a','2026-10-26','OUT','1.00','estimated')),'duplicate'),
   ('unsafe event ID',rows(ent('=HYPERLINK','2026-10-25','OUT','1.00','estimated')),'unsafe'),
   ('script event ID',rows(ent('<script>','2026-10-25','OUT','1.00','estimated')),'unsafe'),
   ('invalid YYYY-MM-DD date',rows(ent('A-1','2026-02-29','OUT','1.00','estimated')),'date'),
   ('invalid year',rows(ent('A-1','1900-01-01','OUT','1.00','estimated')),'date'),
   ('invalid direction state',rows(ent('A-1','2026-10-25','OUT','1.00','due_reported')),'direction'),
   ('negative dollar amount',rows(ent('A-1','2026-10-25','OUT','-1.00','estimated')),'amount'),
   ('zero amount',rows(ent('A-1','2026-10-25','OUT','0.00','estimated')),'amount'),
   ('only one decimal place',rows(ent('A-1','2026-10-25','OUT','1.9','estimated')),'amount'),
   ('exceed per-row maximum',rows(ent('A-1','2026-10-25','OUT','1000000.01','estimated')),'amount'),
   ('spreadsheet formula in source reference',rows(ent('A-1','2026-10-25','OUT','1.00','estimated','=1+1')),'unsafe'),
   ('bad source ref with HTML',rows(ent('A-1','2026-10-25','OUT','1.00','estimated','<img src=x>')),'unsafe'),
   ('row with extra field','event_id,date,direction,amount_cad,state,source_ref\nA-1,2026-10-25,OUT,1.00,estimated,SRC,a', 'six cells'),
   ('row with missing field','event_id,date,direction,amount_cad,state,source_ref\nA-1,2026-10-25,OUT,1.00,estimated', 'six cells'),
   ('broken quote','event_id,date,direction,amount_cad,state,source_ref\n"A-1,2026-10-25,OUT,1.00,estimated,SRC', 'quoted'),
  ]:
   await setup(payload,'0.00');await blocked(name,hint)
  await setup(rows(ent('A-1','2026-10-25','OUT','1.00','estimated')),'-1.00');await blocked('negative reserve rejects','reserve')
  await setup(rows(ent('A-1','2026-10-25','OUT','1.00','estimated')),'1.1');await blocked('reserve requires exact pennies','reserve')
  await setup(rows(ent('A-1','2026-10-25','OUT','1.00','estimated')),'0.00','');await blocked('missing reporting date rejects','reporting date')
  await setup(rows(ent('A-1','2026-10-25','OUT','1.00','estimated')),'0.00');await page.fill('#project','=HYPERLINK');await page.click('#audit');await blocked('unsafe project ID rejects','project ID')
  await page.fill('#project','DEMO-CASH');await setcsv(rows(ent('A-1','2026-10-25','OUT','1.00','estimated')))
  check('recovered from invalid input',await val('mBase')=='$1.00')
  await page.set_input_files('#csvfile',{'name':'invented.csv','mimeType':'text/csv','buffer':(R/'examples/cash_exposure_funded_fictional.csv').read_bytes()})
  for _ in range(40):
   if 'DEPOSIT-1' in await page.locator('#events').input_value():break
   await asyncio.sleep(0.05)
  check('local CSV import text accepted','DEPOSIT-1' in await page.locator('#events').input_value())
  check('file import clears stale results',await page.locator('#outCSV').is_disabled())
  await page.click('#audit');check('local CSV import valid after analysis',await val('mBase')=='$0.00')
  await page.set_input_files('#csvfile',{'name':'bad.txt','mimeType':'text/plain','buffer':b'invented only'})
  await blocked('noncsv file rejected','only invented')
  await page.set_input_files('#csvfile',{'name':'too_big.csv','mimeType':'text/csv','buffer':b'a'*80001})
  await blocked('oversized file rejected','80,000')
  await setup(rows(*[ent(f'C{i}','2026-10-25','OUT','1.00','estimated') for i in range(151)]),'0.00')
  await blocked('row bound 151 rejects','1–150')
  await setup(rows(*[ent(f'C{i}','2026-10-25','OUT','100000.00','estimated') for i in range(101)]),'0.00')
  await blocked('total volume over ten million rejects','total event volume')
  await setup(rows(ent('COST-A','2026-10-25','OUT','100.00','estimated')),'0.00');check('valid recovery after bound',await val('mBase')=='$100.00')
  # User-controlled externally sourced-ish strings in exports never auto-run formula or script.
  await setup(rows(ent('COST-A','2026-10-25','OUT','1.00','estimated','A-2')),'0.00')
  check('CSV outputs no formula in leading cells', not (await down('outCSV'))[1].startswith('=HYPERLINK'))
  check('no untrusted external resources requested',len(network)==0,network)
  check('no JavaScript page errors',len(errors)==0,errors)
  await browser.close()
 result={'suite':'cash_exposure_browser_checks.py','passed':sum(x['pass'] for x in T),'failed':sum(not x['pass'] for x in T),'actually_executed':True,'browser':'Headless Chromium app content in-memory','independent_file_host_tested':False,'checks':T}
 (R/'tests/cash_exposure_test_results.json').write_text(json.dumps(result,indent=2)+'\n')
 print(f"RESULT {result['passed']}/{len(T)} PASS")
async def go():
 try:await main()
 except BaseException as e:
  (R/'tests/cash_exposure_test_results.json').write_text(json.dumps({'passed':sum(x['pass'] for x in T),'failed':sum(not x['pass'] for x in T)+1,'actually_executed':True,'error':str(e),'checks':T},indent=2)+'\n')
  traceback.print_exc();raise
if __name__=='__main__':asyncio.run(go())
