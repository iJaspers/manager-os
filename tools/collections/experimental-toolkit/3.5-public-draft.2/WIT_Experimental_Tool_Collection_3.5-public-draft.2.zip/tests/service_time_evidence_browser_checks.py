"""Original v2.6 private time-evidence tool checks: synthetic in-memory Chromium only."""
import asyncio,pathlib,json,csv,io,traceback
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
RESULTS=[]
def check(label,pass_check,detail=''):
    ok=bool(pass_check);RESULTS.append({'name':label,'passed':ok,'detail':str(detail)[:240]});print(('PASS ' if ok else 'FAIL ')+label,flush=True)
    if not ok:raise AssertionError(label+' '+str(detail)[:240])
def parse(t):return list(csv.reader(io.StringIO(t)))
def build(rows):
    obj=io.StringIO();csv.writer(obj,lineterminator='\n').writerows(rows);return obj.getvalue()
def fixture(name):return parse((ROOT/'examples'/name).read_text())
S=fixture('time_evidence_conflicts_segments_fictional.csv');C=fixture('time_evidence_conflicts_claims_fictional.csv');CS=fixture('time_evidence_aligned_segments_fictional.csv');CC=fixture('time_evidence_aligned_claims_fictional.csv')
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
  page=await browser.new_page(accept_downloads=True)
  errors=[];requests=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('request',lambda r:requests.append(r.url))
  html=(ROOT/'28_Service_Time_Evidence_Reconciler.html').read_text().replace('<link rel="stylesheet" href="styles.css">','<style>'+(ROOT/'styles.css').read_text()+'</style>').replace('<script src="common.js"></script>','<script>'+(ROOT/'common.js').read_text()+'</script>')
  await page.set_content(html,wait_until='load')
  async def inside(id):return (await page.locator('#'+id).inner_text()).strip()
  async def apply(s=CS,c=CC):
   await page.locator('#segments').fill(build(s) if isinstance(s,list) else s)
   await page.locator('#claims').fill(build(c) if isinstance(c,list) else c)
   await page.click('#review')
  async def blocked(part):
   message=await inside('error');check('blocks input: '+part,await inside('status')=='INPUT BLOCKED' and part.lower() in message.lower() and await page.locator('#exportCSV').is_disabled(),message)
  async def dl(id):
   async with page.expect_download() as d:await page.click('#'+id)
   file=await d.value;return file.suggested_filename,pathlib.Path(await file.path()).read_text()
  try:
   check('original conflicted segment fixture row shape',len(S)==8 and all(len(r)==9 for r in S))
   check('original conflicted claim fixture row shape',len(C)==5 and all(len(r)==9 for r in C))
   check('source default risk loaded',await inside('mSegments')=='7' and await inside('mClaims')=='4')
   check('one overlapping segment pair',await inside('mOverlaps')=='1')
   check('four claim/job groups plus one activity-only group',await inside('mGroups')=='4')
   findings=await inside('findings')
   for code in ['OVERLAPPING_ACTIVITY_SEGMENTS','SEGMENT_RIGHTS_HOLD','SEGMENT_SOURCE_MISSING','CLAIM_SOURCE_MISSING','CLAIM_NOT_APPROVED','CLAIM_RIGHTS_HOLD','REPEATED_JOB_DAY_CLAIM','CLAIM_EXCEEDS_MODELLED_MINUTES','CLAIM_WITHOUT_ACTIVITY','ACTIVITY_WITHOUT_CLAIM']:
    check('risk detects '+code,code in findings)
   register=await inside('groups')
   for expected in ['TECH-A / 2026-11-02 / SITE-A','120 min\t60 min\t240 min\tCLAIM EXCEEDS MODELLED 60 min','SITE-B\t120 min\t0 min\t180 min\tCLAIM EXCEEDS MODELLED 60 min','SITE-C\t120 min\t0 min\t0 min\tNO REPORTED CLAIM','SITE-D\t0 min\t0 min\t60 min\tNO LINKED ONSITE/TRAVEL SEGMENTS']:
    check('models risk register '+expected[:35],expected in register,register[:600])
   check('no application runtime errors',not errors,errors)
   check('zero network requests',not requests,requests)
   name,txt=await dl('exportCSV');check('private CSV filename',name=='PRIVATE_service_time_evidence_exceptions.csv');rr=parse(txt);check('private CSV schema',rr[0]==['related_record','finding_code','human_next_check']);check('private export escapes spreadsheet formulas',all(not r[0].startswith(('=','+','@')) for r in rr[1:]))
   name,txt=await dl('exportTXT');check('private TXT filename',name=='PRIVATE_service_time_evidence_review.txt');check('private TXT does not claim validation','not independently verified' in txt and 'CLAIM EXCEEDS MODELLED 60 min' in txt)
   name,txt=await dl('exportJSON');j=json.loads(txt);check('counts-only JSON kind',j['kind']=='private_counts_only_service_time_review');check('counts-only JSON metrics',j['segments']==7 and j['claims']==4 and j['overlapping_segment_pairs']==1 and j['job_day_groups']==4)
   check('AI counts-only JSON hides identifiers dates minutes',not any(x in txt for x in ['TECH-A','SITE-A','SEG-01','CLM-04','2026-11-02','240','NOTE-01','CLAIM-01']))
   check('AI JSON explicitly denies verification and publication',not any(j[x] for x in ['source_verified','rights_verified','work_verified','approval_verified','billing_authorized','published']))
   await page.click('#demoClean')
   check('aligned fixture no model exceptions','NO MODEL EXCEPTIONS' in await inside('status') and await inside('mIssues')=='0')
   check('aligned data exactly four segments and two claims',await inside('mSegments')=='4' and await inside('mClaims')=='2' and await inside('mOverlaps')=='0')
   await page.locator('#claims').fill(build(CC)+'\n')
   check('edits invalidate exports',await page.locator('#exportCSV').is_disabled() and 'Input changed' in await inside('status'))
   await page.click('#review');check('corrected review reenables export',not await page.locator('#exportJSON').is_disabled())
   s=[r.copy() for r in CS];s.append(s[1].copy());await apply(s);await blocked('repeated or invalid segment_id')
   c=[r.copy() for r in CC];c.append(c[1].copy());await apply(CS,c);await blocked('repeated or invalid claim_id')
   s=[r.copy() for r in CS];s[1][2]='2026-02-29';await apply(s);await blocked('invalid work_date')
   s=[r.copy() for r in CS];s[1][2]='1999-01-01';await apply(s);await blocked('invalid work_date')
   s=[r.copy() for r in CS];s[1][3]='8:00';await apply(s);await blocked('invalid HH:MM')
   s=[r.copy() for r in CS];s[1][3]='24:00';await apply(s);await blocked('invalid HH:MM')
   s=[r.copy() for r in CS];s[1][4]='08:00';await apply(s);await blocked('end_time must follow')
   s=[r.copy() for r in CS];s[1][4]='07:59';await apply(s);await blocked('end_time must follow')
   s=[r.copy() for r in CS];s[1][5]='drive';await apply(s);await blocked('invalid activity')
   s=[r.copy() for r in CS];s[1][7]='authorized';await apply(s);await blocked('invalid rights_status')
   s=[r.copy() for r in CS];s[1][6]='SITE<script>';await apply(s);await blocked('invalid worker_code or job_code')
   s=[r.copy() for r in CS];s[1][8]='=HYPERLINK("foo")';await apply(s);await blocked('invalid source_ref')
   c=[r.copy() for r in CC];c[1][4]='60.5';await apply(CS,c);await blocked('integer')
   c=[r.copy() for r in CC];c[1][4]='-1';await apply(CS,c);await blocked('integer')
   c=[r.copy() for r in CC];c[1][4]='0';await apply(CS,c);await blocked('outside 1–1440')
   c=[r.copy() for r in CC];c[1][4]='1441';await apply(CS,c);await blocked('outside 1–1440')
   c=[r.copy() for r in CC];c[1][5]='all';await apply(CS,c);await blocked('invalid claim_basis')
   c=[r.copy() for r in CC];c[1][6]='signed';await apply(CS,c);await blocked('invalid approval_state')
   c=[r.copy() for r in CC];c[1][7]='public';await apply(CS,c);await blocked('invalid rights_status')
   c=[r.copy() for r in CC];c[1][8]='-malicious';await apply(CS,c);await blocked('invalid source_ref')
   s=[r.copy() for r in CS];s[1]=s[1][:-1];await apply(s);await blocked('incorrect column count')
   c=[r.copy() for r in CC];c[0][0]='not_claim';await apply(CS,c);await blocked('exact CSV header')
   await apply('segment_id,worker_code\nA,B');await blocked('exact CSV header')
   s=[r.copy() for r in CS];s[1][8]='X'*91;await apply(s);await blocked('90 character cell')
   await apply(build(CS)+'X'*120001);await blocked('character limit')
   # Hypothetical duplicate group in a normal fit: two claims each eligible, aggregate excess flagged.
   c=[r.copy() for r in CC];c.append(c[1].copy());c[3][0]='CLM-13';await apply(CS,c)
   f=await inside('findings');check('group duplicate flagged','REPEATED_JOB_DAY_CLAIM' in f);check('duplicate group aggregate exceeds source','CLAIM_EXCEEDS_MODELLED_MINUTES' in f)
   # Contradictory basis rejected for automatic confidence; reviewed as hold.
   c=[r.copy() for r in CC];c.append(c[1].copy());c[3][0]='CLM-13';c[3][5]='onsite_only';await apply(CS,c)
   check('inconsistent basis held for human','MIXED_CLAIM_BASIS' in await inside('findings'))
   # Unauthorized/fabricated timestamps in notes stay escaped in DOM.
   c=[r.copy() for r in CC];c[1][8]='UNKNOWN';await apply(CS,c);check('UNKNOWN claim source flagged','CLAIM_SOURCE_MISSING' in await inside('findings'))
   s=[r.copy() for r in CS];s[1][7]='restricted';await apply(s);check('restricted segment rights held','SEGMENT_RIGHTS_HOLD' in await inside('findings'))
   # Real file picker test using only invented local fixture bytes.
   await page.locator('#segmentsFile').set_input_files(str(ROOT/'examples/time_evidence_conflicts_segments_fictional.csv'))
   await page.locator('#claimsFile').set_input_files(str(ROOT/'examples/time_evidence_conflicts_claims_fictional.csv'))
   check('file picker import invalidates prior snapshot',await page.locator('#exportCSV').is_disabled())
   await page.click('#review');check('imported risk sample finds overlap',await inside('mOverlaps')=='1' and await inside('mSegments')=='7')
   check('still no unexpected network requests',not requests,requests)
   check('still no JS exceptions',not errors,errors)
  finally:
   out={'version':'v2.6','tool':'28_Service_Time_Evidence_Reconciler.html','passed':sum(x['passed'] for x in RESULTS),'failed':sum(not x['passed'] for x in RESULTS),'checks':RESULTS,'test_mode':'in-memory synthetic HTML/CSS/JS with real browser file picker on invented fixtures; not independent file-host acceptance'}
   (ROOT/'tests/service_time_evidence_test_results.json').write_text(json.dumps(out,indent=2)+'\n')
   await browser.close()
   print('RESULT',out['passed'],out['failed'],flush=True)
if __name__=='__main__':asyncio.run(main())
