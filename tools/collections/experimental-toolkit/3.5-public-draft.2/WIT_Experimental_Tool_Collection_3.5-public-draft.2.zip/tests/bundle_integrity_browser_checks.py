"""Actual headless Chromium offline bytes-versus-manifest checks. Fictional local files only."""
import asyncio, csv, hashlib, io, json, pathlib, traceback
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
HEADER=['file_name','size_bytes','sha256','rights']; TESTS=[]
def check(name, ok, detail=''):
 ok=bool(ok);TESTS.append({'test':name,'pass':ok,'detail':str(detail)[:180]});print(('PASS ' if ok else 'FAIL ')+name,flush=True)
 if not ok:raise AssertionError(name+' '+str(detail))
def digest(data):return hashlib.sha256(data).hexdigest()
def record(name, data=b'Hello fake test\n', rights='ORIGINAL'):
 return [name,str(len(data)),digest(data),rights]
def csv_data(rows,head=HEADER):
 f=io.StringIO();w=csv.writer(f,lineterminator='\n');w.writerow(head);w.writerows(rows);return f.getvalue()
async def main_suite():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
  page=await browser.new_page(accept_downloads=True);page.set_default_timeout(16000)
  errors=[];network=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda q:network.append(q.url))
  html=(ROOT/'19_Evidence_Bundle_Integrity_Check.html').read_text().replace('<link rel="stylesheet" href="styles.css">','<style>'+(ROOT/'styles.css').read_text()+'</style>').replace('<script src="common.js"></script>','<script>'+(ROOT/'common.js').read_text()+'</script>')
  await page.set_content(html,wait_until='load');await page.wait_for_function('document.getElementById("mExpected").textContent!=="—"')
  async def value(id):return await page.locator('#'+id).inner_text()
  async def down(id):
   async with page.expect_download() as obj:await page.click('#'+id)
   d=await obj.value;return d.suggested_filename,pathlib.Path(await d.path()).read_text()
  async def until_text(id,part):
   for _ in range(250):
    if part in await value(id):return
    await asyncio.sleep(0.035)
   raise AssertionError('timeout waiting for '+id+' to include '+part)
  async def until_value(id,part):
   for _ in range(250):
    if part in await page.locator('#'+id).input_value():return
    await asyncio.sleep(0.035)
   raise AssertionError('timeout waiting for '+id+' value')
  async def await_review():
   for _ in range(250):
    if await value('mExpected')!='—' or await value('status')=='COMPARISON BLOCKED':return
    await asyncio.sleep(0.035)
   raise AssertionError('timed out waiting for audit result')
  async def run(rows, files=None, project='DEMO-BUNDLE', head=HEADER):
   await page.fill('#project',project);await page.fill('#manifest',csv_data(rows,head))
   if files is not None:
    await page.set_input_files('#files',[{'name':n,'mimeType':'application/octet-stream','buffer':b} for n,b in files])
   await page.click('#review');await await_review()
  async def blocked(name, contains=''):
   s=await value('status');e=await value('err')
   check(name,s=='COMPARISON BLOCKED' and await page.locator('#outCSV').is_disabled() and (not contains or contains.lower() in e.lower()),s+' / '+e)
  check('bad fictional fixture loads automatically',await value('mExpected')=='3')
  check('bad fixture has only two selected',await value('mSelected')=='2')
  check('bad fixture has two missing',await value('mMissing')=='2')
  check('bad fixture has one unexpected',await value('mUnexpected')=='1')
  check('bad fixture has zero byte matches',await value('mMatches')=='0')
  check('bad fixture stops', 'STOP' in await value('status'))
  check('privacy notice insists fictional only','FICTIONAL' in await page.locator('.notice').inner_text())
  bad_name,bad_csv=await down('outCSV');check('private exception CSV export',bad_name.startswith('PRIVATE_'))
  check('exception CSV has issue codes','SHA256_MISMATCH' in bad_csv and 'MISSING_FILE' in bad_csv and 'UNEXPECTED_FILE' in bad_csv)
  check('only expected CSV columns',next(csv.reader(io.StringIO(bad_csv)))==['file_name','severity','issue_code','human_action'])
  name,bad_txt=await down('outTXT');check('private audit TXT export',name.startswith('PRIVATE_'))
  check('TXT never claims custody verified','NO MANIFEST AUTHENTICITY' in bad_txt and 'NO UPLOAD' in bad_txt)
  name,j=await down('outJSON');data=json.loads(j)
  check('AI JSON only counts plus code labels',data['schema']=='PD-BUNDLE-INTEGRITY-1' and data['counts']['missing']==2)
  check('JSON does not leak filename/project or SHA','proof_alpha' not in j and 'counts_beta' not in j and 'DEMO-BUNDLE' not in j and digest(b'X\n') not in j)
  check('JSON rights and publication assertions remain false',all(data[key] is False for key in ['expectedManifestAuthenticated','signaturesVerified','sourceRightsVerified','provenanceVerified','chainOfCustodyVerified','permissionToPublish','permissionToContactClients','revenueReceivedVerified']))
  await page.click('#demoGood');await await_review()
  check('matching demo two selected',await value('mSelected')=='2')
  check('matching demo two hashes pass',await value('mMatches')=='2')
  check('matching demo zero missing and unexpected',(await value('mMissing'),await value('mUnexpected'))==('0','0'))
  check('matching demo has no issues',await value('mIssues')=='0')
  check('matching demo still requires human review','HUMAN REVIEW REQUIRED' in await value('status') and 'UNVERIFIED' in await value('status'))
  name,good=await down('outCSV');check('matching demo differences header only',len(list(csv.reader(io.StringIO(good))))==1)
  draft_name,draft_csv=await down('draftManifest')
  dr=list(csv.reader(io.StringIO(draft_csv)))
  check('draft manifest clearly marked private and untrusted',draft_name.startswith('PRIVATE_DRAFT_UNTRUSTED_'))
  check('draft has exact four-column schema',dr[0]==HEADER and len(dr)==3)
  check('draft records source hashes for currently selected invented files',dr[1][2]==digest(b'Invented blue widget signed-off? Not verified.\n') and dr[2][2]==digest(b'code,qty\nA,2\nB,3\n'))
  check('draft leaves all rights explicitly UNKNOWN',all(row[-1]=='UNKNOWN' for row in dr[1:]))
  check('draft note warns not independently authenticated','NOT AN AUTHENTICATED' in await value('draftNote'))
  await page.fill('#project','DEMO-OTHER');check('changing project disables stale downloads',all([await page.locator('#'+x).is_disabled() for x in ['outCSV','outTXT','outJSON']]))
  await page.click('#review');await await_review();check('rerun re-enables exports',await page.locator('#outJSON').is_enabled())
  await page.fill('#manifest',csv_data([record('a.txt',b'next')]))
  check('changing manifest disables stale exports',await page.locator('#outCSV').is_disabled())
  await page.click('#review');await await_review();check('changing manifest without new file triggers file exception', 'STOP' in await value('status'))
  # SHA-256 known vectors from independent hashlib, including SHA block and double-block boundaries.
  for n in [0,1,3,55,56,63,64,65,119,120,127,128,1024,4096,1000000]:
   payload=b'a'*n;actual=await page.evaluate('(s)=>sha256(new TextEncoder().encode(s))','a'*n)
   check('independent SHA256 reference vector for length '+str(n),actual==digest(payload),actual[:18])
  unusual=bytes(range(256))*4
  actual=await page.evaluate('(xs)=>sha256(new Uint8Array(xs))',list(unusual))
  check('binary 0x00-0xff byte range matches Python hashlib',actual==digest(unusual))
  # Fresh independent file importer and exact byte hash comparison.
  await run([record('note.txt',b'fictional 123\n')],[('note.txt',b'fictional 123\n')])
  check('external in-browser File object accepted as matching','MATCH_RECORDED_NOT_AUTHENTICATED' in await page.locator('#results').inner_text())
  await run([record('note.txt',b'fictional 123\n')],[('note.txt',b'fictional 123!\n')])
  check('changed byte count flagged','BYTE_LENGTH_MISMATCH' in (await down('outCSV'))[1])
  check('changed byte content flagged','SHA256_MISMATCH' in (await down('outCSV'))[1])
  check('changed does not count matching',await value('mMatches')=='0')
  await run([record('note.txt',b'fictional 123\n')],[('note.txt',b'fictional 124\n')])
  check('same length tamper still flagged SHA','SHA256_MISMATCH' in (await down('outCSV'))[1] and 'BYTE_LENGTH_MISMATCH' not in (await down('outCSV'))[1])
  await run([record('file.txt',b'a')],[('OTHER.txt',b'a')]);check('unlisted same-content file not silently matched',await value('mMissing')=='1' and await value('mUnexpected')=='1')
  await run([record('file.txt',b'a')],[]);await blocked('missing selected files disallowed','Select invented files')
  await run([record('same.txt',b'a'),record('other.txt',b'a')],[('same.txt',b'a'),('other.txt',b'a')]);check('duplicate contents under two names flagged for review','IDENTICAL_DIGEST_MULTIPLE_NAMES' in (await down('outCSV'))[1])
  check('duplicate bytes not falsely described as mismatch',await value('mMatches')=='2')
  await run([record('empty.txt',b'')],[('empty.txt',b'')]);check('zero bytes allowed only with review','EMPTY_FILE_REVIEW' in (await down('outCSV'))[1])
  for flag,key in [('ORIGINAL','mMatches'),('CLIENT_REPORTED','mIssues'),('UNKNOWN','mIssues'),('DENIED','mIssues')]:
   await run([record('note.txt',b'demo',flag)],[('note.txt',b'demo')])
   check('rights status accepted '+flag,(await value(key)).isdigit())
   if flag!='ORIGINAL':
    codes={'CLIENT_REPORTED':'REPORTED_RIGHTS_NOT_VERIFIED','UNKNOWN':'RIGHTS_UNKNOWN','DENIED':'RIGHTS_DENIED'}
    check('rights holds against self-report '+flag,codes[flag] in (await down('outCSV'))[1])
  check('DENIED stops even where hashes agree','STOP' in await value('status'))
  await run([record('note.txt',b'demo','CLAIMED')],[('note.txt',b'demo')]);await blocked('unknown rights enum rejected','rights')
  await run([], [('note.txt',b'demo')]);await blocked('zero expected records blocked','1–40')
  await run([record('note.txt',b'demo'),record('note.txt',b'demo')],[('note.txt',b'demo')]);await blocked('duplicate manifest records blocked','Duplicate manifest')
  await run([record('Note.txt',b'demo'),record('note.TXT',b'demo')],[('Note.txt',b'demo')]);await blocked('case-insensitive manifest duplicates blocked','Duplicate manifest')
  for bad in ['../traversal.txt','..hidden.txt','.hidden.txt','path/file.txt','folder\\note.txt','n..ote.txt','inject.html','script.js','launch.exe','=SUM(1).txt','<img>.txt','off ice.txt','a.txt\n']:
   await run([record(bad,b'demo')],[('note.txt',b'demo')]);await blocked('unsafe expected file name '+repr(bad),'unsafe')
  await run([record('a.txt',b'demo')],[('a.js',b'demo')]);await blocked('script-shaped actual file rejected','unsafe')
  await run([record('a.txt',b'demo')],[('a.txt',b'demo'),('A.TXT',b'other')]);await blocked('case-insensitive duplicate selected names rejected','Duplicate selected')
  await run([record('a.txt',b'demo')],[('a.txt',b'demo')],project='wrong');await blocked('wrong lowercase project code rejected','bundle code')
  await run([record('a.txt',b'demo')],[('a.txt',b'demo')],project='<svg>');await blocked('HTML-shaped project code rejected','bundle code')
  await run([record('a.txt',b'demo')],[('a.txt',b'demo')],head=['BAD']+HEADER[1:]);await blocked('incorrect CSV header rejected','headers')
  await run([record('a.txt',b'demo')[:-1]],[('a.txt',b'demo')]);await blocked('short CSV row rejected','four columns')
  await run([record('a.txt',b'demo')+['extra']],[('a.txt',b'demo')]);await blocked('extra CSV field rejected','four columns')
  await run([['a.txt','-1',digest(b'demo'),'ORIGINAL']],[('a.txt',b'demo')]);await blocked('negative size blocked','expected size')
  await run([['a.txt','00',digest(b'demo'),'ORIGINAL']],[('a.txt',b'demo')]);await blocked('ambiguous leading-zero size blocked','expected size')
  await run([['a.txt',str(4*1024*1024+1),digest(b'demo'),'ORIGINAL']],[('a.txt',b'demo')]);await blocked('expected size exceeding per-file limit blocked','expected size')
  await run([['a.txt','4','0'*63,'ORIGINAL']],[('a.txt',b'demo')]);await blocked('short expected digest blocked','SHA-256')
  await run([['a.txt','4','A'*64,'ORIGINAL']],[('a.txt',b'demo')]);await blocked('uppercase expected digest blocked','SHA-256')
  await run([record('a.txt',b'demo')],[('a.txt',b'demo')]);await page.fill('#manifest','file_name,size_bytes,sha256,rights\n"open,4,abc,ORIGINAL');await page.click('#review');await blocked('unclosed CSV quoted cell rejected','Unclosed quoted field')
  await page.fill('#manifest','X'*(64*1024+1));await page.click('#review');await blocked('oversized pasted manifest blocked','64 KiB')
  await run([record(f'F{i:02d}.txt',b'x') for i in range(41)],[('F00.txt',b'x')]);await blocked('41 manifest records blocked','1–40')
  await run([record('a.txt',b'demo')],[('a.txt',b'X'*(4*1024*1024+1))]);await blocked('large actual file blocked before hashing','4 MiB')
  # Import manifest from browser file input and prove stale export invalidation.
  await run([record('a.txt',b'demo')],[('a.txt',b'demo')]);await page.set_input_files('#manifestFile',{'name':'fake.csv','mimeType':'text/csv','buffer':csv_data([record('a.txt',b'demo','UNKNOWN')]).encode()})
  await until_value('manifest','UNKNOWN')
  check('manifest file import invalidates previous export',await page.locator('#outTXT').is_disabled())
  await page.click('#review');await await_review();check('imported manifest re-audited','RIGHTS_UNKNOWN' in (await down('outCSV'))[1])
  await page.set_input_files('#manifestFile',{'name':'fake.html','mimeType':'text/html','buffer':b'not csv'})
  await until_text('err','.csv')
  check('manifest file rejects HTML extension',await page.locator('#outCSV').is_disabled())
  await page.set_input_files('#manifestFile',{'name':'too_big.csv','mimeType':'text/csv','buffer':b'X'*(64*1024+1)})
  await until_text('err','64 KiB')
  check('manifest file enforces limit before read',await page.locator('#outCSV').is_disabled())
  await run([record('fake.json',b'{"fictional":true}\n')],[('fake.json',b'{"fictional":true}\n')]);check('structured json bytes hashed without JSON parsing',await value('mMatches')=='1')
  await run([record('mock.pdf',b'%PDF-1.4\nnot valid PDF, synthetic only\n')],[('mock.pdf',b'%PDF-1.4\nnot valid PDF, synthetic only\n')]);check('synthetic PDF-like bytes hashed without PDF open',await value('mMatches')=='1')
  check('no JavaScript runtime errors',not errors,errors)
  check('no outbound requests',not network,network)
  await browser.close()
async def run_tests():
 try:await main_suite()
 except Exception as e:TESTS.append({'test':'UNHANDLED_BROWSER_TEST_ERROR','pass':False,'detail':repr(e)[:180]});print('TEST ERROR',repr(e),flush=True);traceback.print_exc()
 finally:
  result={'tool':'19_Evidence_Bundle_Integrity_Check.html','environment':'Actual Chromium in-memory app assets, synthetic File objects only','assertions':len(TESTS),'passed':sum(x['pass'] for x in TESTS),'failed':sum(not x['pass'] for x in TESTS),'tests':TESTS,'independentExtractedDesktopVerified':False,'independentMobileVerified':False,'clientAcceptanceVerified':False,'manifestSignatureVerified':False,'realDataUsed':False,'published':False}
  (ROOT/'tests/bundle_integrity_test_results.json').write_text(json.dumps(result,indent=2)+'\n');print('SUMMARY',result['passed'],'/',result['assertions'],'FAILED',result['failed'],flush=True)
  if result['failed']:raise SystemExit(1)
if __name__=='__main__':asyncio.run(run_tests())
