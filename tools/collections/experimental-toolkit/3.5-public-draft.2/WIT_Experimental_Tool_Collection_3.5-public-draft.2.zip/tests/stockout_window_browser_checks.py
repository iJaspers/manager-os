"""Private synthetic-input stock window test. Actual Chromium, app loaded in-memory; never independent desktop, mobile, customer or host verification."""
import asyncio,csv,io,json,pathlib,copy,traceback
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=ROOT/'tests/stockout_window_test_results.json'
checks=[]
def check(name,yes,detail=''):
 yes=bool(yes);checks.append({'test':name,'passed':yes,'detail':str(detail)[:200]});print(('PASS' if yes else 'FAIL')+' '+name,flush=True)
 if not yes:raise AssertionError(name+': '+str(detail))
def rows(raw):return list(csv.reader(io.StringIO(raw)))
def txt(rs):
 s=io.StringIO();csv.writer(s,lineterminator='\n').writerows(rs);return s.getvalue()
RISK=rows((ROOT/'examples/inventory_risk_fictional.csv').read_text())
CLEAN=rows((ROOT/'examples/inventory_steady_fictional.csv').read_text())
async def run():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
  page=await browser.new_page(accept_downloads=True)
  errors=[];network=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('request',lambda r:network.append(r.url))
  html=(ROOT/'24_Stockout_Replenishment_Window.html').read_text().replace('<link rel="stylesheet" href="styles.css">','<style>'+(ROOT/'styles.css').read_text()+'</style>').replace('<script src="common.js"></script>','<script>'+(ROOT/'common.js').read_text()+'</script>')
  await page.set_content(html,wait_until='load')
  async def inner(id):return (await page.locator('#'+id).inner_text()).strip()
  async def apply(data=RISK,asof='2026-10-24'):
   await page.locator('#asOf').fill(asof)
   await page.locator('#stock').fill(txt(data) if isinstance(data,list) else data)
   await page.click('#review')
  async def expect_error(fragment):
   msg=await inner('error');check('blocked invalid '+fragment,'INPUT BLOCKED' in await inner('status') and fragment.lower() in msg.lower() and await page.locator('#exportCSV').is_disabled(),msg)
  async def export(id):
   async with page.expect_download() as pending:await page.click('#'+id)
   obj=await pending.value;return obj.suggested_filename,pathlib.Path(await obj.path()).read_text()
  async def modify(row,col,val):
   rs=copy.deepcopy(RISK);rs[row][col]=val;await apply(rs)
  check('default fictional demo loaded',await inner('mItems')=='5')
  check('default detects two projected-stockout rows',await inner('mShort')=='2')
  check('default detects two supplier-held rows',await inner('mSuppliers')=='2')
  found=await inner('findings')
  for code in ['PROJECTED_STOCKOUT_BEFORE_COVER','SAFETY_STOCK_BREACH','REPLENISHMENT_PLANNING_GAP','STALE_PHYSICAL_COUNT','DEMAND_SOURCE_UNKNOWN','ZERO_RECENT_USAGE','INBOUND_NOT_CONFIRMED','RESERVATIONS_EXCEED_STOCK','SUPPLIER_UNAVAILABLE_OR_UNCERTAIN','INBOUND_TOO_LATE_FOR_HORIZON','CURRENT_FREE_STOCK_BELOW_BUFFER','SUPPLIER_INBOUND_NOT_CREDITED']:
   check('fictional default flags '+code,code in found)
  check('supplier-held inbound excluded', 'Patch cable (SKU-CABLE)\t-2\t3\t0\t10' in await inner('overview'),await inner('overview'))
  check('latch gap pack rounds 14','Door latch kit (SKU-LATCH)\t3\t14\t0\t14' in await inner('overview'))
  check('stockout day4 from reported consumption','day 4;' in found)
  name,data=await export('exportCSV');check('private CSV download',name.startswith('PRIVATE_FICTIONAL_'))
  r=rows(data)
  check('CSV issue schema',r[0]==['sku_id','priority','issue_code','human_next_action'])
  check('CSV fictional stockout',any(v[0]=='SKU-LATCH' and v[2]=='PROJECTED_STOCKOUT_BEFORE_COVER' for v in r[1:]))
  name,data=await export('exportTXT')
  check('TXT prevents purchase claim','NOT purchase orders' in data and 'NOT VERIFIED' in data)
  check('TXT includes cost only private', 'Door latch kit' in data and 'CAD' in data)
  name,data=await export('exportJSON');j=json.loads(data)
  check('counts-only JSON schema',j['schema']=='PD-STOCKOUT-WINDOW-1' and j['distribution']=='PRIVATE_COUNTS_ONLY')
  check('JSON projected counts',j['counts']['items']==5 and j['counts']['projectedStockoutItems']==2 and j['counts']['supplierHoldItems']==2)
  for raw in ['SKU-LATCH','SKU-CABLE','Door latch kit','45.00','2026-10-24','COUNT-A','Patch cable']:
   check('no private data in AI export '+raw,raw not in data)
  for k in ['inventoryVerified','demandVerified','supplierVerified','etaVerified','costsVerified','procurementAuthorized','customerApprovalVerified','permissionToPublish','revenueReceivedVerified']:
   check('AI export never asserts '+k,j[k] is False)
  check('AI requires independent human review',j['humanDecisionRequired'] is True)
  await page.click('#demoClean')
  check('steady case has 2 inventory lines',await inner('mItems')=='2')
  check('steady case no stockout',await inner('mShort')=='0')
  check('steady case no findings', 'NO_REGISTER_EXCEPTION' in await inner('findings'))
  check('steady case never approves procurement','NO AUTOMATIC PURCHASE' in await inner('status'))
  await page.locator('#stock').fill('')
  check('editing data invalidates stale exports',await page.locator('#exportTXT').is_disabled() and 'NOT REVIEWED' in await inner('status'))
  await page.click('#demoRisk')
  await page.locator('#asOf').fill('2026-10-25')
  check('changing model date disables exports',await page.locator('#exportJSON').is_disabled())
  await page.click('#review')
  check('changing model date recalculates','STALE_PHYSICAL_COUNT' in await inner('findings'))
  # Isolated named holds and model semantics.
  await modify(1,10,'0.00');check('zero cost hold','UNIT_COST_UNSUPPORTED' in await inner('findings'))
  await modify(1,11,'uncertain');check('uncertain supplier hold','SUPPLIER_UNAVAILABLE_OR_UNCERTAIN' in await inner('findings'))
  await modify(1,11,'discontinued');check('discontinued supplier block','BLOCK' in await inner('status') and 'SUPPLIER_UNAVAILABLE_OR_UNCERTAIN' in await inner('findings'))
  await modify(1,4,'0');check('inventory unused review','ZERO_RECENT_USAGE' in await inner('findings'))
  await modify(1,13,'UNKNOWN');check('demand trace uncertainty','DEMAND_SOURCE_UNKNOWN' in await inner('findings'))
  await modify(1,12,'2026-10-01');check('stale count detected','STALE_PHYSICAL_COUNT' in await inner('findings'))
  await modify(1,2,'1');check('negative availability reported','RESERVATIONS_EXCEED_STOCK' in await inner('findings'))
  # Confirmed supply arriving today is NOT available day zero, but arrives tomorrow.
  sample=copy.deepcopy(CLEAN);sample[1][2]='0';sample[1][3]='1';sample[1][4]='30';sample[1][5]='5';sample[1][6]='0';sample[1][7]='10';sample[1][8]='2026-10-24';sample[1][9]='confirmed'
  await apply(sample)
  check('same-day reported inbound does not erase immediate day0 stockout','PROJECTED_STOCKOUT_BEFORE_COVER' in await inner('findings'))
  check('same-day confirmed inbound counted by horizon','Backplate set (SKU-PLATE)\t-1\t5\t10\t0' in await inner('overview'))
  sample[1][8]='2026-10-23';await apply(sample)
  check('past-due ETA never credited','Backplate set (SKU-PLATE)\t-1\t5\t0\t10' in await inner('overview'))
  check('past-due ETA flagged','PAST_DUE_INBOUND' in await inner('findings'))
  sample[1][8]='2026-10-29';await apply(sample)
  check('inbound arriving on final horizon day excluded','Backplate set (SKU-PLATE)\t-1\t5\t0\t10' in await inner('overview'))
  check('horizon ETA documented as too late','INBOUND_TOO_LATE_FOR_HORIZON' in await inner('findings'))
  sample[1][8]='2026-10-26';sample[1][9]='unconfirmed';await apply(sample)
  check('unconfirmed arrival excluded','Backplate set (SKU-PLATE)\t-1\t5\t0\t10' in await inner('overview'))
  check('unconfirmed arrival hold','INBOUND_NOT_CONFIRMED' in await inner('findings'))
  sample[1][8]='';await apply(sample)
  check('missing unconfirmed ETA held','INBOUND_DATE_UNKNOWN' in await inner('findings'))
  # Pack multiple must round up and costs must retain cents exactly.
  sample=copy.deepcopy(CLEAN);sample[1][2]='0';sample[1][3]='0';sample[1][4]='10';sample[1][5]='7';sample[1][6]='1';sample[1][14]='5';sample[1][10]='1.23';await apply(sample)
  check('pack multiple rounds 4 need up to 5','Backplate set (SKU-PLATE)\t0\t3\t0\t5' in await inner('overview'))
  _,private=await export('exportTXT');check('exact cents in private output','gap CAD $6.15' in private,private[:350])
  # malformed CSV and semantics fail closed.
  bad=[(1,0,'SKU-BOLT','duplicate sku_id'),(1,0,'LOWER','duplicate improbable'),(1,0,'sku-test','uppercase code'),(1,0,'=SUM(A1)','uppercase code'),(1,1,'=HYPERLINK("bad")','short fictional'),(1,1,'sales@example.com','short fictional'),(1,1,'https://bad.example','short fictional'),(1,1,'<img src=x onerror=alert(1)>','short fictional'),(1,1,'A'*90,'short fictional'),(1,2,'-1','nonnegative whole'),(1,2,'1.1','nonnegative whole'),(1,2,'1e3','nonnegative whole'),(1,2,'100001','between 0 and'),(1,4,'NaN','nonnegative whole'),(1,5,'0','between 1 and'),(1,5,'181','between 1 and'),(1,7,'999999','between 0 and'),(1,9,'arrived','incoming_state'),(1,10,'12.345','exact nonnegative'),(1,10,'100000.01','exact nonnegative'),(1,11,'approved','supplier_state'),(1,12,'2026-02-29','not a valid calendar'),(1,12,'2026-10-25','cannot occur after'),(1,13,'https://source.example','fictional uppercase'),(1,14,'0','between 1 and'),(1,14,'10001','between 1 and')]
  for row,col,val,frag in bad:
   if val=='LOWER':continue
   await modify(row,col,val);await expect_error(frag)
  r=copy.deepcopy(RISK);r[1][0]=r[2][0];await apply(r);await expect_error('duplicate sku_id')
  r=copy.deepcopy(RISK);r[1][9]='none';await apply(r);await expect_error('state none') if r[1][7]!='0' else None
  r=copy.deepcopy(RISK);r[1][7]='4';await apply(r);await expect_error('state none')
  r=copy.deepcopy(RISK);r[1][9]='confirmed';r[1][7]='1';r[1][8]='';await apply(r);await expect_error('requires a valid arrival date')
  r=copy.deepcopy(RISK);r[1][9]='unconfirmed';r[1][7]='0';await apply(r);await expect_error('requires positive quantity')
  await apply('junk');await expect_error('exact 15-column')
  await apply(txt([RISK[0]]));await expect_error('between 1 and 80')
  await apply(txt([RISK[0]]+[RISK[1]]*81));await expect_error('between 1 and 80')
  await apply(txt([RISK[0],RISK[1][:-1]]));await expect_error('wrong column count')
  await apply(txt(RISK)+'A'*96000);await expect_error('95KB')
  await apply(txt(RISK)+'\n"unclosed');await expect_error('unclosed quoted')
  r=copy.deepcopy(RISK);r[1][1]='A\x01B';await apply(r);await expect_error('unsafe control')
  r=copy.deepcopy(RISK);r[1][1]='A\nB';await apply(r);await expect_error('short fictional')
  msg=await page.evaluate("(s)=>{try{dayDate(s,'model date');return 'accepted'}catch(e){return e.message}}",'2026-02-29')
  check('date model rejects impossible Feb 29','not a valid calendar date' in msg,msg)
  msg=await page.evaluate("(s)=>{try{dayDate(s,'model date');return 'accepted'}catch(e){return e.message}}",'1980-01-01')
  check('date model rejects out-of-bounds year','outside supported date years' in msg,msg)
  # local file import via file input, only fictional CSV. Use real Chromium file API but still page in memory.
  await page.click('#demoClean')
  await page.set_input_files('#stockFile',str(ROOT/'examples/inventory_risk_fictional.csv'))
  await asyncio.sleep(.2)
  check('file import brings fictional stock into textarea','SKU-LATCH' in await page.locator('#stock').input_value())
  check('file import invalidates previous exports',await page.locator('#exportCSV').is_disabled())
  await page.click('#review')
  check('imported inventory computes projected shortages',await inner('mShort')=='2')
  await page.set_input_files('#stockFile',{'name':'not_a_csv.txt','mimeType':'text/plain','buffer':b'foo'})
  await expect_error('only invented CSV')
  # security baseline, no outbound request.
  await page.click('#demoRisk')
  check('CSP denies network',"connect-src 'none'" in html)
  check('no storage or request APIs',not any(x in html for x in ['localStorage','sessionStorage','indexedDB','fetch(','XMLHttpRequest(']))
  check('no attempted network traffic',not network,network)
  check('no browser JS exceptions',not errors,errors)
  await browser.close()
  OUT.write_text(json.dumps({'suite':'stockout_window_browser_checks','checks':len(checks),'passed':len(checks),'failed':0,'in_memory_chromium':True,'independent_desktop_tested':False,'independent_mobile_tested':False,'real_customer_tested':False,'published':False,'details':checks},indent=2))
if __name__=='__main__':
 try:asyncio.run(run())
 except Exception:
  OUT.write_text(json.dumps({'suite':'stockout_window_browser_checks','checks':len(checks),'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'in_memory_chromium':True,'traceback':traceback.format_exc(),'details':checks},indent=2))
  traceback.print_exc();raise
