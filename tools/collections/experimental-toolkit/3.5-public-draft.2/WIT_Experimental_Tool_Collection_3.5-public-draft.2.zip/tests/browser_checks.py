"""Run against local HTML with: python tests/browser_checks.py (Chromium + Playwright)."""
import asyncio, json, pathlib, traceback
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
RESULTS=[]

def check(name, outcome, note=""):
    RESULTS.append({"test":name,"pass":bool(outcome),"detail":str(note)})
    if not outcome: raise AssertionError(name+': '+str(note))

async def main():
  async with async_playwright() as p:
    browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=await browser.new_page(accept_downloads=True)
    async def go(name):
      nonlocal page
      await page.close()
      page=await browser.new_page(accept_downloads=True)
      html=(ROOT/name).read_text(); html=html.replace('<link rel="stylesheet" href="styles.css">','<style>'+ (ROOT/'styles.css').read_text() + '</style>'); html=html.replace('<script src="common.js"></script>', '<script>'+(ROOT/'common.js').read_text()+'</script>'); await page.set_content(html,wait_until='load')

    await go('01_Project_Quote_Builder.html')
    check('quote initial value',await page.locator('#mprice').inner_text()=='$499.00')
    check('quote advance rounding',await page.locator('#mupfront').inner_text()=='$249.50')
    check('quote balance',await page.locator('#mremain').inner_text()=='$249.50')
    await page.select_option('#upfront','40');await page.click('#build')
    check('quote 40% advance',await page.locator('#mupfront').inner_text()=='$199.60')
    check('quote 40% balance',await page.locator('#mremain').inner_text()=='$299.40')
    await page.fill('#price','299.99');await page.select_option('#upfront','30');await page.click('#build')
    check('quote cents rounding',await page.locator('#mupfront').inner_text()=='$90.00')
    await page.fill('#price','x');await page.click('#build')
    check('quote rejects nonnumeric',bool(await page.locator('#err').inner_text()) and await page.locator('#export').is_disabled())
    await page.fill('#price','200');await page.fill('#project','<img src=x onerror=alert(123)>');await page.click('#build')
    check('quote injected HTML displayed literally', '<img src=x onerror=alert(123)>' in await page.locator('#quote').inner_text() and await page.locator('#quote img').count()==0)
    async with page.expect_download() as d:
      await page.click('#export')
    downloaded=await d.value
    check('quote export filename',downloaded.suggested_filename.endswith('.txt'))

    await go('02_Door_Register_Auditor.html')
    check('auditor sample count',await page.locator('#mrows').inner_text()=='7')
    check('auditor distinct ids',await page.locator('#munique').inner_text()=='5')
    findings=await page.locator('#results tr').all_inner_texts()
    check('auditor catches duplicate',any('DUPLICATE_ID' in v for v in findings))
    check('auditor catches missing id',any('MISSING_ID' in v for v in findings))
    check('auditor catches completed with open issue',any('COMPLETE_WITH_OPEN_ISSUE' in v for v in findings))
    check('auditor catches unknown status',any('INVALID_STATUS' in v for v in findings))
    check('auditor counts affected rows once',await page.locator('#mopen').inner_text()=='5')
    await page.fill('#csv','door_id,status,hardware,issue_open,source,notes\n"D,1",complete,"Lock, A",no,ref,"Note with \"\"quote\"\""')
    await page.click('#audit')
    check('quoted CSV correct parse',await page.locator('#mrows').inner_text()=='1' and await page.locator('#missues').inner_text()=='0')
    await page.fill('#csv','door_id,status,hardware,issue_open,source,notes\n="=HYPERLINK(\"\"https://evil.test\"\")",complete,,yes,,bad')
    await page.click('#audit')
    async with page.expect_download() as d:
      await page.click('#export')
    csv=await (await d.value).path();content=pathlib.Path(csv).read_text()
    check('CSV export spreadsheet formula guard',"'=" in content)
    await page.fill('#csv','door_id,status\n"unclosed,complete');await page.click('#audit')
    check('auditor rejects malformed CSV',bool(await page.locator('#err').inner_text()) and await page.locator('#export').is_disabled())
    await page.locator('#file').set_input_files(str(ROOT/'examples'/'door_register_fictional.csv'))
    await page.wait_for_function("document.getElementById('mrows').textContent === '7'",timeout=5000)
    check('auditor uploads local sample',await page.locator('#mrows').inner_text()=='7')

    await go('03_Publication_Readiness_Gate.html')
    await page.click('#review')
    check('publication defaults to HOLD', 'HOLD' in await page.locator('#status').inner_text())
    for box in await page.locator('#checks input[type="checkbox"]').all(): await box.check()
    await page.click('#review')
    check('publication never auto approves', 'HUMAN_REVIEW_REQUIRED' in await page.locator('#status').inner_text())
    await page.locator('#checks input[type="checkbox"]').first.uncheck()
    check('publication change invalidates review', await page.locator('#save').is_disabled())
    await browser.close()

try:
    asyncio.run(main())
except Exception as e:
    RESULTS.append({"test":"uncaught", "pass":False, "detail":str(e) + '\n'+traceback.format_exc()})
finally:
    report={"test_count":len(RESULTS),"passed":sum(x['pass'] for x in RESULTS),"failed":sum(not x['pass'] for x in RESULTS),"results":RESULTS}
    (ROOT/'tests'/'test_results.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({k:report[k] for k in ['test_count','passed','failed']},indent=2))
    for item in RESULTS:
        if not item['pass']: print('FAIL',item)
    if report['failed']: raise SystemExit(1)
