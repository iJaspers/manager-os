"""Revenue Lab v0.4: actual headless Chromium DOM/download behavioral checks. No client data."""
import asyncio, json, pathlib, traceback
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
RESULTS=[]
def check(label, condition, detail=''):
    r={'test':label,'pass':bool(condition),'detail':str(detail)[:800]}
    RESULTS.append(r)
    if not condition: raise AssertionError(label+': '+str(detail))
B='project_id,scope_id,item,acceptance,class\nDEMO,S-001,Invented base deliverable,Tested on fictional rows,included\nDEMO,S-002,Private file disclosure,Not allowed,excluded'
CH='project_id,change_id,scope_id,request,kind,delta_cad,days_delta,status,review_ref'
OK='DEMO,C-01,,Add synthetic output,add,125.00,1,approval_reported,TEST-ONLY'
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  page=await browser.new_page(accept_downloads=True)
  requests=[];errors=[]
  page.on('request',lambda req:requests.append(req.url))
  page.on('pageerror',lambda exc:errors.append(str(exc)))
  html=(ROOT/'06_Change_Order_Scope_Guard.html').read_text()
  html=html.replace('<link rel="stylesheet" href="styles.css">','<style>'+(ROOT/'styles.css').read_text()+'</style>')
  html=html.replace('<script src="common.js"></script>','<script>'+(ROOT/'common.js').read_text()+'</script>')
  await page.set_content(html,wait_until='load')
  async def codes():return await page.locator('#results td:nth-child(3)').all_inner_texts()
  async def set_case(change=OK,baseline=B,fee='800.00',project='DEMO'):
   await page.fill('#baseline',baseline)
   await page.fill('#changes',CH+'\n'+change)
   await page.fill('#fee',fee)
   await page.fill('#project',project)
   await page.click('#audit')
  async def issue(label,code,change=OK,baseline=B,fee='800.00',project='DEMO'):
   await set_case(change,baseline,fee,project)
   values=await codes()
   check(label,code in values,values)
  check('initial fictional sample included', 'C-001' in await page.locator('#changes').input_value())
  values=await codes()
  check('sample has pending change review','CHANGE_NOT_ACCEPTED' in values,values)
  check('sample catches missing reported approval','MISSING_APPROVAL_REFERENCE' in values,values)
  check('sample detects orphan original scope','UNKNOWN_SCOPE_REF' in values,values)
  check('sample detects forbidden excluded baseline','EXCLUDED_SCOPE_ITEM' in values,values)
  check('sample displays status HOLD','HOLD' in await page.locator('#status').inner_text())
  check('no network after sample render',not requests,requests)
  check('3 exports enabled on valid structured input',all([await page.locator('#'+id).is_enabled() for id in ['csvexport','jsonexport','textexport']]))
  async with page.expect_download() as d:await page.click('#csvexport')
  exported=pathlib.Path(await (await d.value).path()).read_text()
  check('exception CSV export written','UNKNOWN_SCOPE_REF' in exported and 'change_id' in exported)
  async with page.expect_download() as d:await page.click('#jsonexport')
  exported=pathlib.Path(await (await d.value).path()).read_text(); obj=json.loads(exported)
  check('AI minimal contract schema and approvals false',obj['schema']=='PD-CHANGE-1' and obj['paymentReceivedVerified'] is False and obj['publicReleaseApproved'] is False and obj['contractAccepted'] is False)
  check('JSON excludes sensitive raw text','dashboard export' not in exported and 'Publish excluded' not in exported and 'Invented base' not in exported)
  check('JSON returns reported delta no payment claim',obj['approvalReportedDeltaCentsUnverified']==9000 and obj['illustrativeTotalIfAllActiveAcceptedCents']==147000,obj)
  async with page.expect_download() as d:await page.click('#textexport')
  exported=pathlib.Path(await (await d.value).path()).read_text()
  check('private text draft accurately labelled','NOT independently verified' in exported and 'no signed contract' in exported.lower())
  await page.click('#clean')
  check('clean case no HARD hold','HOLD' not in await page.locator('#status').inner_text())
  check('clean case only reported review',await codes()==['APPROVAL_UNVERIFIED'],await codes())
  check('clean cents arithmetic correct',await page.locator('#mreported').inner_text()=='$125.00' and await page.locator('#mtotal').inner_text()=='$925.00')
  await issue('duplicate change ID','DUPLICATE_CHANGE_ID',OK+'\n'+OK)
  check('duplicate change blocks financial totals',await page.locator('#mtotal').inner_text()=='WITHHELD')
  await issue('duplicate baseline ID','DUPLICATE_SCOPE_ID',OK,B+'\nDEMO,S-001,Clone,Same,included')
  await issue('mismatched change project','CHANGE_PROJECT_MISMATCH',OK.replace('DEMO,C-01','OTHER,C-01'))
  check('mismatched project blocks financial totals',await page.locator('#mtotal').inner_text()=='WITHHELD')
  await issue('mismatched original project','BASELINE_PROJECT_MISMATCH',OK,B.replace('DEMO,S-001','OTHER,S-001'))
  await issue('missing change description','MISSING_CHANGE_DESCRIPTION',OK.replace('Add synthetic output',''))
  await issue('unknown kind','INVALID_CHANGE_KIND',OK.replace(',add,',',trick,'))
  await issue('unknown request status','INVALID_DECISION_STATE',OK.replace(',approval_reported,',',paid,'))
  await issue('modification missing original ID','MISSING_SCOPE_REF',OK.replace(',add,',',modify,'))
  await issue('modification not in baseline','UNKNOWN_SCOPE_REF',OK.replace('C-01,,','C-01,S-404,').replace(',add,',',modify,'))
  await issue('modification excluded item held','EXCLUDED_SCOPE_ITEM',OK.replace('C-01,,','C-01,S-002,').replace(',add,',',modify,'))
  await issue('addition to explicitly excluded item held','EXCLUDED_SCOPE_ITEM',OK.replace('C-01,,','C-01,S-002,'))
  await issue('zero-priced add flags scope-creep exposure','UNPRICED_EXTRA_WORK',OK.replace('125.00','0.00'))
  await issue('negative add requires review','ADDITION_NEGATIVE_FEE',OK.replace('125.00','-10.00'))
  await issue('positive removal price requires review','REMOVAL_POSITIVE_FEE',OK.replace('C-01,,','C-01,S-001,').replace(',add,',',remove,'))
  await issue('clarification pricing requires review','CLARIFICATION_HAS_FEE',OK.replace('C-01,,','C-01,S-001,').replace(',add,',',clarify,'))
  await issue('incomplete original acceptance','INCOMPLETE_BASELINE',OK,B.replace('Tested on fictional rows',''))
  await issue('missing approval reference held','MISSING_APPROVAL_REFERENCE',OK.replace('TEST-ONLY',''))
  await issue('extra requested but not approved','CHANGE_NOT_ACCEPTED',OK.replace('approval_reported','quoted'))
  await issue('removed scope negative amount gives credit','APPROVAL_UNVERIFIED',OK.replace('C-01,,','C-01,S-001,').replace('add,-','remove,-').replace('add,125.00','remove,-50.00'))
  check('credit arithmetic exact',await page.locator('#mtotal').inner_text()=='$750.00')
  await issue('invalid currency exponent rejected','INVALID_PRICE_DELTA',OK.replace('125.00','1e5'))
  check('invalid money withholds all dollar totals','WITHHELD' in await page.locator('#mtotal').inner_text() and 'WITHHELD' in await page.locator('#mpending').inner_text())
  await issue('three decimal places rejected','INVALID_PRICE_DELTA',OK.replace('125.00','12.345'))
  await issue('invalid day delta rejected','INVALID_DAYS_DELTA',OK.replace(',1,approval_reported',',1.5,approval_reported'))
  await issue('invalid huge day delta rejected','INVALID_DAYS_DELTA',OK.replace(',1,approval_reported',',366,approval_reported'))
  await issue('negative total flags implausible credits','NEGATIVE_POTENTIAL_TOTAL',OK.replace('C-01,,','C-01,S-001,').replace('add,125.00','remove,-900.00'))
  check('negative total withheld',await page.locator('#mtotal').inner_text()=='WITHHELD')
  await issue('declined scope ignored in financial sum','APPROVAL_UNVERIFIED',OK) # first reset
  await set_case(OK+'\nDEMO,C-02,,Unused declined add,add,100000.00,2,declined,')
  check('declined not counted',await page.locator('#mtotal').inner_text()=='$925.00' and await page.locator('#mchanges').inner_text()=='2')
  # Properly quoted multiline, no script execution or HTML DOM injection.
  hostile='DEMO,C-01,,"<img src=x onerror=alert(1)>; fictional, note\nwith ""quotes""",add,125.00,1,quoted,'
  await set_case(hostile)
  check('hostile CSV description processed as inert text','CHANGE_NOT_ACCEPTED' in await codes())
  check('hostile markup never adds IMG node',await page.locator('img').count()==0)
  async with page.expect_download() as d: await page.click('#jsonexport')
  js=pathlib.Path(await (await d.value).path()).read_text()
  check('AI handoff excludes injection payload','<img' not in js and 'onerror' not in js)
  # Absent/invalid headers and columns fail closed.
  await page.fill('#baseline','project_id,scope_id,scope_id,acceptance,class\nDEMO,S-01,x,y,included')
  await page.click('#audit')
  check('duplicate/malformed header fails closed','exact ordered columns' in await page.locator('#err').inner_text() and await page.locator('#csvexport').is_disabled())
  await page.fill('#baseline',B);await page.fill('#changes',CH+'\nDEMO,C-01,,"unclosed,add,125.00,1,quoted,')
  await page.click('#audit')
  check('unclosed quote fails closed','Unclosed quoted field' in await page.locator('#err').inner_text() and await page.locator('#jsonexport').is_disabled())
  await page.fill('#changes',CH+'\n'+OK);await page.fill('#fee','99999999.00');await page.click('#audit')
  check('oversized base price fails closed','Base price' in await page.locator('#err').inner_text())
  await page.fill('#fee','800.00');await page.fill('#project','=HYPERLINK()');await page.click('#audit')
  check('hostile spreadsheet project ID rejected','Project ID' in await page.locator('#err').inner_text())
  await page.fill('#project','DEMO');await page.fill('#changes',CH+'\n'+OK);await page.click('#audit')
  await page.fill('#fee','850.00')
  check('edit invalidates prior exports',await page.locator('#csvexport').is_disabled() and 'Inputs changed' in await page.locator('#status').inner_text())
  # Inputs as actual local files, without network or server.
  await page.locator('#basefile').set_input_files(str(ROOT/'examples'/'change_baseline_fictional.csv'))
  await page.locator('#changesfile').set_input_files(str(ROOT/'examples'/'change_requests_fictional.csv'))
  await page.wait_for_timeout(180)
  await page.click('#audit')
  check('local CSV-file import reads synthetic source',await page.locator('#mchanges').inner_text()=='4')
  check('local CSV-file import preserves original baseline',await page.locator('#baseline').input_value()==(ROOT/'examples'/'change_baseline_fictional.csv').read_text())
  # Restrict excessive rows to a bounded local process.
  await page.fill('#changes',CH+'\n'+ '\n'.join('DEMO,C-'+str(i)+',,Add item,add,1.00,0,new,' for i in range(501)))
  await page.click('#audit')
  check('over 500 rows fail closed','more than 500' in await page.locator('#err').inner_text() and await page.locator('#jsonexport').is_disabled())
  check('no unexpected network requests',not requests,requests)
  check('no browser script exceptions',not errors,errors)
  await browser.close()
try:
 asyncio.run(main())
except Exception as exc:
 RESULTS.append({'test':'uncaught','pass':False,'detail':str(exc)+'\n'+traceback.format_exc()})
finally:
 out={'test_count':len(RESULTS),'passed':sum(x['pass'] for x in RESULTS),'failed':sum(not x['pass'] for x in RESULTS),'results':RESULTS,
 'environment':'Actual headless Chromium in-memory DOM test with inline local shared JS/CSS; not file:// install, mobile, real user or hosted deployment'}
 (ROOT/'tests'/'change_test_results.json').write_text(json.dumps(out,indent=2))
 print(json.dumps({k:out[k] for k in ('test_count','passed','failed')}))
 for x in RESULTS:
  if not x['pass']: print('FAILED',x)
 if out['failed']:raise SystemExit(1)
