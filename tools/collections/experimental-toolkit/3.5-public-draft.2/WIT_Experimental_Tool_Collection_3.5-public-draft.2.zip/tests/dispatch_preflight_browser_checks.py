"""Synthetic-only Chromium in-memory execution. NOT independent desktop/mobile/site acceptance."""
import asyncio,csv,io,json,pathlib,traceback,copy
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=ROOT/'tests/dispatch_preflight_test_results.json'
T=[]
def check(name,result,detail=''):
    obj=dict(test=name,passed=bool(result),detail=str(detail)[:180]);T.append(obj)
    print(('PASS' if result else 'FAIL')+' '+name,flush=True)
    if not result:raise AssertionError(name+': '+str(detail))
HDR='visit_id,site_id,visit_date,window_start,window_end,access_state,access_ref,contact_state,escort_required,escort_state,parts_state,parts_ref,tools_ready,safety_class,safety_review,scope_ref,last_confirmed'.split(',')
CLEAN=[['VIS-101','SITE-A','2026-10-25','09:00','11:00','reported_confirmed','AUTH-01','reported_confirmed','yes','reported_confirmed','staged','PART-01','yes','routine','reported_done','SCOPE-01','2026-10-24'],['VIS-102','SITE-B','2026-10-26','13:00','15:00','reported_confirmed','AUTH-02','reported_confirmed','no','not_applicable','not_needed','','yes','routine','reported_done','SCOPE-02','2026-10-24']]
def csvtext(rows,header=HDR):
    b=io.StringIO();c=csv.writer(b,lineterminator='\n');c.writerow(header);c.writerows(rows);return b.getvalue()
async def run():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
  page=await browser.new_page(accept_downloads=True)
  errors=[];requests=[];page.on('pageerror',lambda x:errors.append(str(x)));page.on('request',lambda x:requests.append(x.url))
  html=(ROOT/'22_Site_Visit_Dispatch_Preflight.html').read_text().replace('<link rel="stylesheet" href="styles.css">','<style>'+(ROOT/'styles.css').read_text()+'</style>').replace('<script src="common.js"></script>','<script>'+(ROOT/'common.js').read_text()+'</script>')
  await page.set_content(html,wait_until='load')
  async def val(id):return (await page.locator('#'+id).inner_text()).strip()
  async def apply(data=CLEAN,date='2026-10-24'):
   await page.fill('#asOf',date)
   await page.fill('#visits',csvtext(data) if isinstance(data,list) else data)
   await page.click('#audit')
  async def findings():return await val('issues')
  async def down(ident):
   async with page.expect_download() as d:await page.click('#'+ident)
   v=await d.value
   return v.suggested_filename,pathlib.Path(await v.path()).read_text()
  async def blocked(word):
   err=await val('err');check('rejected '+word,(await val('status')).startswith('INPUT BLOCKED') and word.lower() in err.lower() and await page.locator('#outCSV').is_disabled(),err)
  async def mutated(index,value,which=0):
   a=copy.deepcopy(CLEAN);a[which][index]=value;await apply(a)
  # Default risk example and nonauthorization.
  check('auto load mixed risk demo',await val('mVisits')=='3')
  check('mixed blocked before dispatch','STOP' in await val('status'))
  mixed=await findings()
  for code in ['ACCESS_UNCONFIRMED','CONTACT_UNCONFIRMED','ESCORT_NOT_CONFIRMED','REQUIRED_PARTS_MISSING','TOOLS_NOT_CONFIRMED','SAFETY_REVIEW_PENDING','CONFIRMATION_STALE','ACCESS_REPORTED_DENIED','CONTACT_UNREACHABLE','SPECIALIST_SAFETY_REVIEW','PLANNED_DATE_PASSED','UNKNOWN_SAFETY_CLASS','SITE_WINDOW_OVERLAP']:
   check('mixed '+code,code in mixed)
  check('overlap affects both visits',mixed.count('SITE_WINDOW_OVERLAP')==2)
  check('stop-count nonzero',int(await val('mStops'))>=4)
  check('all risk rows held',await val('mHeld')=='3')
  name,data=await down('outCSV');parsed=list(csv.reader(io.StringIO(data)))
  check('CSV is private',name.startswith('PRIVATE_FICTIONAL_'))
  check('CSV contains correct finding columns',parsed[0]==['visit_id','priority','issue_code','human_next_action'])
  check('CSV contains correct fictional risk ID',any(x[0]=='VIS-201' and x[2]=='REQUIRED_PARTS_MISSING' for x in parsed[1:]))
  name,txt=await down('outTXT')
  check('TXT private, fictional and no dispatch','FICTIONAL' in txt and 'NO REAL SITE ACCESS' in txt and 'VIS-201' in txt)
  name,jdata=await down('outJSON');j=json.loads(jdata)
  check('AI JSON contract schema',j['schema']=='PD-SITE-PREFLIGHT-1' and j['distribution']=='PRIVATE_COUNTS_ONLY')
  check('AI JSON contains counts',j['counts']['visits']==3 and j['counts']['heldVisits']==3 and j['issueCounts']['SITE_WINDOW_OVERLAP']==2)
  check('AI JSON no sensitive fictional tokens',all(x not in jdata for x in ['SITE-A','VIS-201','AUTH-03','PART-03','SCOPE-01','2026-10-24','09:00']))
  for k in ['actualAccessRightsVerified','customerContactAuthorized','siteSafetyVerified','workerCompetenceVerified','partsPhysicallyVerified','dispatchAuthorized','permissionToSpend','permissionToPublish','revenueReceivedVerified']:
   check('AI JSON never grants '+k,j[k] is False)
  # Clean review proves no exception, never dispatch authorization.
  await page.click('#demoClean')
  check('clean 2 visits',await val('mVisits')=='2')
  check('clean findings zero',await val('mFindings')=='0' and await val('mHeld')=='0')
  check('clean still human dispatch hold','NOT AUTHORIZED TO DISPATCH' in await val('status'))
  name,jdata=await down('outJSON');check('clean JSON disclaims dispatch',json.loads(jdata)['dispatchAuthorized'] is False)
  await page.fill('#visits','');check('edit invalidates review',await page.locator('#outCSV').is_disabled() and 'NOT REVIEWED' in await val('status'))
  # Risk cases, precisely one input change per test.
  cases=[
   (5,'pending','ACCESS_UNCONFIRMED'),(5,'denied','ACCESS_REPORTED_DENIED'),(6,'','ACCESS_SOURCE_MISSING'),
   (7,'pending','CONTACT_UNCONFIRMED'),(7,'unreachable','CONTACT_UNREACHABLE'),
   (9,'pending','ESCORT_NOT_CONFIRMED'),(10,'missing','REQUIRED_PARTS_MISSING'),(10,'pending','PARTS_NOT_STAGED'),
   (11,'','PARTS_SOURCE_MISSING'),(12,'no','TOOLS_NOT_CONFIRMED'),
   (13,'specialist','SPECIALIST_SAFETY_REVIEW'),(13,'unknown','UNKNOWN_SAFETY_CLASS'),
   (14,'pending','SAFETY_REVIEW_PENDING'),(16,'','CONFIRMATION_DATE_MISSING'),(16,'2026-10-21','CONFIRMATION_STALE'),
   (2,'2026-10-22','PLANNED_DATE_PASSED'),(2,'2026-10-29','FUTURE_WINDOW_RECONFIRM'),
   (4,'09:20','SHORT_WINDOW_REVIEW')
  ]
  for ix,value,code in cases:
   await mutated(ix,value);check('isolated finding '+code,code in await findings())
  # Exact date and window boundaries.
  await mutated(16,'2026-10-22');check('2-day confirmation is fresh','CONFIRMATION_STALE' not in await findings())
  await mutated(2,'2026-10-27');check('3 days away does not trigger far future','FUTURE_WINDOW_RECONFIRM' not in await findings())
  await mutated(4,'09:30');check('exact 30-minute window accepted','SHORT_WINDOW_REVIEW' not in await findings())
  await mutated(4,'09:29');check('29-minute window held','SHORT_WINDOW_REVIEW' in await findings())
  await mutated(2,'2026-10-24');check('same-day date not automatically late','PLANNED_DATE_PASSED' not in await findings())
  await mutated(13,'specialist');check('reported safety done does not override specialist STOP', 'SPECIALIST_SAFETY_REVIEW' in await findings() and 'STOP' in await val('status'))
  a=copy.deepcopy(CLEAN);a[0][6]='';await apply(a);check('claimed access without reference still held','ACCESS_SOURCE_MISSING' in await findings())
  # Intentional overlap, adjacent windows, and different-site/date isolation.
  shared=copy.deepcopy(CLEAN);shared[1][1]='SITE-A';shared[1][2]='2026-10-25';shared[1][3]='10:30';shared[1][4]='12:30';await apply(shared)
  check('same site/date overlap 2 findings',(await findings()).count('SITE_WINDOW_OVERLAP')==2)
  shared[1][3]='11:00';await apply(shared);check('adjacent windows no overlap','SITE_WINDOW_OVERLAP' not in await findings())
  shared[1][3]='10:30';shared[1][1]='SITE-B';await apply(shared);check('different sites no overlap','SITE_WINDOW_OVERLAP' not in await findings())
  shared[1][1]='SITE-A';shared[1][2]='2026-10-26';await apply(shared);check('different dates no overlap','SITE_WINDOW_OVERLAP' not in await findings())
  # Strong rejection of incoherent schedule/privileged declarations.
  bad=[
   (0,'abc','uppercase code'),(1,'real.site@example.com','uppercase code'),
   (15,'=<script>','uppercase code'),(6,'+alert(1)','uppercase code'),(11,'x' * 24,'uppercase code'),
   (2,'2026-02-30','calendar date'),(2,'2026-13-01','calendar date'),(3,'24:00','strictly increasing'),
   (3,'9:00','strictly increasing'),(4,'09:00','strictly increasing'),(3,'11:00','strictly increasing'),
   (5,'yes','invalid access_state'),(7,'done','invalid contact_state'),(8,'maybe','invalid escort_required'),
   (10,'complete','invalid parts_state'),(12,'sure','invalid tools_ready'),(13,'safe','invalid safety_class'),
   (14,'done','invalid safety_review'),(16,'2026-10-25','last_confirmed cannot be after')]
  for ix,value,err in bad:
   await mutated(ix,value);await blocked(err)
  a=copy.deepcopy(CLEAN);a[1][0]=a[0][0];await apply(a);await blocked('Duplicate invented visit_id')
  a=copy.deepcopy(CLEAN);a[0][8]='yes';a[0][9]='not_applicable';await apply(a);await blocked('escort is required')
  a=copy.deepcopy(CLEAN);a[1][9]='pending';await apply(a);await blocked('escort is not required')
  a=copy.deepcopy(CLEAN);a[1][11]='PART-REF';await apply(a);await blocked('parts_ref must be empty')
  await apply('junk');await blocked('exact 17-column')
  await apply(csvtext([]));await blocked('between 1 and 180')
  await apply(csvtext(CLEAN,header=HDR[:-1]));await blocked('exact 17-column')
  await apply(csvtext(CLEAN)[:20]);await blocked('exact 17-column')
  await apply(csvtext([CLEAN[0][:-1]]));await blocked('exactly 17 columns')
  await apply(csvtext(CLEAN)+'z'*100001);await blocked('100KB')
  await apply(csvtext([CLEAN[0]]*181));await blocked('between 1 and 180')
  await apply(csvtext([[('<img src=x onerror=alert(1)>' if i==0 else x) for i,x in enumerate(CLEAN[0])]]));await blocked('uppercase code')
  await apply(csvtext([[('AB\x00CD' if i==0 else x) for i,x in enumerate(CLEAN[0])]]));await blocked('unsafe control-text')
  # Defend formula injection and unsafe DOM with validation, not merely CSS/encoding.
  await mutated(6,'=CMD');await blocked('uppercase code')
  await mutated(1,'<svg onload=alert(1)>');await blocked('uppercase code')
  check('malicious input did not execute',not errors,errors)
  await apply(CLEAN);check('recovers from errors',await val('mFindings')=='0')
  # Actual file import, download, stale-output controls.
  await page.locator('#importFile').set_input_files({'name':'synthetic.csv','mimeType':'text/csv','buffer':csvtext(CLEAN).encode()})
  check('CSV imported into text area',await page.locator('#visits').input_value()==csvtext(CLEAN))
  check('file import invalidates old exports',await page.locator('#outCSV').is_disabled())
  await page.click('#audit');check('file import audited',await val('mFindings')=='0')
  await page.locator('#importFile').set_input_files({'name':'synthetic.txt','mimeType':'text/plain','buffer':b'hello'})
  await blocked('only fictional .csv')
  await page.locator('#importFile').set_input_files({'name':'oversize.csv','mimeType':'text/csv','buffer':b'x'*100001})
  await blocked('100KB')
  check('files cannot silently re-enable exports',await page.locator('#outJSON').is_disabled())
  await apply(CLEAN);check('valid after bad file import',await val('mFindings')=='0')
  name,data=await down('outCSV');check('clean CSV export header survives',list(csv.reader(io.StringIO(data)))[0]==['visit_id','priority','issue_code','human_next_action'])
  check('no network calls',not requests,requests)
  check('no JS exceptions',not errors,errors)
  source=(ROOT/'22_Site_Visit_Dispatch_Preflight.html').read_text()
  check('network blocked by CSP',"connect-src 'none'" in source)
  check('no storage or fetch APIs',not any(x in source for x in ['localStorage','sessionStorage','indexedDB','fetch(','XMLHttpRequest']))
  check('human authorization prominently required','Only an authorized human may dispatch' in await page.locator('main').inner_text())
  await browser.close()
  result=dict(tool='22_Site_Visit_Dispatch_Preflight.html',host='actual headless Chromium page.set_content(in-memory) only',passed=sum(x['passed'] for x in T),failed=sum(not x['passed'] for x in T),tests=T)
  OUT.write_text(json.dumps(result,indent=2)+'\n');print('TOTAL',result['passed'],result['failed'])
if __name__=='__main__':
 try:asyncio.run(run())
 except Exception:
  OUT.write_text(json.dumps(dict(tool='22_Site_Visit_Dispatch_Preflight.html',passed=sum(x['passed'] for x in T),failed=1,tests=T),indent=2)+'\n')
  print(traceback.format_exc());raise
