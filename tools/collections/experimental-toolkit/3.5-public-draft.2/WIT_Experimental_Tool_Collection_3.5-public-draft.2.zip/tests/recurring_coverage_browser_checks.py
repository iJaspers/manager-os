"""Private v2.4 bounded Chromium regression against extracted v2.3.1 source plus new fictional recurring coverage application; in-memory only."""
import asyncio, pathlib, json, csv, io, traceback, re
from playwright.async_api import async_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
CHECKS=[]

def check(label,ok,detail=''):
 ok=bool(ok)
 CHECKS.append({'name':label,'passed':ok,'detail':str(detail)[:350]})
 print(('PASS ' if ok else 'FAIL ')+label,flush=True)
 if not ok:raise AssertionError(f'{label} : {detail}')

def parse(txt):return list(csv.reader(io.StringIO(txt)))
def pack(rows):
 out=io.StringIO();csv.writer(out,lineterminator='\n').writerows(rows);return out.getvalue()

O=parse((ROOT/'examples/recurring_obligations_risk_fictional.csv').read_text())
V=parse((ROOT/'examples/recurring_visits_risk_fictional.csv').read_text())
CO=parse((ROOT/'examples/recurring_obligations_clean_fictional.csv').read_text())
CV=parse((ROOT/'examples/recurring_visits_clean_fictional.csv').read_text())

async def main():
 async with async_playwright() as pw:
  b=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
  p=await b.new_page(accept_downloads=True)
  errors=[];requests=[]
  p.on('pageerror',lambda e:errors.append(str(e)))
  p.on('request',lambda r:requests.append(r.url))
  html=(ROOT/'26_Recurring_Service_Coverage_Auditor.html').read_text().replace('<link rel="stylesheet" href="styles.css">','<style>'+(ROOT/'styles.css').read_text()+'</style>').replace('<script src="common.js"></script>','<script>'+(ROOT/'common.js').read_text()+'</script>')
  await p.set_content(html,wait_until='load')
  async def inside(id):return (await p.locator('#'+id).inner_text()).strip()
  async def apply(o=O,v=V,asof='2026-10-24'):
   await p.locator('#asOf').fill(asof)
   await p.locator('#obligations').fill(pack(o) if isinstance(o,list) else o)
   await p.locator('#visits').fill(pack(v) if isinstance(v,list) else v)
   await p.click('#review')
  async def blocked(code):
   msg=await inside('error')
   check('validation blocks '+code, 'INPUT BLOCKED' in await inside('status') and code.lower() in msg.lower() and await p.locator('#exportCSV').is_disabled(),msg)
  async def download(id):
   async with p.expect_download() as d:await p.click('#'+id)
   got=await d.value
   return got.suggested_filename, pathlib.Path(await got.path()).read_text()
  try:
   check('risk obligation fixture 4 entries and 10 fields',len(O)==5 and all(len(r)==10 for r in O))
   check('risk visit fixture 5 entries and 7 fields',len(V)==6 and all(len(r)==7 for r in V))
   check('new app initial auto-review in browser', 'HUMAN REVIEW REQUIRED' in await inside('status'))
   for id,n in [('mObligations','4'),('mDue','5'),('mCovered','1'),('mGaps','4')]:check('risk metric '+id,await inside(id)==n,await inside(id))
   findings=await inside('findings')
   for code in ['COVERAGE_WINDOW_PASSED','DUE_WINDOW_OPEN','DUE_WITHIN_14_DAYS','RIGHTS_UNCONFIRMED','RIGHTS_RESTRICTED','AGREEMENT_SOURCE_MISSING','VISIT_PROOF_INCOMPLETE','FUTURE_DATED_VISIT','VISIT_OUTSIDE_SCHEDULE_WINDOW','UNKNOWN_OBLIGATION']:
    check('risk detects '+code,code in findings)
   cycles=await inside('cycles')
   check('risk due table preserves uncovered September cycle','PM-A' in cycles and '2026-09-23' in cycles and 'MISSED_OR_UNVERIFIED' in cycles)
   check('risk retains reviewed evidence only for August','V-A1' in cycles and 'V-A2' not in cycles)
   check('future service is never counted as coverage',await inside('mCovered')=='1')
   check('no external request in in-memory synthetic test',not requests,requests)
   check('no app script errors',not errors,errors)
   name,out=await download('exportCSV')
   check('private exceptions CSV downloadable',name=='PRIVATE_recurring_service_exceptions.csv')
   pr=parse(out)
   check('CSV schema correct',pr[0]==['record','finding_code','human_next_check'])
   check('CSV has expected missing cycle',any('2026-09-23' in ' '.join(row) for row in pr))
   name,txt=await download('exportTXT')
   check('private TXT is labeled provisional',name.startswith('PRIVATE_') and 'not independently verified' in txt.lower())
   check('private TXT contains fictional cycle', 'PM-A' in txt and '2026-09-23' in txt)
   name,js=await download('exportJSON')
   payload=json.loads(js)
   check('counts-only export shape',payload['kind']=='private_counts_only_recurring_service_review')
   check('counts-only correct totals',payload['obligations']==4 and payload['due_cycles']==5 and payload['source_reported_covered_cycles']==1 and payload['open_or_past_gaps']==4)
   check('AI JSON no identifiers',all(x not in js for x in ['PM-A','AGR-A','WO-A1','V-C1','Motor check','2026-10-24']))
   check('AI JSON explicitly nonauthorizing',not any(payload[k] for k in ['verified_actual_service','verified_evidence_authenticity','rights_confirmed','action_authorized','published']))
   await p.click('#demoClean')
   check('clean sample has no findings', 'NO MODEL EXCEPTIONS' in await inside('status') and await inside('mIssues')=='0')
   check('clean sample one covered due cycle',await inside('mObligations')=='2' and await inside('mDue')=='1' and await inside('mCovered')=='1' and await inside('mGaps')=='0')
   await p.locator('#obligations').fill(pack(CO).replace('PM-X,Lamp check','PM-X,=HYPERLINK(hello)'))
   await p.click('#review')
   check('display never inserts attacker HTML',await p.locator('script[src],iframe,img').count()==0)
   await p.locator('#obligations').fill(pack(CO).replace('Lamp check','<img src=x onerror=alert(1)>'))
   await p.click('#review')
   await blocked('invalid label')
   await apply(CO,CV)
   check('input modification disables exports',not await p.locator('#exportCSV').is_disabled())
   await p.locator('#visits').fill(pack(CV)+'\n')
   check('input invalidates prior successful review',await p.locator('#exportCSV').is_disabled() and 'Input changed' in await inside('status'))
   await p.click('#review')
   check('re-audit restores exports',not await p.locator('#exportCSV').is_disabled())
   bad=[x.copy() for x in CO];bad.append(bad[1].copy());await apply(bad,CV);await blocked('repeated obligation_id')
   bad=[x.copy() for x in CV];bad.append(bad[1].copy());await apply(CO,bad);await blocked('repeated visit_id')
   bad=[x.copy() for x in CO];bad[1][2]='2026-02-29';await apply(bad,CV);await blocked('not a valid calendar date')
   bad=[x.copy() for x in CO];bad[1][2]='2026-10-22';bad[1][3]='2026-10-20';await apply(bad,CV);await blocked('end before first due')
   bad=[x.copy() for x in CO];bad[1][4]='6';await apply(bad,CV);await blocked('outside 7–366')
   bad=[x.copy() for x in CO];bad[1][4]='7';bad[1][5]='6';bad[1][6]='2';await apply(bad,CV);await blocked('overlapping visit windows')
   bad=[x.copy() for x in CO];bad[1][4]='14.5';await apply(bad,CV);await blocked('whole number')
   bad=[x.copy() for x in CO];bad[1][8]='granted';await apply(bad,CV);await blocked('invalid criticality or rights state')
   bad=[x.copy() for x in CO];bad[1][9]='https://bad.test';await apply(bad,CV);await blocked('invalid source ref')
   bad=[x.copy() for x in CV];bad[1][3]='happened';await apply(CO,bad);await blocked('invalid service/evidence state')
   bad=[x.copy() for x in CV];bad[1][5]='www.evil.test/go';await apply(CO,bad);await blocked('invalid evidence_ref')
   bad=[x.copy() for x in CO];bad[1][0]='=HYPERLINK';await apply(bad,CV);await blocked('invalid or repeated obligation_id')
   await apply('x,y,z\na,b,c',pack(CV));await blocked('exact header required')
   await apply('obligation_id,service_label,first_due_date\n"bad,abc',pack(CV));await blocked('Unclosed quoted field')
   await apply(pack(CO), 'visit_id,obligation_id\nA,B');await blocked('exact header required')
   await apply(CO,CV);await p.locator('#asOf').evaluate("el=>{el.value='2026-02-29';el.dispatchEvent(new Event('input',{bubbles:true}))}");await p.click('#review');await blocked('must be YYYY-MM-DD')
   await apply(pack(CO),pack(CV),'1999-12-31');await blocked('outside 2000–2100')
   await apply(CO,CV,'2026-10-19')
   check('future-dated visit cannot count as verified covered','FUTURE_DATED_VISIT' in await inside('findings') and await inside('mDue')=='0' and await inside('mCovered')=='0')
   await apply(CO,CV,'2026-10-20')
   check('exact due boundary credits valid evidence',await inside('mCovered')=='1')
   bad=[x.copy() for x in CV];bad[1][4]='reported';await apply(CO,bad,'2026-10-24')
   check('reported but unreviewed evidence cannot close elapsed cycle',await inside('mCovered')=='0' and 'COVERAGE_WINDOW_PASSED' in await inside('findings'))
   bad=[x.copy() for x in CV];bad[1][5]='UNKNOWN';await apply(CO,bad)
   check('missing evidence reference cannot close cycle',await inside('mCovered')=='0' and 'VISIT_PROOF_INCOMPLETE' in await inside('findings'))
   bad=[x.copy() for x in CV];bad[1][6]='UNKNOWN';await apply(CO,bad)
   check('missing work reference cannot close cycle',await inside('mCovered')=='0')
   bad=[x.copy() for x in CV];bad[1][3]='cancelled';await apply(CO,bad)
   check('cancelled visit cannot close cycle',await inside('mCovered')=='0')
   bad=[x.copy() for x in CV];bad[1][2]='2026-10-23';await apply(CO,bad,'2026-10-24')
   check('visit just outside grace is not credited',await inside('mCovered')=='0' and 'VISIT_OUTSIDE_SCHEDULE_WINDOW' in await inside('findings'))
   bad=[x.copy() for x in CV];bad[1][2]='2026-10-22';await apply(CO,bad,'2026-10-24')
   check('grace-day endpoint is inclusive',await inside('mCovered')=='1')
   bad=[x.copy() for x in CV];bad[1][2]='2026-10-19';await apply(CO,bad)
   check('early-day endpoint is inclusive',await inside('mCovered')=='1')
   bad=[x.copy() for x in CV];bad[1][2]='2026-10-18';await apply(CO,bad)
   check('visit before early window uncredited',await inside('mCovered')=='0' and 'VISIT_OUTSIDE_SCHEDULE_WINDOW' in await inside('findings'))
   bad=[x.copy() for x in CV];bad.append(['V-X-2','PM-X','2026-10-20','completed','reviewed','EV-X2','WO-X2']);await apply(CO,bad)
   check('duplicate visits same window flagged','MULTIPLE_VISITS_SAME_WINDOW' in await inside('findings'))
   check('duplicate visit cannot double-count coverage',await inside('mCovered')=='1')
   # Contractual anchor must not shift after a late but within-grace visit.
   o=parse(pack(CO));o[1][2]='2026-08-24';o[1][3]='2026-10-24';o[1][4]='30';o[1][5]='1';o[1][6]='3';
   v=parse(pack(CV));v[1][2]='2026-08-27';await apply(o,v)
   check('anchor schedule retains intervening missed due dates','2026-09-23' in await inside('cycles') and '2026-10-23' in await inside('cycles'))
   # Calendar leap boundary, no timezone drift: N day intervals cross leap Feb.
   o=parse(pack(CO));o[1][2]='2028-02-28';o[1][3]='2028-03-06';o[1][4]='7';o[1][5]='0';o[1][6]='0';v=parse(pack(CV));v[1][2]='2028-02-28';await apply(o,v,'2028-03-06')
   check('2028 leap date stepped by fixed day interval','2028-03-06' in await inside('cycles') and '2028-02-28' in await inside('cycles'))
   # Local file upload tests actually pass fixtures into input, not just synthetic textarea fills.
   await p.locator('#obligationFile').set_input_files(str(ROOT/'examples/recurring_obligations_risk_fictional.csv'))
   await p.locator('#visitFile').set_input_files(str(ROOT/'examples/recurring_visits_risk_fictional.csv'))
   await p.locator('#asOf').fill('2026-10-24')
   await p.click('#review')
   check('import local real fixture bytes in browser',await inside('mObligations')=='4' and await inside('mCovered')=='1')
   check('no navigation/requests generated by local CSV file upload',not requests,requests)
   check('CSP rejects all browser external network attempts',not errors,errors)
   # CSV injection from source identifiers is blocked, export formula escaping inherited from common.js.
   check('all case data remained local',all(x.startswith('data:') is False for x in requests) and not requests)
  except Exception:
   traceback.print_exc();raise
  finally:
   result={'suite':'recurring_coverage_browser_checks','version':'v2.4','test_mode':'actual headless Chromium in-memory HTML/CSS/JS synthetic only','passed':sum(x['passed'] for x in CHECKS),'failed':sum(not x['passed'] for x in CHECKS),'checks':CHECKS,'page_errors':errors,'network_requests':requests,'independent_desktop_file_host_tested':False,'customer_tested':False,'published':False}
   (ROOT/'tests/recurring_coverage_test_results.json').write_text(json.dumps(result,indent=2)+'\n')
   await b.close()

if __name__=='__main__':asyncio.run(main())
