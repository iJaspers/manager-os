> Public experimental source. PRIVATE in export names and schemas describes user-generated reports, not this source package. Use only invented examples; never infer permission to disclose reports or data. Browser/real-user acceptance is not established. See README_START_HERE.md.

# RECURRING SERVICE COVERAGE | PRIVATE AI CONTRACT v2.4

**Original, fictional-only, offline prototype.** Tool: `26_Recurring_Service_Coverage_Auditor.html`. This is a bounded review of declared recurring maintenance/inspection obligations versus reported service visits. Its purpose is to surface potential missed service windows and unverifiable work evidence for human checking. It is not a calendar, actual-compliance inspection, warranty determination or permission to enter a site. No customer, employer, security, financial, tax or MOS-private inputs.

## Source data

Use **invented** UTF-8 CSV. Obligations: `obligation_id,service_label,first_due_date,contract_end_date,interval_days,early_window_days,grace_days,criticality,rights_status,source_ref`; 1–80 rows. Visits: `visit_id,obligation_id,completed_date,service_status,evidence_status,evidence_ref,work_ref`; 1–350 rows. Both headers must match exactly. No external scripts or URLs. Dates must be valid `YYYY-MM-DD` between 2000-01-01 and 2100-12-31. Periodicity uses **fixed days**: it does not model calendar months, business-day clauses, holidays, termination/suspension amendments, renewal, travel or real contracts. Obligation horizon at most 10 years, period 7–366 days, early/grace 0–30 days and `early+grace<period` to prevent overlap; cycle count capped at 5,000.

The source-of-truth contract for a given cycle is **first_due_date + integer × interval_days**, through contract_end_date inclusive. Its recognized visit window is `[due - early, due + grace]` inclusive. A future-dated visit never qualifies. A past-or-present visit is marked `COVERED_REPORTED` only when service status is `completed`, evidence status `reviewed`, and two well-formed fictional evidence/work references are present. These fields are merely user-declared. They cannot authenticate the visit, evidence, rights or maintenance.

`MISSED_OR_UNVERIFIED` means no qualifying reported visit and review date past the declared window. `OPEN_OR_UNVERIFIED` means the review date lies in an open visit window without a qualifying reported visit. `UPCOMING_14_DAYS` marks an upcoming due date within 14 days; `NOT_YET_DUE` is farther away. It also surfaces missing original source references, rights holds, duplicate same-window visits, provisional evidence, visits outside windows, unknown obligation IDs and future-dated completion claims. These are **review flags**, not legal or operational conclusions.

## Safeguards and boundaries

- In-page display via `textContent`, escaped CSV download, no browser storage, network, backend, cookies, analytics or remote dependencies.
- User-selected local fictional CSV imports only; private exception CSV and detailed private TXT exports. Counts-only AI JSON excludes identifiers, amounts and per-record dates and explicitly reports all verification/authorization booleans as false.
- Inputs invalidate old review/export; oversized and malformed data fail closed. Original and inherited source code must stay byte-identical until explicitly tested changes are authorized.
- The human must independently inspect actual contract terms, authorizations, safety/regulatory requirements, amended due dates, site attendance and original evidence. `rights_status=cleared` and `evidence_status=reviewed` are user claims and not proof.
- Do not dispatch staff, contact customers/suppliers, change financial systems, make compliance claims or publish. No real proceeds have been confirmed.

## Validation scope

## Current collection evidence
Read VALIDATION.md for performed checks and unverified gates on this exact collection. Historical upstream in-memory browser results are not a rerun or acceptance of this candidate. Public source availability does not grant permission to disclose user-generated outputs or to act on their contents.
