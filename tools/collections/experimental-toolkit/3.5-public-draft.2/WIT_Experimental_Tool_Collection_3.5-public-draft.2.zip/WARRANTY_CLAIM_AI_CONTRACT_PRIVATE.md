> Public experimental source. PRIVATE in export names and schemas describes user-generated reports, not this source package. Use only invented examples; never infer permission to disclose reports or data. Browser/real-user acceptance is not established. See README_START_HERE.md.

# PRIVATE AI Contract | Warranty Claim Readiness Preflight v1


## Bounded business problem

A field-service team preparing paperwork for a damaged asset can waste time on missing purchase/coverage evidence, duplicate incident reports, uncertain rights, and conflicting dates. The tool runs entirely in the local browser on invented `FAKE_` aliases and produces a **triage list**, never a warranty determination or claim submission. It is distinct from PO/receipt/invoice three-way reconciliation (procurement), supplier credit/return recovery (supplier relationship), and service time evidence (time claims).

## Human-readable input contract

`assets` exact columns: `asset_tag,coverage_start_date,coverage_months,coverage_basis,asset_proof_ref,rights_status`

`incidents` exact columns: `incident_tag,asset_tag,incident_date,issue_tag,incident_proof_ref,claim_state,source_ref`

Identifiers and issue types must be invented `FAKE_[A-Z0-9_]{1,32}` aliases; references are `FAKE`-prefixed or `NONE`. Dates must be actual Gregorian `YYYY-MM-DD` in years 2000–2099. `coverage_months` is an integer 1–120. `coverage_basis` is `supplier_declared`, `client_assumed` or `unknown`. `rights_status` is `owned`, `unknown` or `restricted`. `claim_state` is `draft`, `submitted`, `closed` or `unknown`. Imported/local CSV is capped at 128 KiB per table, 200 asset rows, 400 incident rows.

An explicit review date is required; default fictional date is `2026-10-25`. The *declared nominal anniversary* is calculated by adding calendar months and clamping the original day to the last day of the destination month (e.g. January 31 + one month = February 28 or 29). The incident date is compared **inclusively** against that nominal anniversary. This convention is a screening assumption, NOT a manufacturer warranty-period rule. Terms, exceptions, claim deadlines, proof requirements, eligibility, exclusions, transferability, jurisdiction and approvals vary. Never label an asset eligible, ineligible, accepted or covered on this basis alone.

## Output contract

- Findings CSV: fictional record tag, stable finding code, human follow-up; spreadsheet-formula-safe quoting via shared `csvSerialize`. `NONE` proof creates a flag, not a fabricated receipt.
- Review TXT: fictional counts, findings and assumptions, with human verification disclaimer.
- AI JSON: **aggregate counts only** (`kind`, `asset_count`, `incident_count`, `finding_count`, `finding_code_counts` and boolean false verification state). No fictional tags or source identifiers exported into JSON, no raw source rows.
- No external network calls, persistence, authentication, receipt validation, warranty API, submission, claim status lookup, payment processing or customer outreach. Results live only in the current tab until explicitly exported. Edits invalidate prior exports.

## Prompt for an authorized human reviewer

> Given only the aggregate `private_warranty_claim_counts_only_v1` JSON and non-sensitive generic descriptions, propose a document-request checklist sorted by missing proof and chronology issues. Do not assert coverage, vendor rights, claim validity, payment entitlement or authorization. If any real source documents, employer information, confidential data or rights questions arise, stop and ask an authorized reviewer to handle them outside this pilot. Never infer proof from status flags.

## Current collection evidence
Read VALIDATION.md for performed checks and unverified gates on this exact collection. Historical upstream in-memory browser results are not a rerun or acceptance of this candidate. Public source availability does not grant permission to disclose user-generated outputs or to act on their contents.
