> Public experimental source. PRIVATE in export names and schemas describes user-generated reports, not this source package. Use only invented examples; never infer permission to disclose reports or data. Browser/real-user acceptance is not established. See README_START_HERE.md.

# Stockout & Replenishment Window | PRIVATE data/AI contract v1

**Scope:** Twenty-fourth offline tool; invented stock items only, separate from site dispatch readiness, cost variance and cash exposure. It models a *possible stockout horizon* based on user-declared quantities and a constant recent-30-day consumption assumption. No vendor connection, real inventory, ownership right, client approval, supplier verification, purchases, tax/QBO/bank or site access.

## Exact input columns

`sku_id,item_label,on_hand_qty,reserved_qty,used_last_30d,lead_days,safety_qty,incoming_qty,incoming_eta,incoming_state,unit_cost_cad,supplier_state,last_count_date,demand_source_ref,order_multiple_qty`

- 1–80 fictional rows / ≤95,000 UTF-8 bytes. Invented uppercase IDs `A-Z` plus `A-Z0-9_-`, 2–28 characters. Short innocent item labels. No real names, emails, URLs, site addresses, vendor IDs or credentials.
- Nonnegative whole `on_hand_qty`, `reserved_qty`, `used_last_30d`, `safety_qty`, `incoming_qty` ≤100,000. `lead_days` 1–180, `order_multiple_qty` 1–10,000. Cost decimal CAD with ≤2 digits and ≤100000.00. All amounts invented.
- Inbound state: `none` requires qty=0 and no ETA. `confirmed` requires qty>0 and valid ETA. `unconfirmed` requires qty>0 and ETA can be omitted. Calendar dates ISO YYYY-MM-DD 2000–2100; count date must not postdate selected model date. Supplier state `available`, `uncertain`, `discontinued`; demand source fictional ID or `UNKNOWN`.
- The model date is explicitly user-selected. Missing, impossible, oversized, duplicate and malformed CSV blocks all outputs, and changing inputs disables stale outputs.

## Deterministic planning assumptions

`free = on_hand - reserved` (negative values are reported); demand through `d` days = ceil(used_last_30d × d / 30). Reported confirmed inbound from a claimed available supplier with a non-past ETA is credited **only on the day after ETA**; unconfirmed, past-due or supplier-held inbound is not credited. Compute day-by-day modelled free stock across 0..lead_days, explicitly flag projected negative stock and safety-stock breaches. For a notional planning gap, take ceil[(horizon demand + safety − free − usable inbound)/declared order multiple] × order multiple, bounded below by zero. This is a stockout scenario, **not** a quantity to order.

## Human review holds

Reports reservation deficits, projected shortages, buffer breaches, no claimed supplier, stale last count >14 days, unknown demand source, zero 30-day usage (review only, not definitive dead-stock), missing cost basis, unconfirmed/past-due or late supplier arrivals. Even zero registered exceptions do not authenticate inventory, consumption rate, rights to buy, supplier ETA, lead time, current price or safety.

## Outputs

Private details: exception CSV and review TXT. CSV is spreadsheet-formula hardened. AI JSON: counts and finding-code counts **only**; no item ID, cost, supplier, dates, paths or descriptions. Output asserts `inventoryVerified`, `supplierVerified`, `demandVerified`, `etaVerified`, `costsVerified`, `procurementAuthorized`, `customerApprovalVerified`, `permissionToPublish`, `revenueReceivedVerified` are always **false**. This prototype deliberately does not make orders, select suppliers, change stock, send messages, or make customer contact.

## Current collection evidence
Read VALIDATION.md for performed checks and unverified gates on this exact collection. Historical upstream in-memory browser results are not a rerun or acceptance of this candidate. Public source availability does not grant permission to disclose user-generated outputs or to act on their contents.
