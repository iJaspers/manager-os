> Public experimental source. PRIVATE in export names and schemas describes user-generated reports, not this source package. Use only invented examples; never infer permission to disclose reports or data. Browser/real-user acceptance is not established. See README_START_HERE.md.

# Three-Way Match Gate: private AI handoff contract

Scope: exclusively invented purchase-order, receipt, and supplier-invoice CSV records.

The file `29_PO_Receipt_Invoice_Three_Way_Gate.html` is a fully local first-party browser comparison tool with no external runtime dependencies except `common.js` and `styles.css` inside the same extracted folder. It never submits, approves, authorizes, records a payment or stores client data. It is not a ledger, tax computation, proof of work, fraud detection, actual delivery certification or accounts payable system.

Three exact register schemas are displayed in the browser. Only positive whole-unit quantities and CAD amounts with at most 2 decimal places are supported. Invoice face totals are provisional, exclude taxes, discounts, credits and freight, and should never be represented as verified payable balances. A fictional future review-as-of date is required. Repeated invoice ID per PO-line is a review flag, not proof of a duplicate charge.

For an AI handoff, share only `PRIVATE_three_way_counts_only_AI.json`, with original invented records stripped. It includes issue-code counts but no identifiers, prices, dates, invoice details or descriptions. The booleans `source_verified`, `rights_verified`, `goods_verified`, `invoice_verified`, `payment_authorized`, and `published` must remain false until independently reviewed by an authorized human in a different controlled process.

Testing: supply original fictional positive and adversarial CSV inputs; inspect local application scripts and exports. Browser-in-memory checks are not independent desktop/mobile, customer, site-host, accounting-platform or actual-payment acceptance.

Do not import real employer/customer/supplier records. No publication of user data, sale, purchase, payment, client solicitation, bank/QBO/tax edit, or other-loop modification is authorized. Separate human permission and actual rights checks are mandatory before any later rollout.

## Current collection evidence
Read VALIDATION.md for performed checks and unverified gates on this exact collection. Historical upstream in-memory browser results are not a rerun or acceptance of this candidate. Public source availability does not grant permission to disclose user-generated outputs or to act on their contents.
