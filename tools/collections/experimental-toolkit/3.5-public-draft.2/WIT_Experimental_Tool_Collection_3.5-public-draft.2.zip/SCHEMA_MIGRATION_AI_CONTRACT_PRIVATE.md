> Public experimental source. PRIVATE in export names and schemas describes user-generated reports, not this source package. Use only invented examples; never infer permission to disclose reports or data. Browser/real-user acceptance is not established. See README_START_HERE.md.

# Private AI data contract: Schema Migration Preflight v1

**Purpose:** Review a hypothetical migration mapping **schema only**, before transferring any real data. All names, source references, classification declarations, approvals and permissions are *typed assertions* with no source authentication. No transformations are executed. Nothing is imported from a source system or exported to a destination. This is different from Tool 09, which reconciles values already represented in two CSVs.

Three local UTF-8 CSV declarations use the following exact headers:

1. Source fields: `field_id,data_type,classification,rights_status,source_ref`.
2. Target fields: `field_id,data_type,required,classification,source_ref`.
3. Proposed mappings: `source_field,target_field,transform,review_status,rights_status,source_ref`.

Identifiers must start with an ASCII letter and contain 1–50 ASCII letters/digits/underscores. Types: `text`, `integer`, `decimal`, `date`, `boolean`. Classification: `public`, `internal`, `personal`, `restricted` in that modeled order. Rights: `owned`, `unknown`, `restricted`. Target `required`: `yes` or `no`. Mapping review: `approved`, `pending`, `rejected`. Supported declared transform names (not executable operations): `copy`, `normalize_text`, `parse_integer`, `parse_decimal`, `parse_date`.

Modeled type pairs: `copy` requires identical declared types; `normalize_text` text→text; `parse_integer` text→integer; `parse_decimal` text/integer→decimal; `parse_date` text→date. No other type mappings are accepted as compatible. Even modeled conversions require human data-level validation (invalid numbers, blanks, locales, precision, date ambiguity, Unicode, truncation, deduplication). A source classification above its proposed target protection classification triggers a privacy downgrade finding, not a legal/compliance determination. Unmapped required target fields, duplicate target mapping, unmapped sensitive source, unsupported pairs, unclear rights, review holds and evidence gaps also generate findings.

Limits: 120,000 characters per pasted CSV, 500 data rows per CSV, max 120 source-ref characters. No network, backend, browser storage, third-party JavaScript or external code. Input is **fictional metadata only**, never actual personal/client/employer/financial/tax/security information. Avoid all real record values. Exports: full findings private CSV, full review private TXT, and **aggregate counts-only AI JSON**. Only the counts-only JSON can be used for a generic AI interpretation without bespoke rights and privacy review; do not paste private TXT or CSV into public systems. No result, including zero modeled issues, proves real schema correctness, data quality, permissions, destination security, privacy compliance or go-live readiness.

## AI response constraint

Explain exception codes and suggest human checks, without claiming or inferring that a migration, export, client instruction, access, publication or paid work has been authorized. Cite the metadata evidence limitation. Never generate executable migration scripts from invented metadata as if verified. Never alter tax, QuickBooks, employer, bank or client data. Manual rights, employment/IP, source/destination security and privacy review are prerequisites to any commercial real-data use.

## Current collection evidence
Read VALIDATION.md for performed checks and unverified gates on this exact collection. Historical upstream in-memory browser results are not a rerun or acceptance of this candidate. Public source availability does not grant permission to disclose user-generated outputs or to act on their contents.
