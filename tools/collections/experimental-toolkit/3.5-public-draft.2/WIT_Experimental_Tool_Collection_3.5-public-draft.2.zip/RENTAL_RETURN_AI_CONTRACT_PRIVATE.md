> Public experimental source. PRIVATE in export names and schemas describes user-generated reports, not this source package. Use only invented examples; never infer permission to disclose reports or data. Browser/real-user acceptance is not established. See README_START_HERE.md.

# RENTAL RETURN EXPOSURE AI CONTRACT, PRIVATE v3.5

**Scope:** Original, offline rental-documentation completeness and exception screen for service businesses. All sample records are invented. The only accepted identifiers begin `FAKE_`; provenance must be `FAKE...` or `NONE`. No actual client, employer, supplier, equipment serial, rate, purchase/return evidence, dates from real work, money or confidential security information is suitable for the prototype.

## Buyer-facing problem

Equipment rented for temporary jobs can accumulate possible late-fee exposure, especially when a return is declared without documented vendor acknowledgment or a due-date extension is *requested*, but not evidenced as approved. This experimental tool compares a rental register with self-declared events and highlights holes for an authorized human to investigate. It is **not** a delivery, return, billing, proof-of-contract, insurance, or ownership authority. It does **not** replace the Supplier Credit Return Recovery tool, which addresses purchased goods and vendor credits.

## CSV contracts

- Rentals: `rental_tag,equipment_tag,start_date,due_date,grace_days,daily_fee_cad,agreement_ref,rights_status`
- Events: `event_tag,rental_tag,event_type,event_date,approved_due_date,evidence_ref,source_ref`
- Type values: `checkout`, `return`, `extension_requested`, `extension_approved`, `damage_reported`.
- `approved_due_date` is a valid ISO date only for `extension_approved`. Otherwise, `NONE`.
- Rights: `authorized`, `unknown`, `restricted`. Rights are *declared*; even `authorized` is not independently validated.
- `FAKE_` identifiers, capped rows/bytes, fixed headers, date validation, integer grace 0–30 days, and claimed daily fee 0–5000 CAD with 0–2 decimal places. No real names, account references, serials, web addresses or freeform personally identifying notes.

## Conservative evaluation rules

1. An extension *request* never extends the deadline. An approval changes the modeled due date only if dated on/before the prevailing declared due date, within declared rental chronology and review date, gives a later approved date, and has *both* fake evidence and source references. Missing documentation, retroactive or non-later approval is flagged rather than applied. Multiple approved extensions may chain in date order.
2. A return is treated as *documentarily declared* only when dated within the declared rental period (not before a later checkout and not after review date) with both evidence and source references. This does not validate actual vendor receipt. Missing paperwork remains open for human review and may create a false positive.
3. Duplicate checkouts/returns, orphan events, missing agreement reference, unclear rights, event evidence/source gaps, future events and contradictory chronology generate findings.
4. `illustrative potential fee exposure` = sum over rentals of `max(0, [calendar days between evidenced return or review date and declared due date + grace]) × declared daily fee`. Date arithmetic uses UTC calendar days and **does not represent actual billed late fees, legal debt, recovery, savings or a payment decision**. The review date is supplied, not fetched from the system. Partial-day billing, country tax, rental-hour thresholds, discounts, maximums, weekends, disputes, and contract-specific billing rules are intentionally excluded.
5. If zero findings, the tool still says human verification is required. Outputs contain only invented tags or aggregate counts. Aggregate-only AI JSON excludes the invented event and rental identifiers.

## Outputs / interfaces

- Downloaded CSV of fictional finding tag, code, human follow-up and illustrative fee associated with that flag.
- TXT with scenario summary and explicit limitations.
- Aggregate-only AI JSON with flags `vendor_terms_verified=false`, `return_receipts_authenticated=false`, `real_permission_verified=false`, `actual_fees_confirmed=false`, `extensions_authorized_by_tool=false`, `independent_host_tested=false`, `published=false`, `revenue_verified=false`.
- No network requests, storage, payments, email, client communications, checkout, contractor dispatch or mutation of other services. All code written locally; no third-party libraries except the existing original toolkit common.js/styles.css.

## Current collection evidence
Read VALIDATION.md for performed checks and unverified gates on this exact collection. Historical upstream in-memory browser results are not a rerun or acceptance of this candidate. Public source availability does not grant permission to disclose user-generated outputs or to act on their contents.
