> Public experimental source. PRIVATE in export names and schemas describes user-generated reports, not this source package. Use only invented examples; never infer permission to disclose reports or data. Browser/real-user acceptance is not established. See README_START_HERE.md.

# PD-COST-VARIANCE-1 | PRIVATE AI handoff contract

Tool: `15_Estimate_Actual_Cost_Variance.html`. Original local HTML/JS, invented sample data only. Inputs are self-reported, not verified accounting records. No customer, employer, tax, QBO, MOS-private, security, or real financial data permitted in prototypes.

## CSV schema
`work_id,scope_state,approval_ref,work_state,quoted_fee_cad,planned_hours,actual_hours,remaining_hours,loaded_rate_cad,planned_external_cad,actual_external_cad,remaining_external_cad,cost_proof` (exact order; 1-60 rows; 128 KiB limit).

Approved `BASELINE` / `APPROVED_CHANGE`: include fee and EAC based on actual + remaining hours multiplied by loaded rate, plus actual + remaining external expense. Proposed `PENDING_CHANGE` or `REJECTED_CHANGE`: exclude all quoted fee and remaining forecast from agreed totals, but include incurred costs as an exposure. This is a _conservative model_, not accounting recognition, rights, scope or verified liability. Signed credits, retained deposits, tax, overhead, and cost accrual reconciliation are deliberately **not modeled**. No fee is treated as collected money, no change treated as really authorized. Nonapproved planned work should not proceed.

`PD-COST-VARIANCE-1` restricted JSON exports only aggregate counts and boolean QA states. Never export IDs, project descriptions, costs, prices, rates, receipts or references to an AI provider without verified rights and separate human approval. PRIVATE CSV/TXT exports are local and may contain untrusted details. They MUST NOT be forwarded or published automatically. Spreadsheet formula mitigation is applied by the shared CSV serializer. Use textContent for all untrusted UI cells. Every edit invalidates exports.

## Gate
The existence of a reference string is **not** proof of signed scope, financial truth or document rights. True buyer acceptance requires separate signed original documents, source validation, accountant/legal review where relevant, and human clearance. Run-only in a client-authorized environment after approvals, with separate independent acceptance of `file://`, downloads and mobile behavior. No contact, payments, invoicing, public release, tax, bank or QBO writes are authorized by this tool.

## Current collection evidence
Read VALIDATION.md for performed checks and unverified gates on this exact collection. Historical upstream in-memory browser results are not a rerun or acceptance of this candidate. Public source availability does not grant permission to disclose user-generated outputs or to act on their contents.
