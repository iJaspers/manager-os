# Asynchronous CSV import correction

Candidate 3.5-public-draft.2 derives from immutable 3.5-public-draft.1. It contains the same 37 application identities; no applications were added. Parser-family apps 9–11 are now 0.1.2-draft.1 derivatives, not byte-identical 0.1.1 files.

A controlled promise-ordering check demonstrated that delayed local file reads could overwrite a newer manual edit in 25 apps. This candidate replaces those import handlers with a per-editable-field generation coordinator. A newer selection, cancellation, oversized selection or manual edit supersedes older work. Errors from stale reads cannot replace current state. Independent input fields can finish in either order. Configuration edits and example loads cancel outstanding imports. Analysis and downloads are held while a current import is pending. Current import failure clears the obsolete target input. Imports now require an explicit analysis/review action afterward, including Door Register Auditor.

Changed apps: 2, 5–16 and 26–37. Existing source of apps 1, 3, 4 and 17–25 remains unchanged; their async behavior was not comprehensively certified by this correction. The shared CSV parser remains byte-identical to the prior corrected parser.

This is still experimental source for fictional data only. Synthetic tests do not establish rendered browser, actual file-picker, mobile, customer, commercial, security or legal acceptance. Published earlier versions remain historical artifacts and are not silently overwritten.
