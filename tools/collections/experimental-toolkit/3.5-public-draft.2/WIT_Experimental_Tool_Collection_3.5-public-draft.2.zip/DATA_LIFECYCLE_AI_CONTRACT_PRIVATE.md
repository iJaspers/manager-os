> Public experimental source. PRIVATE in export names and schemas describes user-generated reports, not this source package. Use only invented examples; never infer permission to disclose reports or data. Browser/real-user acceptance is not established. See README_START_HERE.md.

# PD-DATA-LIFECYCLE-1 | PRIVATE AI handoff contract

**Purpose:** A human-reviewed data-minimization, access, retention and disposition planning aid for a bounded problem-solving engagement. This is distinct from checking proposed public-release files. All examples are invented; do not input real client, employer, financial, tax, security or personally identifiable data without a separate lawful process and explicit authorization.

## Exact input data contract

`data_id,label,data_class,necessity,rights,storage,access,retention_until,action,evidence_ref`

- 1–150 rows and at most 128 KiB; strict CSV column order and count. Every data ID is unique uppercase code and every label is short, invented, non-contact metadata.
- `data_class`: `SYNTHETIC_PUBLIC`, `CLIENT_PRIVATE`, `PERSONAL`, `SECURITY_SENSITIVE`, `UNKNOWN`.
- `necessity`: `YES`, `NO`, `UNKNOWN`.
- `rights`: `ORIGINAL`, `CLIENT_PERMISSION_REPORTED`, `THIRD_PARTY_REPORTED`, `DENIED`, `UNKNOWN`. A *reported* permission must never be treated as actual consent, lawful processing ground, ownership or sublicensing.
- `storage`: `LOCAL_ENCRYPTED`, `CLIENT_CONTROLLED`, `THIRD_PARTY`, `NONE`, `UNKNOWN`. These values are **self-reported plans**, not verified platform security settings.
- `access`: `OWNER_ONLY`, `AUTHORIZED_TEAM`, `PUBLIC`, `UNKNOWN`.
- `retention_until`: YYYY-MM-DD (inclusive proposed planning deadline) or blank. Dates are evaluated in UTC **calendar days only** relative to an explicit as-of day; no assumed timezone, time-of-day, event trigger, statutory retention schedule or grace period.
- `action`: `DELETE`, `RETURN`, `ANONYMIZE`, `KEEP`, `UNKNOWN`. Every action is a **proposal, not an action executed**. No destruction certificate, privacy notice, legal opinion or evidence review is produced.
- `evidence_ref`: optional, invented uppercase code. This field is a pointer **only**, not verified evidence of return, erasure, consent or any other event.

## Output policy

- `PRIVATE_data_lifecycle_exceptions.csv`: `data_id,severity,issue_code,human_action`; must remain private.
- `PRIVATE_data_lifecycle_plan.txt`: includes the invented project code, all entered inventory metadata and findings; **private**, never send to public AI models or publish.
- `PRIVATE_data_lifecycle_AI_counts.json`: fixed schema `PD-DATA-LIFECYCLE-1`; includes aggregate counts and static issue category totals only, never raw identifiers, labels, dates, rights sources, evidence references or narrative. Fields that could imply approval, actual disposition or outreach are fixed `false`; human review is always required.
- A zero-exception plan only means **no automated planning rule fired**. It never establishes actual deletion, lawful processing, approval, suitability to work, safe public sharing or commercial acceptance.
- Edits and imports invalidate prior exports; no server, network access, browser storage or automatic action is implemented.

## Human next steps

Verify collection necessity, legal basis and ownership, actual encryption and data access, storage vendors and copies/backups, statutory/document retention, client instructions, data-subject rights, incident handling and *independent evidence* for any claimed disposal. Qualified privacy/security/legal specialists should review nontrivial regulated or security-sensitive handling. Client outreach, use of real data, publication, any purchase and payment processing all require distinct explicit authorization.

## Source rights

Original HTML and tests authored for this private build, using the package's original `common.js`, `styles.css` and local examples. No third-party packages, runtime dependencies or proprietary external code were incorporated into the new tool. The public collection reuses reviewed shared assets and identifies its actual changes and tests in VALIDATION.md.

## Current collection evidence
Read VALIDATION.md for performed checks and unverified gates on this exact collection. Historical upstream in-memory browser results are not a rerun or acceptance of this candidate. Public source availability does not grant permission to disclose user-generated outputs or to act on their contents.
