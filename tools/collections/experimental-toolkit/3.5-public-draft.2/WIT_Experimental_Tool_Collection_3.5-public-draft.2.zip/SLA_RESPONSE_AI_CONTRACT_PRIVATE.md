> Public experimental source. PRIVATE in export names and schemas describes user-generated reports, not this source package. Use only invented examples; never infer permission to disclose reports or data. Browser/real-user acceptance is not established. See README_START_HERE.md.

# PRIVATE AI HANDOFF | SLA Response Evidence Auditor v1

This is a **strictly fictional**, offline response-timing declaration screen. It does not interpret a real contract, validate response delivery, determine breach or entitlement, authenticate evidence, provide legal advice, contact anyone, or authorize any action.

## CSV inputs

1. Tickets CSV exact header `ticket_tag,received_utc,response_target_minutes,rights_status,review_state,source_ref`; 1–120 rows. `ticket_tag` must be a visibly synthetic uppercase `FAKE_` ID. Times must be strict real UTC `YYYY-MM-DDTHH:MMZ`; `response_target_minutes` integer 1–10080, **continuous elapsed calendar minutes**. `rights_status` = owned/unknown/restricted; `review_state` = reviewed/pending/rejected. `source_ref` a `FAKE` prefixed tag or `NONE`.
2. Responses CSV exact header `ticket_tag,response_utc,channel,proof_state,source_ref`; 0–120 rows. `channel` = email/phone/portal/other; `proof_state` = confirmed/claimed/pending/rejected. `confirmed` is **self-declared and never independently verified**.
3. Fictional as-of timestamp in the same UTC minute precision. Inputs live in browser memory only; no server, storage or network.

## Screening semantics

- Compare each ticket's declared receipt + target minutes against declared responses.
- Model-timely count requires a recorded `confirmed` response with a source tag, chronological consistency and response timestamp no later than target or as-of. It is not an authenticated service metric.
- Report source/rights/review holds, non-confirmed claims, missing evidence, future or pre-receipt responses, duplicates, orphan replies and modeled missed/near deadlines.
- All comparisons are continuous elapsed UTC minutes. **No business calendar, public holidays, timezone conversions, service-level exceptions, actual response content or reliability assessment** is applied.
- Duplicate ticket IDs and bad headers, timestamps, enums or oversized files must block processing. Data edit invalidates prior exports.

## Exports

- PRIVATE findings CSV: `fictional_ticket_tag,finding_code,human_follow_up`.
- PRIVATE human-readable TXT: includes invented identifiers and explicit non-clearance caveats.
- PRIVATE AI aggregate JSON: counts and finding-code totals only, **no ticket references or raw timestamps**, with `source_evidence_authenticated`, `sla_terms_interpreted`, `rights_verified`, `compliance_certified`, `actions_authorized`, `independent_host_tested` all `false`.

## Mandatory handoff boundaries

## Current collection evidence
Read VALIDATION.md for performed checks and unverified gates on this exact collection. Historical upstream in-memory browser results are not a rerun or acceptance of this candidate. Public source availability does not grant permission to disclose user-generated outputs or to act on their contents.
