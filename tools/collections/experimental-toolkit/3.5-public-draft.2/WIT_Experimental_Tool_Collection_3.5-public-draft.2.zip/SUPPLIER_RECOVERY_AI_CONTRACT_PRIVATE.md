> Public experimental source. PRIVATE in export names and schemas describes user-generated reports, not this source package. Use only invented examples; never infer permission to disclose reports or data. Browser/real-user acceptance is not established. See README_START_HERE.md.

# Supplier Credit & Return Recovery | PRIVATE AI/Data Contract v1

**File:** `25_Supplier_Credit_Return_Recovery.html`. **Status:** Original source with historical in-memory Chromium evidence, not rerun on this collection; VALIDATION.md controls current checks. No actual supplier/customer validation, rights/legal opinion, operational deployment or automated communication. No network, packages, database or account connection.

## Problem solved and buyer distinction

For a fixed-scope project/service business, returned or defective purchased components can sit uncredited after the job is over. This register surfaces unsupported returns, reported return-window deadlines, claims that are open/denied, and partially or falsely recorded credits. It is distinct from forward stock replenishment (tool 24), customer billing (tool 08), project variance (tool 15), and customer decision approval (tool 17).

## Input schema

Use one UTF-8 CSV up to 90KB, exact 16-column header, 1–70 rows, and invented values only:

`case_id,item_label,quantity,unit_cost_cad,purchase_date,return_window_days,reason,invoice_ref,problem_evidence_ref,rights_state,claim_state,claim_date,claim_ref,credit_state,reported_credit_cad,credit_evidence_ref`

- `case_id`: unique uppercase invented code 2–30 chars; `item_label`: safe fictional label 2–61 chars.
- `quantity`: integer 1–10,000; `unit_cost_cad`: exact CAD decimal with at most two cents, $0–$100,000; total row cost limited to $10,000,000; credit cannot exceed row's recorded cost.
- `purchase_date`, optional `claim_date`: valid YYYY-MM-DD calendar dates, never future relative to selected review date; claimed date cannot precede purchase.
- `return_window_days`: declared supplier policy 0–730; 0 = unknown. **Not** a legal warranty or statutory eligibility cutoff.
- `reason`: defective / wrong_item / overage / other. `rights_state`: unknown / cleared / restricted. **Even cleared is user-reported, not permission.**
- `claim_state`: not_started / submitted / approved / denied / closed. `credit_state`: none / pending / reported_received. Nonzero reported credits require `reported_received`, which in turn needs positive claimed amount.
- Reference fields are absent, `UNKNOWN`, or invented uppercase IDs, not paths, URLs, email addresses or secrets.

## Calculations and outputs

`gross_notional_cents = quantity × unit_cost_cents`. Credit is deducted in the planning display **only if** `credit_state=reported_received` and a plausible non-UNKNOWN credit reference code is present. This does not independently verify money or memo authenticity. The remainder is **nominal unreconciled cost**, not collectible revenue, cash, recognized income, or accounting truth. Claim date after a typed-in window, reported policy expiry, missing source, inconsistent closed/pending state, and duplicate invoice+item combinations create issues, not automatic legal judgments.

- Display: human-only exception table with invented identifiers and amounts.
- Private CSV: `case_id,priority,exception_code,human_next_check`.
- Private TXT: bounded reported case facts and verification cautions.
- Counts-only AI JSON: cases, issue counts, and strict `false` verification/authorization flags, no row identifiers, amounts, or individual dates.
- Any input edit disables stale export buttons. All rendering is `textContent`, not HTML injection. No data is sent, persisted, transmitted, uploaded or stored on servers by this tool.

## Human controls

## Current collection evidence
Read VALIDATION.md for performed checks and unverified gates on this exact collection. Historical upstream in-memory browser results are not a rerun or acceptance of this candidate. Public source availability does not grant permission to disclose user-generated outputs or to act on their contents.
