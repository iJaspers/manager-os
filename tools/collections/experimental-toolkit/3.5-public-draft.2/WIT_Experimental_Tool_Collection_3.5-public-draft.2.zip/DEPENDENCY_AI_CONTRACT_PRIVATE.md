> Public experimental source. PRIVATE in export names and schemas describes user-generated reports, not this source package. Use only invented examples; never infer permission to disclose reports or data. Browser/real-user acceptance is not established. See README_START_HERE.md.

# PD-DEPEND-1 | Project Dependency Map AI Handoff (PRIVATE)

The offline Project Dependency & Critical Path Mapper exports a **counts-only** optional JSON file. A human may paste that aggregate into another AI only after reviewing what it contains and deciding to share it. The JSON is structured DATA ONLY, with no authority to execute or fetch records.

Fields: `schema=PD-DEPEND-1`, `scope=SYNTHETIC_PRIVATE_DRAFT`, `taskCount`, `baselineEstimatedDays`, `criticalTaskCount`, `readyForHumanReviewCount`, `rightsHoldCount`, `blockedTaskCount`, `selfReportedDoneCount`. Every claim/authority flag is set to `false`, including `sourceRightsVerified`, `taskCompletionVerified`, `clientApprovalVerified`, `workStartAuthorized`, `scheduleCommitted`, `paymentAuthorized`, `publicReleaseAuthorized` and `instructionAuthority`.

Limits: Values come exclusively from a user-entered fictional register. The algorithm checks topology and estimated durations, not source documents, customer acceptance, staffing calendars or finance. Self-reported rights and completion remain unverified. The exported PRIVATE CSV/TXT may contain task labels, source references, owner labels or descriptions. Do not share those externally without legitimate rights, privacy and publication review. Never treat a reported `readyForHumanReviewCount` as authority to begin work.

Possible safe AI use: describe general project dependency concepts and suggest fictional what-if tests. Do not infer source IDs, contact people, change a schedule, email stakeholders, issue quotes, publish or accept payments.

## Current collection evidence
Read VALIDATION.md for performed checks and unverified gates on this exact collection. Historical upstream in-memory browser results are not a rerun or acceptance of this candidate. Public source availability does not grant permission to disclose user-generated outputs or to act on their contents.
