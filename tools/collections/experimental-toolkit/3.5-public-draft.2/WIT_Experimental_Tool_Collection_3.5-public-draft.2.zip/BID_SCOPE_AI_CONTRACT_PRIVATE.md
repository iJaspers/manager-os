> Public experimental source. PRIVATE in export names and schemas describes user-generated reports, not this source package. Use only invented examples; never infer permission to disclose reports or data. Browser/real-user acceptance is not established. See README_START_HERE.md.

# Bid Scope Comparison | PD-BID-SCOPE-1 | PRIVATE

**Purpose:** Human-review aid for comparing *invented* subcontractor bid coverage against an invented requirement register, without ranking or selecting vendors. It is a distinct procurement scope analysis, not a project quote, change-order, or cost variance tool.

**Requirement rows:** CSV exact headers `item_id,description,quantity,unit,critical`. Unique uppercase item identifiers `[A-Z][A-Z0-9_-]{1,19}`. 1–180 items, positive integer quantity up to 999999. Units are `each`, `m`, `hour`, `day`, `lot`. `critical` is `yes` or `no`.

**Offer rows:** CSV exact headers `bidder_id,item_id,coverage,quantity,unit,unit_price_cad,exclusion,valid_through,source_ref`. Up to 1100 rows and 18 fictional bidder IDs. One row per bidder/item. `coverage` is `included`, `excluded`, or `clarify`. Only `included` rows can contain positive quantity, unit, and nonnegative price. For other coverage states quantity/unit/price must be empty. `valid_through` is a strict calendar date; a blank date triggers human review. `source_ref` is an invented neutral record pointer, not proof. Each CSV is at most 110KB. Input errors block output.

**Deterministic logic:** For each bidder and requirement, a missing, excluded or clarification line triggers a hold; critical missing/excluded/mismatched quantities trigger a STOP-level exception. Included lines count in a *provisional subtotal* only when their quantity and unit equal the required line. A hidden exclusion, zero unit price, expired quote, missing or suspicious source, unmapped line, blank validity or unpriced exemption also generates an exception. Provisional totals are never a real project price, and there is deliberately no lowest-bid winner or automatic award. Does not model subcontractor mobilization, tax, insurance, safety certifications, legal terms, trade qualifications, pricing revisions, actual paid invoices or eligible customer/client work.

**Local exports:** Private CSV exception rows, private TXT findings and provisional subtotals, aggregate-only JSON contract `PD-BID-SCOPE-1`. CSV formula injection is escaped. JSON must exclude bidder IDs, exact prices, source refs, dates, exclusion text and task descriptions; all positive rights/permission claims are explicitly false. No network calls, persistent storage, real customer contact, purchasing, negotiation or payment authority.

## Current collection evidence
Read VALIDATION.md for performed checks and unverified gates on this exact collection. Historical upstream in-memory browser results are not a rerun or acceptance of this candidate. Public source availability does not grant permission to disclose user-generated outputs or to act on their contents.
