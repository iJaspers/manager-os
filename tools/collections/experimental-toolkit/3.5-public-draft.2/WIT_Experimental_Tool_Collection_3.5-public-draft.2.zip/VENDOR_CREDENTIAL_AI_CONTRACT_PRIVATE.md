> Public experimental source. PRIVATE in export names and schemas describes user-generated reports, not this source package. Use only invented examples; never infer permission to disclose reports or data. Browser/real-user acceptance is not established. See README_START_HERE.md.

# Private AI data contract: Vendor Credential & Expiry Preflight v1

**Purpose:** Catch potential document-timing and missing-role-requirement exceptions before a **fictional** subcontractor/vendor service commitment. This is a locally executing, original, offline UI for synthetic aliases only. It has no licensing jurisdiction model, legal requirements library, insurer link, credential verification, identity validation, actual assignment approval, coverage determination, or external side effects.

## Three CSV schemas

- Assignments: `vendor_tag,role_tag,work_date,rights_status,scope_approval,source_ref`. `rights_status=owned|unknown|restricted`; `scope_approval=approved|pending|rejected`.
- Role requirements: `role_tag,credential_tag,mandatory,renewal_notice_days,source_ref`. `mandatory=yes|no`; notice integer 0–180.
- Document declarations: `vendor_tag,credential_tag,valid_from,expires_on,review_state,source_ref`. `review_state=checked|pending|rejected|unknown`.

All IDs must be uppercase invented tags, 1–40 characters, starting A–Z, then A–Z, digits, underscore. Dates use real calendar days in strict ISO 2000–2099. Validity endpoints are inclusive. `checked`, `owned`, and `approved` are unverified typed assertions, not permissions or endorsements. The review date is deliberately typed and fictitious. Source references are invented labels, not real documents. Source references can be empty but create a review exception. Limit 500 rows and 120,000 characters per table; 120 characters per source reference. Duplicate assignment and duplicate role-requirement keys are blocked. Multiple declarations for the same vendor credential are **not** silently collapsed; flagged `COMPETING_DECLARATIONS`, and effective-date evaluation is withheld until resolved.

Mandatory presence count is **a presence count**, not compliant count: missing mandatory declaration is flagged; an expired/pending or unverified declaration still counts as present. No vendor status is greenlit. Other findings include role undefined, rights/scope hold, missing evidence, work date in past, declaration already expired as of review date, valid-from after intended work, expiry before intended work, renewal window, unreviewed declaration and declarations unconnected to an assignment's requirement. Notice window is a simple arithmetic buffer after the work date, not law or policy.

## Privacy and export boundary

Only entirely invented role/vendor/document tags and references, never actual names, workers, insurance policies, licence numbers, medical, client, financial, employer or security data. Content remains in current browser tab (no API, cookie, localStorage, telemetry, third-party JavaScript, network, account access, or real-life contact). Optional private TXT and exception CSV contain synthetic record aliases. The optional AI JSON is counts-only and deliberately excludes tags, work dates, source references, staff data and raw inputs. It explicitly denies verification and authorization. Do not import data about real people or submit raw export to a public model.

## AI handoff

Interpret finding codes as questions for a qualified human to resolve from authoritative requirements and original evidence. Do not assert insurance cover, trade qualifications, legal compliance, contractual rights, eligibility, expiry validity or approval from these declarations. Never issue dispatch authorization, purchase orders, customer proposals, releases or legal advice. External desktop/mobile/browser/host compatibility and real-world suitability remain untested until explicitly independently checked. Employment/IP, privacy and consent controls remain in force.

## Current collection evidence
Read VALIDATION.md for performed checks and unverified gates on this exact collection. Historical upstream in-memory browser results are not a rerun or acceptance of this candidate. Public source availability does not grant permission to disclose user-generated outputs or to act on their contents.
