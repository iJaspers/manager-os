> Public experimental source. PRIVATE in export names and schemas describes user-generated reports, not this source package. Use only invented examples; never infer permission to disclose reports or data. Browser/real-user acceptance is not established. See README_START_HERE.md.

# PRIVATE / Renewal & Notice Window Guard / AI data contract v1

**Scope:** A human-review-only, original, browser-local metadata preflight for fictional contract renewal windows. No service or contract legal interpretation is generated. No contact, notice, cancellation, acceptance, payment, invoice, filing or external request is permitted. Does not handle true client, employer, personal, financial, security, tax or privileged content.

## Input

`contracts`: exact CSV header `contract_tag,term_end,renewal_mode,notice_days,decision_intent,rights_status,review_state,source_ref`. Strict invented tags, 2020–2099 valid calendar dates, 0–366 notice days, source refs as invented opaque tags only. Enums: mode `auto|manual|none|unknown`, intent `continue|cancel|undecided`, rights `owned|unknown|restricted`, review `reviewed|pending|rejected`.

`notices`: exact CSV header `contract_tag,notice_date,proof_state,source_ref`, zero or more rows (header-only is allowed). Proof enum `confirmed|claimed|pending|rejected`. `confirmed` is a typed declaration, not authenticated delivery. `asof` is an explicit fictional calendar review date.

## Model

Model cutoff is `term_end - notice_days` measured in UTC *calendar-date arithmetic*, inclusive. This is a **screening convention**, not a statement of legal rights or actual notice period. Flags include orphan or duplicate claimed notices, missing source links, undecided auto-renewal decisions, late/unverified cancellation assertions, passed/near model cutoffs, renewal terms already elapsed, unknown renewal mode, rights/review holds. Claims do not establish that a notice reached its proper recipient, that the notice method was valid, or that a contract was canceled. Unknowns remain holds; never infer legal compliance from a green model result.

## Output and privacy

Private CSV finding queue; private human-readable TXT review; counts-only JSON (`private_renewal_notice_counts_only_v1`). JSON must include zero identifiers, dates other than user-entered review date, financial amounts or raw contract terms; booleans for `contract_terms_verified`, `notices_authenticated`, `rights_verified`, `legal_clearance`, `actions_authorized`, `independent_host_tested` must always be `false`. All exports marked private. Script uses local input only, no network/storage and no embedded third-party packages.

## Acceptance boundary

Current source status: public experimental collection; current performed tests and remaining gates are recorded in VALIDATION.md. No real-world use or authority is established.

## Current collection evidence
Read VALIDATION.md for performed checks and unverified gates on this exact collection. Historical upstream in-memory browser results are not a rerun or acceptance of this candidate. Public source availability does not grant permission to disclose user-generated outputs or to act on their contents.
