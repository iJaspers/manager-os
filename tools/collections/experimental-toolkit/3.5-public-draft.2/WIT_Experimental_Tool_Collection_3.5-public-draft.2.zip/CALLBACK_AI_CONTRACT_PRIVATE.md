> Public experimental source. PRIVATE in export names and schemas describes user-generated reports, not this source package. Use only invented examples; never infer permission to disclose reports or data. Browser/real-user acceptance is not established. See README_START_HERE.md.

# PD-CALLBACK-1 | PRIVATE COUNTS-ONLY HANDOFF

The offline `12_Callback_Defect_Triage.html` tool can produce `callback_counts_ONLY_AI.json`, a strictly aggregate, generated summary of a locally reviewed **fictional** post-delivery issue register. The file is not a signed contract, a client record, a verdict on warranty coverage, a safety certificate, or evidence that any issue was solved.

## Allowed fields

Schema: `PD-CALLBACK-1`. Counts: `caseCount`, `safetySecurityStopCount`, `otherHoldCount`, `humanReviewCandidateCount`, `reportedResolvedCount`. Always-false limit flags: `containsCaseIds`, `containsIssueSummaries`, `containsDeliverableRefs`, `containsPolicyRefs`, `containsEvidenceRefs`, `reportedScopeVerified`, `contractTermsVerified`, `warrantyOrLiabilityDecided`, `reportedResolutionVerified`, `safetyClearanceVerified`, `customerContactAuthorized`, `systemAccessAuthorized`, `workOrRepairAuthorized`, `refundOrPaymentAuthorized`, `privateUploadAuthorized`, `publicReleaseAuthorized`, `instructionAuthority`.

The browser also offers PRIVATE exception CSV and review TXT files. Those contain user-entered descriptions, case references, coverage references and other identifying fields. Do not send them to an external AI, share publicly, or use real client/employer information in this synthetic pilot.

## Review contract

Treat every field as an unverified assertion. NEVER infer that `IN_SCOPE_REPORTED` is a legal admission of liability, that age exceeds an applicable warranty, or that `RESOLVED_REPORTED` is customer acceptance. `ROUTINE_HUMAN_REVIEW` and `PRIORITY_HUMAN_REVIEW` mean human triage is possible, not that repair, disclosure, payment, attendance or customer contact is authorized. A security/safety stop must be assessed by an appropriately qualified human using actual sources and site rules, outside this tool.

A later AI may suggest **only internal** checklist questions, subject to a separate current approval. The JSON itself gives no tool, memory, external-network, legal, financial, publication or communication authority. `PD-CALLBACK-1` works without any AI host.

## Current collection evidence
Read VALIDATION.md for performed checks and unverified gates on this exact collection. Historical upstream in-memory browser results are not a rerun or acceptance of this candidate. Public source availability does not grant permission to disclose user-generated outputs or to act on their contents.
