> Public experimental source. PRIVATE in export names and schemas describes user-generated reports, not this source package. Use only invented examples; never infer permission to disclose reports or data. Browser/real-user acceptance is not established. See README_START_HERE.md.

# PD-TIME-1 | PRIVATE Service Time Evidence Reconciler

**Version:** v2.6, 2026-10-24. First-party original offline HTML + JavaScript. Reuses original toolkit `common.js`/`styles.css` without modification, no external libraries, external scripts, APIs, account access, persistent storage, telemetry or server. Every field and all sample data are invented. This is a **human exception queue**, not validated proof or a dispatch, payroll or invoicing engine.

## Buyer problem and distinctness

A service business may have recorded time segments (onsite, travel, shop, break, administration) and a separate purported job-time claim that disagree. This tool crosschecks one person's *reported* same-day intervals against *reported* visit/job time claims; it detects same-person overlaps, unlinked claims, unsupported claimed minutes, unclaimed onsite/travel segments, duplicate claims and missing permission/provenance. It does not map photographs to recordings (`14`), determine whether a milestone is payable (`08`), schedule a visit (`22`) or calculate weekly crew capacity (`27`). It does not independently prove a worker worked, determine which minutes are billable, or evaluate labor standards/union overtime.

## Input contracts (fictional only)

Two local RFC 4180-style CSV strings/files. Each header must be exact, with 1–300 data rows and 9 cells per row; each text input <=120,000 characters, each cell <=90 characters. File selection limit ~480k bytes plus decoded character bound. IDs are uppercase `A-Z` followed by 1–30 uppercase letters/digits/underscore/hyphen. Dates are valid `YYYY-MM-DD` in 2000–2100; same-day 24-hour `HH:MM` times strictly increasing, no crossing midnight. A single imported file does not trigger review until the user explicitly runs it. Any validation failure clears all previous exports.

- Segments: `segment_id,worker_code,work_date,start_time,end_time,activity,job_code,rights_status,source_ref`.
- Claims: `claim_id,worker_code,work_date,job_code,claimed_minutes,claim_basis,approval_state,rights_status,source_ref`.
- Segment activities: `onsite`, `travel`, `shop`, `admin`, `break`. Only onsite and travel contribute to comparisons; *all* segments can overlap. Break/shop/admin are not assumed payable or unpaid.
- Claimed minutes: whole integer 1–1440. `claim_basis`: `onsite_only` or `onsite_plus_travel`; this is a *claim premise*, not a signed contract. `approval_state`: `approved`, `pending`, `rejected` as typed, never verified.
- `rights_status`: `cleared`, `unknown`, `restricted`; **even `cleared` is an unsupported input claim**, not legal permission.
- `source_ref` is a typed safe token or `UNKNOWN`; `UNKNOWN` flags an evidence gap. No source is verified by the software. Duplicate segment or claim IDs halt review. Duplicate claims for a worker/date/job produce a *human review finding*, not silent approval.

## Deterministic provisional calculations

Segments are integer minute intervals `[start,end)`. Any intersection between two segments reported for the same worker/day adds one overlap pair and finding. A job-day group is `worker_code/work_date/job_code` and matches recorded onsite/travel minutes against the aggregate time claimed on that key. For a group with any `onsite_only` basis, the conservative comparison excludes travel. Inconsistent bases generate `MIXED_CLAIM_BASIS`, and no model result justifies collection or an accusation. Duplicate claims are explicitly held as `REPEATED_JOB_DAY_CLAIM`; a combined amount above eligible typed minutes adds a separate exception. When a claim has no onsite/travel segments, it is unlinked. A segment group with onsite/travel but no claim is flagged without assuming it ought to be billed. Numeric data and rights are not independently validated. Outputs remain preliminary.

## Private outputs and AI boundary

- Detailed local UI, `PRIVATE_service_time_evidence_exceptions.csv`, and `PRIVATE_service_time_evidence_review.txt` contain fictional record identifiers/dates/hours. They MUST remain private and should not be pasted into external AI tools without fresh human review and permissions.
- `PRIVATE_service_time_counts_only_AI.json` exposes only counts (segments, claims, overlapping pairs, job-day groups, human exceptions) and constant booleans `source_verified=false`, `rights_verified=false`, `work_verified=false`, `approval_verified=false`, `billing_authorized=false`, `published=false`. It contains **no worker ID, job ID, date, hour, dollar amount, source ref, claim ref or individual finding**.
- Exported CSV cells are protected against spreadsheet-formula injection by the shared original CSV serializer. UI uses `textContent` for untrusted strings. Network access is denied by restrictive CSP.

**Permitted follow-on AI use:** Suggest safe human verifications using aggregate counts only. Never infer dishonesty, fraud, payroll underpayment, rights ownership, permitted travel billing, tax deductions, acceptance, authenticated service, payment or authority to alter a record.

**Original invented fixtures:** `examples/time_evidence_conflicts_segments_fictional.csv`, `examples/time_evidence_conflicts_claims_fictional.csv`, `examples/time_evidence_aligned_segments_fictional.csv`, `examples/time_evidence_aligned_claims_fictional.csv`.

**QA boundary:** `tests/service_time_evidence_browser_checks.py` exercises positive/adversarial, local synthetic CSV file picker, input invalidation, downloads and network checks using locally in-memory supplied HTML/CSS/JS. This is NOT an extracted `file://`/desktop/mobile/production-host/customer test; extracted local browser navigation is separately attempted and administrator-blocked. No real clients, site visit, employer material, contracts, production use, website publication, billing, money collection or commercial outcomes are verified.

## Current collection evidence
Read VALIDATION.md for performed checks and unverified gates on this exact collection. Historical upstream in-memory browser results are not a rerun or acceptance of this candidate. Public source availability does not grant permission to disclose user-generated outputs or to act on their contents.
