> Public experimental source. PRIVATE in export names and schemas describes user-generated reports, not this source package. Use only invented examples; never infer permission to disclose reports or data. Browser/real-user acceptance is not established. See README_START_HERE.md.

# Site Visit Dispatch Preflight | PRIVATE data and AI contract

**Schema:** `PD-SITE-PREFLIGHT-1` (only counts and finding codes may be passed to an AI). Distribution is PRIVATE_COUNTS_ONLY. No invented identifiers, dates, time windows, site info, pricing, contact details, access references, scope references, permit details, employee/client identities, or actual evidence are included in the AI JSON export.

**Input:** One offline CSV with exact 17-column header:
`visit_id,site_id,visit_date,window_start,window_end,access_state,access_ref,contact_state,escort_required,escort_state,parts_state,parts_ref,tools_ready,safety_class,safety_review,scope_ref,last_confirmed`

Use fictional invented identifiers only. `visit_id`, `site_id`, `scope_ref`, and optional `access_ref`/`parts_ref` must match `^[A-Z][A-Z0-9_-]{1,23}$`. `visit_date` and nonempty `last_confirmed` must be real ISO dates; `last_confirmed` cannot be after the selected review date. Time windows are strictly increasing `HH:MM` pairs within a single site-local calendar date. All rows use the same declared site-local calendar assumption: the tool deliberately does NOT validate actual timezones, daylight-saving changes or live clock arrival.

Enums: access_state `reported_confirmed|pending|denied`; contact_state `reported_confirmed|pending|unreachable`; escort_required `yes|no`; escort_state `reported_confirmed|pending|not_applicable`; parts_state `staged|pending|missing|not_needed`; tools_ready `yes|no`; safety_class `routine|specialist|unknown`; safety_review `reported_done|pending`.

**Checks:** Missed planned date (STOP); distant future window needing reconfirmation (HOLD, >3 days ahead); narrow visit window (HOLD, <30 minutes); denied/unconfirmed access or missing source, contact, required escort, missing/pending parts, staged-parts evidence gap, absent tool check, specialist/unknown safety class (STOP even when review reportedly complete), pending safety assessment, missing/stale last confirmation (>2 days), and same invented site/date overlapping attendance (HOLD on each overlapping visit). Date arithmetic uses UTC calendar-day differences only to avoid browser timezone effects, not as evidence of actual timezone. A clean result means no *register-level* exception, not authorization to go to a site.

**Input limitations:** 100,000 UTF-8 bytes and 180 rows maximum; exact CSV header and column count; no executable or external code; no name/email/address free-text fields; offline manual CSV/textarea input; all reported confirmations are inherently unverified.

**Exports:** PRIVATE detailed CSV and TXT contain fictional IDs; restricted counts-only JSON contains numbers, exception codes and hardcoded authorization booleans all `false`. Editing/importing resets and disables all stale exports. No data is stored or transmitted by the tool. Do not forward detailed reports outside the private lab.

**Mandatory human gates:** Genuine site authority, permission, scope, appointment and contacts, safe entry, permits, site-specific hazard review, worker qualifications, correct material/tool staging, travel feasibility and employee availability must be independently confirmed. The tool does not validate the site, verify source documents, authorize dispatch, book workers, contact clients, spend money, access secure locations or publish outputs.

## Current collection evidence
Read VALIDATION.md for performed checks and unverified gates on this exact collection. Historical upstream in-memory browser results are not a rerun or acceptance of this candidate. Public source availability does not grant permission to disclose user-generated outputs or to act on their contents.
