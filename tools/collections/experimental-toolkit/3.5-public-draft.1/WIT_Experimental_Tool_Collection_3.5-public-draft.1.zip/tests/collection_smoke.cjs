'use strict';
// Bounded synthetic DOM startup/fixture checks, NOT rendered browser or OS isolation.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'); const results=[];
function check(file,name,fn){try{fn();results.push({file,name,pass:true})}catch(e){results.push({file,name,pass:false,detail:String(e.message).slice(0,300)})}}
async function boot(file){const html=fs.readFileSync(path.join(root,file),'utf8'),nodes=new Map();
 function elem(){return {value:'',textContent:'',disabled:false,checked:false,files:[],children:[],events:{},classList:{add(){},remove(){},toggle(){}},addEventListener(n,f){this.events[n]=f},click(){return this.events.click?.({target:this})},replaceChildren(){this.children=[]},append(...v){this.children.push(...v)},appendChild(v){this.children.push(v)},remove(){},setAttribute(){}}}
 const doc={getElementById(id){if(!nodes.has(id))nodes.set(id,elem());return nodes.get(id)},createElement:elem,querySelectorAll(){return[]},body:elem()};
 const dec=s=>s.replaceAll('&gt;','>').replaceAll('&lt;','<').replaceAll('&amp;','&').replaceAll('&quot;','"');
 for(const x of html.matchAll(/<input\b[^>]*>/g)){const id=x[0].match(/\bid="([^"]+)"/),val=x[0].match(/\bvalue="([^"]*)"/);if(id){const n=doc.getElementById(id[1]);n.value=val?dec(val[1]):'';n.checked=/\bchecked\b/.test(x[0]);}}
 for(const x of html.matchAll(/<textarea\b[^>]*id="([^"]+)"[^>]*>([\s\S]*?)<\/textarea>/g))doc.getElementById(x[1]).value=dec(x[2]);
 for(const x of html.matchAll(/<select\b[^>]*id="([^"]+)"[^>]*>([\s\S]*?)<\/select>/g)){const opts=[...x[2].matchAll(/<option([^>]*)>([^<]*)<\/option>/g)],c=opts.find(v=>/selected/.test(v[1]))||opts[0];if(c)doc.getElementById(x[1]).value=c[1].match(/value="([^"]+)"/)?.[1]||c[2];}
 const ctx=vm.createContext({document:doc,File,Blob,TextEncoder,TextDecoder,Uint8Array,Uint32Array,ArrayBuffer,console:{log(){}},setTimeout(){},clearTimeout(){}},{codeGeneration:{strings:false,wasm:false}});
 const common=fs.readFileSync(path.join(root,'common.js'),'utf8'), scripts=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(x=>x[1]);
 for(const s of scripts)new vm.Script(s);await vm.runInContext(common+'\n'+scripts.join('\n'),ctx,{timeout:2000});
 return {ctx,nodes,html,run:s=>vm.runInContext(s,ctx,{timeout:1000})};
}
(async()=>{
for(const file of fs.readdirSync(root).filter(f=>/^\d\d_.*\.html$/.test(f)).sort()){
 let app;try{app=await boot(file);results.push({file,name:'inline syntax and synthetic DOM startup',pass:true})}catch(e){results.push({file,name:'inline syntax and synthetic DOM startup',pass:false,detail:String(e.message)})}
 if(!app)continue;
 check(file,'shared parser rejects bare quote',()=>assert.throws(()=>app.run('parseCSV(\'a,b\\n1,bad"quote\')'),/quote/i));
 check(file,'shared parser preserves valid quoted fixture',()=>assert.equal(JSON.stringify(app.run('parseCSV(\'a,b\\n1,"valid, value"\')')),JSON.stringify([['a','b'],['1','valid, value']])));
 check(file,'no direct network or dynamic-code APIs in app source',()=>assert.doesNotMatch(app.html,/\bfetch\s*\(|XMLHttpRequest|WebSocket|navigator\.sendBeacon|\beval\s*\(|new\s+Function|localStorage|sessionStorage|document\.write/));
}
const report={scope:'37 app inline syntax and startup with minimal synthetic DOM plus shared parser fixtures and API scan; NOT browser event dispatch, rendering, picking, downloads or per-tool business correctness.',tests:results.length,passed:results.filter(x=>x.pass).length,failed:results.filter(x=>!x.pass).length,results};
fs.writeFileSync(path.join(__dirname,'collection_smoke_results.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));process.exitCode=report.failed?1:0;

})().catch(e=>{console.error(e);process.exitCode=1});
