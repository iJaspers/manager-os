# Scope of rights

This owner-authorized public bundle contains previously public WIT starter artifacts and two source-visible experimental tool previews. It does not grant a blanket MIT, open-source or commercial reuse licence. Preserve each component's existing notices.

The optional companion retains the original scoped licence inside its archive. That grant does not extend to either Scout preview or unrelated WIT material. The two tool directories contain their own source-availability notices and provenance. Third-party runtimes are external prerequisites, not included binaries. Standard applicable rights remain unaffected.
