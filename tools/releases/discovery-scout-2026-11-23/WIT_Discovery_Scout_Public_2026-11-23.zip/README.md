# WIT, Discovery and Scout public preview

Release: 23 November 2026. Start with START_HERE_PHONE.txt.

WIT/ contains the unchanged public starter text, handbook and optional Bob companion RC1. Scout_Explain/ contains version 0.1.0-public-draft.1, with 135 Python and 20 JavaScript offline regression tests passed. School_Contact_Scout/ contains version 0.1.0-preview.1, with 21 offline tests passed. Read each tool's README, TEST_RESULTS, PROVENANCE and LICENSE_NOTICE before use. Examples are fictional.

The WIT text can be attached or pasted into a supported existing AI chat host. Python tools require a runtime and do not install themselves on a phone. The source previews supply no autonomous LinkedIn crawler, email delivery service or scheduler. Working contact lists, source responses and research checkpoints can contain personal information; keep them private.

Public release home: https://github.com/iJaspers/manager-os/tree/main/tools/releases/discovery-scout-2026-11-23

Source availability is separate from production readiness. File hashes in SHA256SUMS.json identify these bytes, not signed authenticity or correctness.
