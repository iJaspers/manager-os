# Witburrow Starter Companion 2026.11.01-rc1

Original WIT instructions and documentation prepared with AI assistance for iJaspers. This small candidate revises the existing `BOB_ON_DEMAND_2026.10.28.1.txt` workflow and its companion's save/return rules. It does not contain the historical private Bob engines or a replacement Manager OS.

The retained MIT notice in LICENSE applies to the original WIT text in this candidate to the extent iJaspers controls the applicable rights. It does not grant rights to linked websites, third-party tools, provider services, books, private records, or employer/client material. Public links are references, not bundled third-party code. No new attribution is invented for linked material. Existing source-specific notices continue to govern any tool separately obtained from the catalogue.

Prior Bob component SHA-256: `04c1875eff89991ee13899eb390d2f7f6d0958336e96fb78c0709815589ca3f9`.
Prior companion: WIT Starter Companion 2026.10.28.1. Current release includes only the revised Bob text and newly revised beginner/release documentation. The earlier workbook, other companion modules, One Thing Now and later menu materials are not bundled.

Public references:

- https://www.ijaspers.com/post/witburrow-starter-reference
- https://github.com/iJaspers/manager-os
- https://github.com/iJaspers/manager-os/blob/main/tools/FIRST_TASK_2026-10-22.3.md

Checksums establish file consistency, not publisher authentication, model reliability or permission to execute actions. This release candidate is not a legal-title certification, host installation, security-isolation claim or publication approval.
